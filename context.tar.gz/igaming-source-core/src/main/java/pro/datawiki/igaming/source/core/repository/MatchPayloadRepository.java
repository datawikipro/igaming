package pro.datawiki.igaming.source.core.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import pro.datawiki.igaming.source.core.domain.MatchPayload;

@Repository
public interface MatchPayloadRepository extends JpaRepository<MatchPayload, Long> {
}
