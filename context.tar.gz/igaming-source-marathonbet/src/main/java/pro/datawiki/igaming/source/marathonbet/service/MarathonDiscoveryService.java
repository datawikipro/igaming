package pro.datawiki.igaming.source.marathonbet.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import pro.datawiki.igaming.source.core.domain.LeagueCache;
import pro.datawiki.igaming.source.core.domain.MatchCache;
import pro.datawiki.igaming.source.core.repository.LeagueCacheRepository;
import pro.datawiki.igaming.source.core.service.MatchPersistenceService;
import pro.datawiki.igaming.source.marathonbet.dto.marathon.MarathonEvent;
import pro.datawiki.igaming.source.marathonbet.dto.marathon.MarathonMenuNode;

import java.time.LocalDateTime;
import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class MarathonDiscoveryService {

    private final MarathonbetApiClient apiClient;
    private final LeagueCacheRepository leagueCacheRepository;
    private final MatchPersistenceService persistenceService;
    private final ObjectMapper objectMapper;

    @Transactional
    public int queueLeagues() {
        MarathonMenuNode root = apiClient.fetchPrematchMenu();
        if (root == null) {
            log.error("Cannot fetch prematch menu, aborting league queueing");
            return 0;
        }

        List<MarathonMenuNode> leagues = apiClient.getLeagueNodes(root);
        int queued = 0;

        for (MarathonMenuNode league : leagues) {
            try {
                if (queueSingleLeague(league)) queued++;
            } catch (Exception e) {
                log.error("Error queueing league {}: {}", league.getLabel(), e.getMessage());
            }
        }
        return queued;
    }

    private boolean queueSingleLeague(MarathonMenuNode league) {
        String link = league.getUrl() != null ? league.getUrl().trim() : "";
        if (link.isEmpty()) return false;
        
        String externalId = league.getUid();
        LeagueCache cache = leagueCacheRepository.findByExternalId(externalId).orElse(new LeagueCache());
        
        boolean isNew = cache.getId() == null;
        if (isNew) {
            cache.setExternalId(externalId);
            cache.setCreatedAt(LocalDateTime.now());
            cache.setStatus(LeagueCache.Status.NEW);
        }
        
        cache.setLeagueName(league.getLabel());
        cache.setUrl(link);
        cache.setSportName(league.getSport());
        cache.setRegionName(league.getRegion());
        cache.setUpdatedAt(LocalDateTime.now());
        
        leagueCacheRepository.save(cache);
        return isNew;
    }

    public int processEventsInLeague(LeagueCache cache) {
        MarathonMenuNode mockNode = new MarathonMenuNode();
        mockNode.setUrl(cache.getUrl());
        mockNode.setLabel(cache.getLeagueName());
        mockNode.setSport(cache.getSportName());
        mockNode.setRegion(cache.getRegionName());
        
        List<MarathonEvent> events = apiClient.fetchEventsForLeague(mockNode);
        int saved = 0;
        for (MarathonEvent event : events) {
            try {
                saveOrUpdateEvent(event);
                saved++;
            } catch (Exception e) {
                log.warn("Failed to save event {}: {}", event.getEventId(), e.getMessage());
            }
        }
        return saved;
    }

    public void saveOrUpdateEvent(MarathonEvent event) throws Exception {
        String payload = objectMapper.writeValueAsString(event);
        
        MatchCache match = new MatchCache();
        match.setExternalId(event.getEventId());
        match.setTeam1(event.getTeam1());
        match.setTeam2(event.getTeam2());
        match.setScore1(event.getScore1());
        match.setScore2(event.getScore2());
        match.setIsLive(event.getIsLive() != null && event.getIsLive());
        match.setSportName(event.getSportName());
        match.setStartTime(event.getStartTime());

        persistenceService.saveOrUpdateMatchMetadata(match, payload);
    }
}
