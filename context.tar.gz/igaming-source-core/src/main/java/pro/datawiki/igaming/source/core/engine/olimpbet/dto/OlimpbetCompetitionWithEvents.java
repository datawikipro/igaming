package pro.datawiki.igaming.source.core.engine.olimpbet.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class OlimpbetCompetitionWithEvents {
    private String id;
    private OlimpbetCompetition competition;
    private List<OlimpbetEvent> events;
}
