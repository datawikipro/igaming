package pro.datawiki.igaming.source.core.validation;
 
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.networknt.schema.JsonSchema;
import com.networknt.schema.JsonSchemaFactory;
import com.networknt.schema.SchemaValidatorsConfig;
import com.networknt.schema.SpecVersion;
import com.networknt.schema.ValidationMessage;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.stereotype.Service;
 
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
 
@Service
@RequiredArgsConstructor
@Slf4j
public class JsonValidationService {
 
    private final ObjectMapper objectMapper;
    private final Map<String, JsonSchema> schemas = new HashMap<>();
    private final JsonSchemaFactory factory = JsonSchemaFactory.getInstance(SpecVersion.VersionFlag.V7);
 
    @PostConstruct
    public void init() throws IOException {
        PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
        Resource[] resources = resolver.getResources("classpath:schemas/*.json");
        
        SchemaValidatorsConfig config = new SchemaValidatorsConfig();
        // Option to customize validator behavior if needed in future
 
        for (Resource resource : resources) {
            String filename = resource.getFilename();
            if (filename != null) {
                try {
                    JsonSchema schema = factory.getSchema(resource.getInputStream(), config);
                    schemas.put(filename, schema);
                    log.info("Loaded JSON schema: {}", filename);
                } catch (Exception e) {
                    log.error("Failed to load schema {}: {}", filename, e.getMessage());
                }
            }
        }
    }
 
    /**
     * Validates JSON string against a schema.
     * @param json The JSON to validate
     * @param schemaName The name of the schema file (e.g. "fonbet-schema.json")
     * @throws ValidationException if validation fails
     */
    public void validate(String json, String schemaName) {
        JsonSchema schema = schemas.get(schemaName);
        if (schema == null) {
            log.warn("Schema {} not found, skipping validation", schemaName);
            return;
        }
 
        try {
            JsonNode node = objectMapper.readTree(json);
            Set<ValidationMessage> errors = schema.validate(node);
            
            if (!errors.isEmpty()) {
                String message = errors.stream()
                        .map(ValidationMessage::getMessage)
                        .collect(Collectors.joining("; "));
                throw new JsonValidationException("JSON Validation failed for " + schemaName + ": " + message);
            }
        } catch (IOException e) {
            throw new JsonValidationException("Failed to parse JSON for validation: " + e.getMessage());
        }
    }
 
    public static class JsonValidationException extends RuntimeException {
        public JsonValidationException(String message) {
            super(message);
        }
    }
}
