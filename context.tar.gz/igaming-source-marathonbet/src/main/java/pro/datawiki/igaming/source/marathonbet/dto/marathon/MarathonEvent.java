package pro.datawiki.igaming.source.marathonbet.dto.marathon;

import lombok.Data;
import java.util.List;

/**
 * Represents a parsed event from Marathonbet HTML page.
 * Marathonbet loads event data via HTML AJAX fragments, parsed with Jsoup.
 */
@Data
public class MarathonEvent {
    private String eventId;
    private String sportName;
    private String leagueName;
    private String team1;
    private String team2;
    private String score1;
    private String score2;
    private String timer;
    private Long startTime;
    private Boolean isLive;
    private String treeId;
    private String matchUrl;
    private List<MarathonOdd> odds;
}
