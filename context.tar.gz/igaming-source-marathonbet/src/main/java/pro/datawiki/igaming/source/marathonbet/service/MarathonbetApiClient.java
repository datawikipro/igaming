package pro.datawiki.igaming.source.marathonbet.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.springframework.stereotype.Service;
import pro.datawiki.igaming.source.marathonbet.config.MarathonbetConfig;
import pro.datawiki.igaming.source.marathonbet.dto.marathon.MarathonEvent;
import pro.datawiki.igaming.source.marathonbet.dto.marathon.MarathonMenuNode;

import java.util.*;

/**
 * Client for Marathonbet.ru data extraction.
 *
 * Responsibilities:
 * 1. Network communication (BrowserService)
 * 2. Menu management
 * 3. Coordination of event fetching and enrichment
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class MarathonbetApiClient {

    private final MarathonbetConfig config;
    private final pro.datawiki.igaming.source.core.browser.BrowserService browserService;
    private final MarathonHtmlParser htmlParser;


    /**
     * Fetch the prematch menu tree (sports -> regions -> leagues).
     */
    public MarathonMenuNode fetchPrematchMenu() {
        log.info("Fetching prematch menu from: {}", config.getMenuPrematchUrl());
        try {
            MarathonMenuNode root = browserService.apiGet(
                    config.getMenuPrematchUrl(), 
                    MarathonMenuNode.class, 
                    15000
            );

            if (root != null) {
                log.info("Fetched prematch menu with {} sports", 
                        root.getChilds() != null ? root.getChilds().size() : 0);
                return root;
            }
        } catch (Exception e) {
            log.error("Error fetching prematch menu: {}", e.getMessage());
        }
        return null;
    }

    /**
     * Get ALL league nodes from the menu.
     */
    public List<MarathonMenuNode> getLeagueNodes(MarathonMenuNode root) {
        List<MarathonMenuNode> leagues = new ArrayList<>();
        if (root == null || root.getChilds() == null) return leagues;

        int sportsUsed = 0;
        for (MarathonMenuNode sportNode : root.getChilds()) {
            if (sportNode.getChilds() != null) {
                boolean hasLeagues = false;
                for (MarathonMenuNode regionNode : sportNode.getChilds()) {
                    if (regionNode.getChilds() != null) {
                        for (MarathonMenuNode leagueNode : regionNode.getChilds()) {
                            leagueNode.setSport(sportNode.getLabel());
                            leagueNode.setRegion(regionNode.getLabel());
                            leagues.add(leagueNode);
                            hasLeagues = true;
                        }
                    }
                }
                if (hasLeagues) sportsUsed++;
            }
        }
        log.info("Collected {} league nodes from {} sports (no limits)", leagues.size(), sportsUsed);
        return leagues;
    }

    /**
     * Fetch events for a league by delegating to BrowserService and MarathonHtmlParser.
     */
    public List<MarathonEvent> fetchEventsForLeague(MarathonMenuNode league) {
        if (league.getUrl() == null) return Collections.emptyList();

        String url = config.getBaseUrl() + league.getUrl();
        log.debug("Fetching events via Browser for league: {} (URL: {})", league.getLabel(), url);

        try {
            String html = browserService.navigateAndGetBody(url, 8000);
            
            if (html == null || html.isEmpty()) {
                log.warn("No HTML content returned from browser for league: {}", league.getLabel());
                return Collections.emptyList();
            }

            Document doc = Jsoup.parse(html);
            return htmlParser.parseEventsFromHtml(doc, league);
        } catch (Exception e) {
            log.error("Error fetching events for league {}: {}", league.getLabel(), e.getMessage());
        }
        return Collections.emptyList();
    }

    /**
     * Navigates to the individual match page to extract "All markets".
     */
    public void enrichWithAllMarkets(MarathonEvent event) {
        if (event.getMatchUrl() == null || event.getMatchUrl().isEmpty()) {
            return;
        }

        String url = config.getBaseUrl() + event.getMatchUrl();
        log.debug("Fetching all markets for event {}: {}", event.getEventId(), url);
        
        try {
            String html = browserService.navigateAndGetBody(url, 5000); 
            if (html == null || html.isEmpty()) {
                log.warn("No HTML content for all markets of event {}", event.getEventId());
                return;
            }

            Document doc = Jsoup.parse(html);
            htmlParser.parseAllMarketsFromHtml(doc, event);
        } catch (Exception e) {
            log.error("Error fetching all markets for event {}: {}", event.getEventId(), e.getMessage());
        }
    }

    /**
     * Fetch a single event directly by its URL.
     */
    public MarathonEvent fetchEventByUrl(String url) {
        log.info("Fetching event directly by URL: {}", url);
        try {
            String html = browserService.navigateAndGetBody(url, 5000);
            
            if (html == null || html.isEmpty()) {
                log.warn("No HTML content returned from browser for URL: {}", url);
                return null;
            }

            Document doc = Jsoup.parse(html);
            return htmlParser.parseSingleEventFromHtml(doc, url, config.getBaseUrl());
        } catch (Exception e) {
            log.error("Error fetching event by URL {}: {}", url, e.getMessage());
        }
        return null;
    }
}
