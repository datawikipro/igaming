package pro.datawiki.igaming.source.core.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import pro.datawiki.igaming.source.core.domain.UnmappedSport;

import java.util.Optional;

@Repository
public interface UnmappedSportRepository extends JpaRepository<UnmappedSport, Long> {

    Optional<UnmappedSport> findFirstByBookmakerAndRawName(String bookmaker, String rawName);
}
