package pro.datawiki.igaming.source.marathonbet.mapper.tennis;

import org.springframework.stereotype.Component;
import pro.datawiki.igaming.dto.BetType;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.dto.market.BetScope;
import pro.datawiki.igaming.dto.market.StatType;
import pro.datawiki.igaming.source.core.mapper.AbstractBetTypeMapper;

@Component
public class MarathonTennisHandicapMapper extends AbstractBetTypeMapper {

    @Override
    public boolean supports(String bookmaker, SportType sportType) {
        return "marathonbet".equals(bookmaker) && sportType == SportType.TENNIS;
    }

    @Override
    public BetType map(String m, String o) {
        if (m == null || o == null) return null;

        // 3. Handicaps (Games & Sets)
        if (m.contains("HANDICAP")) {
            StatType statType = m.contains("SET") ? StatType.SETS : (m.contains("GAME") ? StatType.GAMES : StatType.MATCH);
            BetScope scope = BetScope.FULL_MATCH;
            if (m.contains("1ST_SET")) scope = BetScope.SET_1;
            else if (m.contains("2ND_SET")) scope = BetScope.SET_2;
            
            return mapHandicapRecord(o, scope, statType, m.contains("ASIAN"));
        }

        return null;
    }
}
