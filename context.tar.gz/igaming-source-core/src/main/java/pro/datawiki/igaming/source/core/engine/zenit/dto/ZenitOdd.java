package pro.datawiki.igaming.source.core.engine.zenit.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class ZenitOdd {
    private String oddKey;
    @JsonProperty
    private Double h;
    @JsonProperty
    private Integer o;
    private String t;
}
