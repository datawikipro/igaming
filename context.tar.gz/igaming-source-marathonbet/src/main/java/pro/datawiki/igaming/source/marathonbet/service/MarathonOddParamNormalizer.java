package pro.datawiki.igaming.source.marathonbet.service;

import org.springframework.stereotype.Component;

@Component
public class MarathonOddParamNormalizer {

    /**
     * Normalizes the numeric parameter of an odd based on its name.
     * Specifically handles the half-total shift for integer totals in Marathonbet
     * (e.g., 'Total_Goals.Under_2' shifts the param from 2.0 to 1.5).
     */
    public double normalizeParam(String name, double param) {
        if (name == null || name.isEmpty()) {
            return param;
        }

        String upperName = name.toUpperCase();
        
        // Handle Integer Total Shifts (e.g. Total Goals 2 -> 1.5/2.5)
        if (upperName.contains("TOTAL_GOALS") && param == Math.floor(param)) {
            if (upperName.contains("UNDER")) {
                return param - 0.5;
            } else if (upperName.contains("OVER")) {
                return param + 0.5;
            }
        }
        
        return param;
    }
}
