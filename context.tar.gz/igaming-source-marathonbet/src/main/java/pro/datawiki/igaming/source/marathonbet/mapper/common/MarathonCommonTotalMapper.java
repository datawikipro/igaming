package pro.datawiki.igaming.source.marathonbet.mapper.common;

import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import pro.datawiki.igaming.dto.BetType;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.dto.market.BetScope;
import pro.datawiki.igaming.dto.market.BetSubject;
import pro.datawiki.igaming.dto.market.StatType;
import pro.datawiki.igaming.source.core.mapper.AbstractBetTypeMapper;

import java.util.Set;

@Component
@Order(Ordered.LOWEST_PRECEDENCE)
public class MarathonCommonTotalMapper extends AbstractBetTypeMapper {

    private static final Set<SportType> SPECIALIZED_SPORTS = Set.of(
            SportType.FOOTBALL, SportType.BASKETBALL, SportType.HOCKEY, SportType.TENNIS,
            SportType.ESPORTS, SportType.CYBER_FOOTBALL, SportType.CYBER_BASKETBALL, SportType.CYBER_HOCKEY,
            SportType.VOLLEYBALL, SportType.BEACH_VOLLEYBALL, SportType.TABLE_TENNIS
    );

    @Override
    public boolean supports(String bookmaker, SportType sportType) {
        return "marathonbet".equals(bookmaker) && !SPECIALIZED_SPORTS.contains(sportType);
    }

    @Override
    public BetType map(String m, String o) {
        if (m == null || o == null) return null;
        String upperM = m.toUpperCase().trim();
        String upperO = o.toUpperCase().trim();

        if (upperM.contains("TOTAL")) {
            BetSubject subject = BetSubject.MATCH;
            if (upperM.contains("FIRST_TEAM") || upperM.contains("TEAM1")) subject = BetSubject.TEAM1;
            else if (upperM.contains("SECOND_TEAM") || upperM.contains("TEAM2")) subject = BetSubject.TEAM2;

            return mapTotalRecord(upperO, BetScope.FULL_MATCH, subject, StatType.MATCH, upperM.contains("ASIAN"));
        }
        return null;
    }
}
