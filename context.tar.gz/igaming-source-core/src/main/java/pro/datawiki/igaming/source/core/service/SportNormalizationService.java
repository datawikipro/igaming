package pro.datawiki.igaming.source.core.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import pro.datawiki.igaming.dto.SportType;

import java.util.HashMap;
import java.util.Map;

@Service
@RequiredArgsConstructor
@Slf4j
public class SportNormalizationService {

    private final UnmappedSportService unmappedSportService;
    private static final Map<String, SportType> RUS_MAP = new HashMap<>();

    static {
        // Standard sports
        RUS_MAP.put("ФУТБОЛ", SportType.FOOTBALL);
        RUS_MAP.put("ТЕННИС", SportType.TENNIS);
        RUS_MAP.put("БАСКЕТБОЛ", SportType.BASKETBALL);
        RUS_MAP.put("ХОККЕЙ", SportType.HOCKEY);
        RUS_MAP.put("ВОЛЕЙБОЛ", SportType.VOLLEYBALL);
        RUS_MAP.put("ГАНДБОЛ", SportType.HANDBALL);
        RUS_MAP.put("НАСТОЛЬНЫЙ ТЕННИС", SportType.TABLE_TENNIS);
        RUS_MAP.put("БИЛЬЯРД", SportType.BILLIARDS);
        RUS_MAP.put("ПЛЯЖНЫЙ ВОЛЕЙБОЛ", SportType.BEACH_VOLLEYBALL);
        RUS_MAP.put("КИБЕРСПОРТ", SportType.ESPORTS);
        RUS_MAP.put("КИБЕРФУТБОЛ", SportType.CYBER_FOOTBALL);
        RUS_MAP.put("КИБЕРХОККЕЙ", SportType.CYBER_HOCKEY);
        RUS_MAP.put("КИБЕРБАСКЕТБОЛ", SportType.CYBER_BASKETBALL);
        RUS_MAP.put("ЛАКРОСС", SportType.LACROSSE);
        RUS_MAP.put("ФЛОРБОЛ", SportType.FLOORBALL);
        RUS_MAP.put("БОКС", SportType.BOXING);
        RUS_MAP.put("РЕГБИЛИГ", SportType.RUGBY_LEAGUE);
        RUS_MAP.put("РЕГБИ-ЛИГА", SportType.RUGBY_LEAGUE);
        RUS_MAP.put("АМЕРИКАНСКИЙ ФУТБОЛ", SportType.AMERICAN_FOOTBALL);
        RUS_MAP.put("ХОККЕЙ НА ТРАВЕ", SportType.FIELD_HOCKEY);
        RUS_MAP.put("БАСКЕТБОЛ 3X3", SportType.BASKETBALL_3X3);
        RUS_MAP.put("БАСКЕТБОЛ 3Х3", SportType.BASKETBALL_3X3);
        RUS_MAP.put("БЕЙСБОЛ", SportType.BASEBALL);
        RUS_MAP.put("ВОДНОЕ ПОЛО", SportType.WATER_POLO);
        RUS_MAP.put("ФУТЗАЛ", SportType.FUTSAL);
        RUS_MAP.put("РЕГБИ-СОЮЗ", SportType.RUGBY_UNION);
        RUS_MAP.put("РЕГБИ", SportType.RUGBY_UNION);
        RUS_MAP.put("ДАРТС", SportType.DARTS);
        RUS_MAP.put("КРИКЕТ", SportType.CRICKET);
        RUS_MAP.put("СКВОШ", SportType.SQUASH);
        RUS_MAP.put("СНУКЕР", SportType.SNOOKER);
        RUS_MAP.put("КЕРЛИНГ", SportType.CURLING);
        RUS_MAP.put("ММА", SportType.MMA);
        RUS_MAP.put("ШАХМАТЫ", SportType.CHESS);
        RUS_MAP.put("НЕТБОЛ", SportType.NETBALL);
        RUS_MAP.put("ГЭЛЬСКИЙ СПОРТ", SportType.GAELIC_SPORT);
        RUS_MAP.put("БОУЛИНГ", SportType.BOWLING);
        RUS_MAP.put("БИАТЛОН", SportType.BIATHLON);
        RUS_MAP.put("ГОЛЬФ", SportType.GOLF);
        RUS_MAP.put("ГЭЛЬСКИЙ ФУТБОЛ", SportType.GAELIC_FOOTBALL);
        RUS_MAP.put("ГЭЛЬСКИЙ ХЕРЛИНГ", SportType.GAELIC_HURLING);
        RUS_MAP.put("ЛЫЖНЫЕ ГОНКИ", SportType.SKIING);
        RUS_MAP.put("БАДМИНТОН", SportType.BADMINTON);
        RUS_MAP.put("ФОРМУЛА 1", SportType.MOTORSPORTS);
        RUS_MAP.put("АВТО/МОТОСПОРТ", SportType.MOTORSPORTS);
        RUS_MAP.put("МОТОРНЫЕ ВИДЫ СПОРТА", SportType.MOTORSPORTS);
        RUS_MAP.put("ПАДЕЛ-ТЕННИС", SportType.PADEL);
        RUS_MAP.put("СЁРФИНГ", SportType.SURFING);
        RUS_MAP.put("СОФТБОЛ", SportType.SOFTBALL);
        
        // English lookups as fallback
        RUS_MAP.put("FOOTBALL", SportType.FOOTBALL);
        RUS_MAP.put("SOCCER", SportType.FOOTBALL);
        RUS_MAP.put("TENNIS", SportType.TENNIS);
        RUS_MAP.put("BASKETBALL", SportType.BASKETBALL);
        RUS_MAP.put("HOCKEY", SportType.HOCKEY);
        RUS_MAP.put("VOLLEYBALL", SportType.VOLLEYBALL);
        RUS_MAP.put("HANDBALL", SportType.HANDBALL);
        RUS_MAP.put("ESPORTS", SportType.ESPORTS);
        RUS_MAP.put("SOFTBALL", SportType.SOFTBALL);
    }

    /** Cache for resolved sport names to avoid repeated O(N) partial matching */
    private static final Map<String, SportType> RESOLVED_CACHE = new java.util.concurrent.ConcurrentHashMap<>();

    public SportType normalize(String rawName) {
        if (rawName == null || rawName.trim().isEmpty()) {
            return SportType.UNKNOWN;
        }

        String search = rawName.toUpperCase();

        // Check cache first
        SportType cached = RESOLVED_CACHE.get(search);
        if (cached != null) return cached;
        
        // 1. Direct match
        SportType type = RUS_MAP.get(search);
        if (type != null) {
            RESOLVED_CACHE.put(search, type);
            return type;
        }

        // 2. Partial match for complex names
        for (Map.Entry<String, SportType> entry : RUS_MAP.entrySet()) {
            if (search.contains(entry.getKey())) {
                RESOLVED_CACHE.put(search, entry.getValue());
                return entry.getValue();
            }
        }

        RESOLVED_CACHE.put(search, SportType.UNKNOWN);
        return SportType.UNKNOWN;
    }

    public SportType normalizeAndNotify(String bookmaker, String rawName) {
        SportType type = normalize(rawName);
        if (type == SportType.UNKNOWN && rawName != null && !rawName.trim().isEmpty()) {
            unmappedSportService.saveIfUnknown(bookmaker, rawName);
        }
        return type;
    }
}
