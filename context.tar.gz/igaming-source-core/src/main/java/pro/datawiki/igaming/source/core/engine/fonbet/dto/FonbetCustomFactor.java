package pro.datawiki.igaming.source.core.engine.fonbet.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class FonbetCustomFactor {
    private Integer e;  // eventId
    private Integer f;  // factorId (bet type)
    private Double v;   // value (odds/coefficient)
    @JsonProperty("isLive")
    private Boolean isLive;
    private Double p;   // parameter

    @JsonProperty("eventId")
    private Integer eventId;
    @JsonProperty("factorId")
    private Integer factorId;
    @JsonProperty("value")
    private Double value;
    @JsonProperty("param")
    private Double param;

    public Integer getE() {
        return e != null ? e : eventId;
    }

    public Integer getF() {
        return f != null ? f : factorId;
    }

    public Double getV() {
        return v != null ? v : value;
    }

    public Double getP() {
        return p != null ? p : param;
    }
}
