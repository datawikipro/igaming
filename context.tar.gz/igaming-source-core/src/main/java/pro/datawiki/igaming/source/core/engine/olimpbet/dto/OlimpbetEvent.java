package pro.datawiki.igaming.source.core.engine.olimpbet.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class OlimpbetEvent {
    private String id;
    private String name;
    private Long startDateTime;
    private String score;
    private String comment;
    private String team1Name;
    private String team2Name;
    private List<OlimpbetOutcome> outcomes;
}
