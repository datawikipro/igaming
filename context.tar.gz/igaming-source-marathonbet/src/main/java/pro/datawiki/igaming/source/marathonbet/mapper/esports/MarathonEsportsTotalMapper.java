package pro.datawiki.igaming.source.marathonbet.mapper.esports;

import org.springframework.stereotype.Component;
import pro.datawiki.igaming.dto.BetType;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.dto.market.BetScope;
import pro.datawiki.igaming.dto.market.BetSubject;
import pro.datawiki.igaming.dto.market.StatType;
import pro.datawiki.igaming.source.core.mapper.AbstractBetTypeMapper;

@Component
public class MarathonEsportsTotalMapper extends AbstractBetTypeMapper {

    @Override
    public boolean supports(String bookmaker, SportType sportType) {
        return "marathonbet".equals(bookmaker) && (sportType == SportType.ESPORTS || sportType == SportType.CYBER_FOOTBALL || sportType == SportType.CYBER_BASKETBALL || sportType == SportType.CYBER_HOCKEY);
    }

    @Override
    public BetType map(String m, String o) {
        if (m == null || o == null) return null;
        String upperM = m.toUpperCase().trim();
        String upperO = o.toUpperCase().trim();

        if (upperM.contains("TOTAL")) {
            BetScope scope = BetScope.FULL_MATCH;
            StatType statType = StatType.MATCH;

            if (upperM.contains("MAPS")) statType = StatType.MAPS;
            else if (upperM.contains("ROUNDS")) statType = StatType.ROUNDS;
            else if (upperM.contains("KILLS")) statType = StatType.KILLS;

            if (upperM.contains("1ST_MAP")) scope = BetScope.MAP_1;
            
            return mapTotalRecord(upperO, scope, BetSubject.MATCH, statType, upperM.contains("ASIAN"));
        }

        return null;
    }
}
