package pro.datawiki.igaming.dto.market;

public enum BetSubject {
    MATCH(""),
    TEAM1("TEAM1_"),
    TEAM2("TEAM2_");

    private final String prefix;

    BetSubject(String prefix) {
        this.prefix = prefix;
    }

    public String prefix() {
        return prefix;
    }
}
