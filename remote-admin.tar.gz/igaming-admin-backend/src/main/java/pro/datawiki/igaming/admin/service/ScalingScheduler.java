package pro.datawiki.igaming.admin.service;

import io.fabric8.kubernetes.api.model.batch.v1.Job;
import io.fabric8.kubernetes.client.KubernetesClient;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import pro.datawiki.igaming.admin.entity.ManagedInstance;
import pro.datawiki.igaming.admin.repository.ManagedInstanceRepository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class ScalingScheduler {

    private final SmartScalingService scalingService;
    private final GcpHardwareService hardwareService;
    private final GeoScalingBalancerService geoScalingBalancerService;
    private final KubernetesClient kubernetesClient;
    private final ManagedInstanceRepository instanceRepository;

    /**
     * Reconcile current state with desired state every 2 minutes.
     */
    @Scheduled(fixedRate = 120000)
    public void reconcileTask() {
        log.info("Starting scheduled reconciliation task...");
        scalingService.reconcile();
        syncDatabaseWithGcp();
    }

    /**
     * Every 30 minutes, try to replace Standard (Fallback) instances with Spot for LOADERS.
     */
    @Scheduled(fixedRate = 1800000)
    public void rotationTask() {
        log.info("Starting scheduled Spot rotation task for Loaders...");
        Map<String, GcpHardwareService.GcpNodeInfo> hardware = hardwareService.getGcpInstancesInfo();
        java.util.List<ManagedInstance> allManaged = instanceRepository.findAll();
        
        for (ManagedInstance m : allManaged) {
            if ("LOADER".equalsIgnoreCase(m.getRole()) && 
                "STANDARD".equalsIgnoreCase(m.getProvisioningModel()) && 
                hardware.containsKey(m.getInstanceName())) {
                
                log.info("Attempting to migrate fallback Loader {} to Spot", m.getInstanceName());
                geoScalingBalancerService.terminateInstance(m.getInstanceName());
                geoScalingBalancerService.provisionNode("ANY", "SPOT", "LOADER", "e2-custom-4-16384", false);
            }
        }
    }

    /**
     * Every 5 minutes, clean up stuck provisioning records in DB.
     */
    @Scheduled(fixedRate = 300000)
    public void cleanupTask() {
        log.info("Checking for failed/stuck provisioning records...");
        List<ManagedInstance> provisioning = instanceRepository.findByStatus("PROVISIONING");
        
        for (ManagedInstance inst : provisioning) {
            // If stuck in PROVISIONING for more than 15 minutes, it's likely failed
            if (inst.getCreatedAt().isBefore(LocalDateTime.now().minusMinutes(15))) {
                log.warn("Instance {} stuck in PROVISIONING for too long, terminating in GCP and removing record", inst.getInstanceName());
                try {
                    geoScalingBalancerService.terminateInstance(inst.getInstanceName());
                } catch (Exception e) {
                    log.error("Failed to terminate GCP instance {} during PROVISIONING cleanup: {}", inst.getInstanceName(), e.getMessage());
                }
                instanceRepository.delete(inst);
            }
        }
    }

    /**
     * Every 5 minutes, clean up NotReady spot nodes from GCP and Kubernetes.
     */
    @Scheduled(fixedRate = 300000)
    public void removeNotReadySpotNodesTask() {
        log.info("Checking for NotReady spot nodes...");
        try {
            kubernetesClient.nodes().list().getItems().forEach(node -> {
                Map<String, String> labels = node.getMetadata().getLabels();
                if (labels == null || !"spot".equals(labels.get("node-type"))) {
                    return;
                }

                boolean isNotReady = false;
                String lastTransitionTimeStr = null;

                if (node.getStatus() == null || node.getStatus().getConditions() == null || node.getStatus().getConditions().isEmpty()) {
                    isNotReady = true;
                    // If no conditions exist, we'll check the node's creation timestamp instead
                    lastTransitionTimeStr = node.getMetadata().getCreationTimestamp();
                } else {
                    java.util.Optional<io.fabric8.kubernetes.api.model.NodeCondition> readyCondition = node.getStatus().getConditions().stream()
                            .filter(c -> "Ready".equals(c.getType()))
                            .findFirst();

                    if (readyCondition.isEmpty()) {
                        isNotReady = true;
                        lastTransitionTimeStr = node.getMetadata().getCreationTimestamp();
                    } else {
                        isNotReady = "False".equals(readyCondition.get().getStatus()) || "Unknown".equals(readyCondition.get().getStatus());
                        lastTransitionTimeStr = readyCondition.get().getLastTransitionTime();
                    }
                }

                if (isNotReady) {
                    String nodeName = node.getMetadata().getName();
                    
                    // Check if it's been NotReady for more than 5 minutes to avoid terminating nodes that are just joining
                    if (lastTransitionTimeStr != null) {
                        try {
                            java.time.ZonedDateTime transitionTime = java.time.ZonedDateTime.parse(lastTransitionTimeStr);
                            if (transitionTime.plusMinutes(5).isAfter(java.time.ZonedDateTime.now(java.time.ZoneOffset.UTC))) {
                                log.info("Node {} is NotReady, but recently transitioned. Skipping.", nodeName);
                                return;
                            }
                        } catch (Exception e) {
                            log.warn("Failed to parse transition time for node {}: {}", nodeName, e.getMessage());
                        }
                    }

                    log.warn("Node {} is NotReady for too long. Terminating it from GCP and K8s.", nodeName);
                    
                    // 1. Delete from GCP
                    try {
                        geoScalingBalancerService.terminateInstance(nodeName);
                    } catch (Exception e) {
                        log.error("Failed to terminate GCP instance {}: {}", nodeName, e.getMessage());
                    }
                    
                    // 2. Delete from Kubernetes
                    try {
                        kubernetesClient.nodes().withName(nodeName).delete();
                    } catch (Exception e) {
                        log.error("Failed to delete K8s node {}: {}", nodeName, e.getMessage());
                    }
                }
            });
        } catch (Exception e) {
            log.error("Failed to fetch nodes for NotReady cleanup: {}", e.getMessage());
        }
    }

    @Transactional
    public void syncDatabaseWithGcp() {
        Map<String, GcpHardwareService.GcpNodeInfo> gcpInstances = hardwareService.getGcpInstancesInfo();
        List<ManagedInstance> dbInstances = instanceRepository.findAll();

        for (ManagedInstance dbInstance : dbInstances) {
            // Don't remove masters or provisioning/terminating ones prematurely
            if ("ACTIVE".equals(dbInstance.getStatus()) && !gcpInstances.containsKey(dbInstance.getInstanceName())) {
                log.warn("Instance {} found in DB as ACTIVE but not in GCP. Removing orphaned record.", dbInstance.getInstanceName());
                instanceRepository.delete(dbInstance);
            }
        }

        // Identify orphaned GCP instances that are not in K8s and not tracked properly in DB
        try {
            List<String> k8sNodeNames = kubernetesClient.nodes().list().getItems().stream()
                    .map(n -> n.getMetadata().getName())
                    .toList();

            for (Map.Entry<String, GcpHardwareService.GcpNodeInfo> entry : gcpInstances.entrySet()) {
                String instanceName = entry.getKey();
                GcpHardwareService.GcpNodeInfo info = entry.getValue();

                if ("RUNNING".equalsIgnoreCase(info.status()) && "Spot".equalsIgnoreCase(info.scheduling())) {
                    boolean inK8s = k8sNodeNames.contains(instanceName);
                    boolean inDb = dbInstances.stream().anyMatch(dbInst -> dbInst.getInstanceName().equals(instanceName));

                    if (!inK8s && !inDb) {
                        log.warn("ZOMBIE INSTANCE DETECTED: GCP Spot Instance {} is RUNNING but not in K8s and not in DB! Terminating...", instanceName);
                        try {
                            geoScalingBalancerService.terminateInstance(instanceName);
                        } catch (Exception e) {
                            log.error("Failed to terminate orphaned zombie GCP instance {}: {}", instanceName, e.getMessage());
                        }
                    }
                }
            }
        } catch (Exception e) {
            log.error("Failed to perform zombie GCP instance cleanup: {}", e.getMessage());
        }
    }
}
