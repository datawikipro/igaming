package pro.datawiki.igaming.dto.market;

import pro.datawiki.igaming.dto.BetType;

public record HandicapBet(
        BetScope scope,
        Team team,
        double param,
        boolean isAsian,
        StatType statType
) implements BetType {

    public enum Team { TEAM1, TEAM2 }

    @Override
    public String code() {
        return scope.prefix() + (statType != null ? statType.prefix() : "") + (isAsian ? "ASIAN_" : "") + "HANDICAP_" + (team == Team.TEAM1 ? "1" : "2") + "_" + param;
    }

    @Override
    public String marketCode() {
        return scope.prefix() + (statType != null ? statType.prefix() : "") + (isAsian ? "ASIAN_" : "") + "HANDICAP";
    }

    @Override
    public String description() {
        return "Handicap " + team + " " + param;
    }

    @Override
    public boolean isParametric() {
        return true;
    }

    @Override
    public BetType withParam(double param) {
        return new HandicapBet(scope, team, param, isAsian, statType);
    }

    @Override
    public Double getParam() {
        return param;
    }
}
