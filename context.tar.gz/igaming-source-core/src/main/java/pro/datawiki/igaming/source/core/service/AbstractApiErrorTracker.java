package pro.datawiki.igaming.source.core.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

@Slf4j
public abstract class AbstractApiErrorTracker {

    private final Map<String, AtomicInteger> errorCounts = new ConcurrentHashMap<>();
    private final AtomicInteger totalAttempts = new AtomicInteger(0);
    private final AtomicInteger totalErrors = new AtomicInteger(0);

    protected abstract String getSourceName();

    public void recordAttempt() {
        totalAttempts.incrementAndGet();
    }

    public void recordError(String errorReason) {
        totalErrors.incrementAndGet();
        
        String reason = errorReason != null ? errorReason : "Unknown error";
        if (reason.length() > 100) {
            reason = reason.substring(0, 100) + "...";
        }
        
        errorCounts.computeIfAbsent(reason, k -> new AtomicInteger(0)).incrementAndGet();
    }

    protected pro.datawiki.igaming.source.core.repository.MatchCacheRepository matchCacheRepository;

    public void setMatchCacheRepository(pro.datawiki.igaming.source.core.repository.MatchCacheRepository matchCacheRepository) {
        this.matchCacheRepository = matchCacheRepository;
    }

    public void reportErrors() {
        reportApiErrors();
        reportMatchStats();
    }

    private void reportApiErrors() {
        int attempts = totalAttempts.getAndSet(0);
        int errors = totalErrors.getAndSet(0);
        
        if (attempts == 0 && errors == 0) {
            return;
        }

        if (errors > 0) {
            Map<String, Integer> currentErrors = new ConcurrentHashMap<>();
            errorCounts.forEach((k, v) -> {
                int count = v.getAndSet(0);
                if (count > 0) {
                    currentErrors.put(k, count);
                }
            });
            
            log.warn("{} API fetch stats: failed to load {} out of {} pages in the last cycle. Reasons: {}",
                    getSourceName(), errors, attempts, currentErrors);
        } else {
            log.debug("{} API fetch stats: successfully loaded {} pages.", getSourceName(), attempts);
        }
    }

    private void reportMatchStats() {
        if (matchCacheRepository == null) {
            return;
        }
        
        try {
            long total = matchCacheRepository.count();
            if (total == 0) return;

            long newMatches = matchCacheRepository.countByStatus(pro.datawiki.igaming.source.core.domain.MatchCache.Status.NEW);
            long pendingMatches = matchCacheRepository.countByStatus(pro.datawiki.igaming.source.core.domain.MatchCache.Status.PENDING);
            long processedMatches = matchCacheRepository.countByStatus(pro.datawiki.igaming.source.core.domain.MatchCache.Status.PROCESSED);
            long failedMatches = matchCacheRepository.countByStatus(pro.datawiki.igaming.source.core.domain.MatchCache.Status.FAILED);
            
            log.info("{} DB Stats: Total={}, NEW={}, PENDING={}, PROCESSED={}, FAILED={}",
                    getSourceName(), total, newMatches, pendingMatches, processedMatches, failedMatches);
        } catch (Exception e) {
            log.error("Failed to report match stats for {}: {}", getSourceName(), e.getMessage());
        }
    }
}
