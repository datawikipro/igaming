package pro.datawiki.igaming.source.core.mapper;

import pro.datawiki.igaming.dto.BetType;
import pro.datawiki.igaming.dto.market.BetScope;
import pro.datawiki.igaming.dto.market.BetSubject;
import pro.datawiki.igaming.dto.market.MatchResultBet;
import pro.datawiki.igaming.dto.market.StatType;
import pro.datawiki.igaming.dto.market.TotalBet;

public abstract class AbstractBetTypeMapper implements BetTypeMapper {

    protected BetType map1X2Record(String o, BetScope scope, StatType statType) {
        if (o == null) return null;
        String upper = o.toUpperCase().trim();
        return switch (upper) {
            case "1", "HOME", "П1", "P1", "W1", "ПОБЕДА 1" -> new MatchResultBet(scope, MatchResultBet.Outcome.WIN1, statType);
            case "DRAW", "X", "НИЧЬЯ", "Х" -> new MatchResultBet(scope, MatchResultBet.Outcome.DRAW, statType);
            case "2", "3", "AWAY", "П2", "P2", "W2", "ПОБЕДА 2" -> new MatchResultBet(scope, MatchResultBet.Outcome.WIN2, statType);
            default -> null;
        };
    }

    protected BetType map1X2DCRecord(String o, BetScope scope, StatType statType) {
        BetType basic = map1X2Record(o, scope, statType);
        if (basic != null) return basic;
        if (o == null) return null;
        String upper = o.toUpperCase().trim();
        return switch (upper) {
            case "HD", "1X", "1Х", "П1Х", "1-X" -> new MatchResultBet(scope, MatchResultBet.Outcome.DC_1X, statType);
            case "HA", "12", "П1П2", "1-2" -> new MatchResultBet(scope, MatchResultBet.Outcome.DC_12, statType);
            case "AD", "X2", "Х2", "ПХ2", "X-2" -> new MatchResultBet(scope, MatchResultBet.Outcome.DC_X2, statType);
            default -> null;
        };
    }

    protected BetType mapTotalRecord(String o, BetScope scope, BetSubject subject, StatType statType, boolean isAsian) {
        if (o == null) return null;
        String upper = o.toUpperCase().trim();
        TotalBet.Direction dir;
        if (upper.startsWith("OVER") || "O".equals(upper) || upper.startsWith("БОЛЬШЕ") || upper.equals("Б") || upper.equals("ТБ") || upper.equals("TB") || upper.startsWith("TOTБ")) dir = TotalBet.Direction.OVER;
        else if (upper.startsWith("UNDER") || "U".equals(upper) || upper.startsWith("МЕНЬШЕ") || upper.equals("М") || upper.equals("ТМ") || upper.equals("TM") || upper.startsWith("TOTМ")) dir = TotalBet.Direction.UNDER;
        else if (upper.startsWith("EXACT") || "EXACTLY".equals(upper) || upper.matches("\\d+")) dir = TotalBet.Direction.EXACT;
        else return null;
        return new TotalBet(scope, subject, dir, 0.0, isAsian, statType);
    }

    protected BetType mapCorrectScoreRecord(String label, BetScope scope) {
        if (label == null || label.isEmpty()) return null;
        
        String upperLabel = label.toUpperCase();
        if (upperLabel.contains("ANY OTHER") || upperLabel.contains("ЛЮБОЙ ДРУГОЙ")) {
            return new pro.datawiki.igaming.dto.market.CorrectScoreBet(scope, 0, 0, true);
        }
        
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(\\d+)\\s*[:-]\\s*(\\d+)").matcher(label);
        if (m.find()) {
            try {
                int s1 = Integer.parseInt(m.group(1));
                int s2 = Integer.parseInt(m.group(2));
                return new pro.datawiki.igaming.dto.market.CorrectScoreBet(scope, s1, s2, false);
            } catch (NumberFormatException ignored) {}
        }
        return null;
    }

    protected BetType mapHandicapRecord(String o, BetScope scope, StatType statType, boolean isAsian) {
        if (o == null) return null;
        String upper = o.toUpperCase().trim();
        pro.datawiki.igaming.dto.market.HandicapBet.Team team;
        if (upper.startsWith("1") || upper.contains("HOME") || upper.contains("HB_H") || upper.contains("HB_ASN_H") || upper.contains("Ф1") || upper.contains("ФОРА 1") || upper.contains("ДФ1К")) team = pro.datawiki.igaming.dto.market.HandicapBet.Team.TEAM1;
        else if (upper.startsWith("2") || upper.startsWith("3") || upper.contains("AWAY") || upper.contains("HB_A") || upper.contains("HB_ASN_A") || upper.contains("Ф2") || upper.contains("ФОРА 2") || upper.contains("ДФ2К")) team = pro.datawiki.igaming.dto.market.HandicapBet.Team.TEAM2;
        else return null;
        return new pro.datawiki.igaming.dto.market.HandicapBet(scope, team, 0.0, isAsian, statType);
    }

    protected BetType mapOddEvenRecord(String o, BetScope scope, StatType statType) {
        if (o == null) return null;
        String upper = o.toUpperCase().trim();
        pro.datawiki.igaming.dto.market.BinaryMarketBet.Outcome outcome;
        if (upper.equals("ODD") || upper.equals("НЕЧЕТ") || upper.equals("НЕЧЕТНЫЙ") || upper.equals("Н") || upper.contains("ODD")) outcome = pro.datawiki.igaming.dto.market.BinaryMarketBet.Outcome.ODD;
        else if (upper.equals("EVEN") || upper.equals("ЧЕТ") || upper.equals("ЧЕТНЫЙ") || upper.equals("Ч") || upper.contains("EVEN")) outcome = pro.datawiki.igaming.dto.market.BinaryMarketBet.Outcome.EVEN;
        else return null;
        return new pro.datawiki.igaming.dto.market.BinaryMarketBet(scope, pro.datawiki.igaming.dto.market.BetSubject.MATCH, pro.datawiki.igaming.dto.market.BinaryMarketBet.MarketType.ODD_EVEN, outcome, statType);
    }
}

