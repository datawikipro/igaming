package pro.datawiki.igaming.source.core.engine.zenit.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ZenitLeague {
    private String nm;
    private List<Integer> games;
}
