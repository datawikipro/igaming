package pro.datawiki.igaming.source.core.engine.betcity.mapper;

import org.springframework.stereotype.Component;
import pro.datawiki.igaming.dto.BetType;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.dto.market.BetScope;
import pro.datawiki.igaming.dto.market.BetSubject;
import pro.datawiki.igaming.dto.market.StatType;
import pro.datawiki.igaming.dto.market.TotalBet;
import pro.datawiki.igaming.source.core.mapper.AbstractBetTypeMapper;

@Component
public class BetcityHockeyTotalMapper extends AbstractBetTypeMapper {

    @Override
    public boolean supports(String bookmaker, SportType sportType) {
        return bookmaker != null && bookmaker.toLowerCase().contains("betcity") && sportType == SportType.HOCKEY;
    }

    @Override
    public BetType map(String m, String o) {
        if (m == null || o == null) return null;
        String group = m.toLowerCase().trim();
        String outcome = o.toUpperCase().trim();

        if (group.contains("тотал")) {
            BetScope scope = resolveScope(group);
            if (scope != null) {
                if (outcome.startsWith("БО") || outcome.equals("OVER") || outcome.equals("Б")) 
                    return new TotalBet(scope, BetSubject.MATCH, TotalBet.Direction.OVER, 0.0, false, StatType.MATCH);
                if (outcome.startsWith("МЕ") || outcome.equals("UNDER") || outcome.equals("М")) 
                    return new TotalBet(scope, BetSubject.MATCH, TotalBet.Direction.UNDER, 0.0, false, StatType.MATCH);
            }
            
            if (group.contains("с учетом от") || group.contains("incl. ot")) {
                if (outcome.startsWith("БО") || outcome.equals("OVER") || outcome.equals("Б")) 
                    return new TotalBet(BetScope.FULL_MATCH_INCLUDING_OT, BetSubject.MATCH, TotalBet.Direction.OVER, 0.0, false, StatType.MATCH);
                if (outcome.startsWith("МЕ") || outcome.equals("UNDER") || outcome.equals("М")) 
                    return new TotalBet(BetScope.FULL_MATCH_INCLUDING_OT, BetSubject.MATCH, TotalBet.Direction.UNDER, 0.0, false, StatType.MATCH);
            }
        }

        return null;
    }

    private BetScope resolveScope(String group) {
        if (group.contains("1-й период")) return BetScope.PERIOD_1;
        if (group.contains("2-й период")) return BetScope.PERIOD_2;
        if (group.contains("3-й период")) return BetScope.PERIOD_3;
        return null;
    }
}
