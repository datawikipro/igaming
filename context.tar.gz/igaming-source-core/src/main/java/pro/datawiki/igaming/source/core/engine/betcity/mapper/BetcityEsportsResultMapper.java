package pro.datawiki.igaming.source.core.engine.betcity.mapper;

import org.springframework.stereotype.Component;
import pro.datawiki.igaming.dto.BetType;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.dto.market.BetScope;
import pro.datawiki.igaming.dto.market.MatchResultBet;
import pro.datawiki.igaming.dto.market.StatType;
import pro.datawiki.igaming.source.core.mapper.AbstractBetTypeMapper;

import static pro.datawiki.igaming.dto.market.MatchResultBet.Outcome.*;

@Component
public class BetcityEsportsResultMapper extends AbstractBetTypeMapper {

    @Override
    public boolean supports(String bookmaker, SportType sportType) {
        return bookmaker != null && bookmaker.toLowerCase().contains("betcity") && (sportType == SportType.ESPORTS || sportType == SportType.CYBER_FOOTBALL || sportType == SportType.CYBER_BASKETBALL || sportType == SportType.CYBER_HOCKEY);
    }

    @Override
    public BetType map(String m, String o) {
        if (m == null || o == null) return null;
        String group = m.toLowerCase().trim();
        String outcome = o.toUpperCase().trim();

        if (group.contains("исход") || group.contains("результат") || group.contains("победитель")) {
            BetScope scope = BetScope.FULL_MATCH;
            if (group.contains("1-я карта") || group.contains("1-я карта")) scope = BetScope.MAP_1;
            else if (group.contains("2-я карта")) scope = BetScope.MAP_2;
            else if (group.contains("3-я карта")) scope = BetScope.MAP_3;

            if (outcome.matches("1|П1|P1")) return new MatchResultBet(scope, WIN1, StatType.MATCH);
            if (outcome.matches("2|П2|P2")) return new MatchResultBet(scope, WIN2, StatType.MATCH);
        }
        return null;
    }
}
