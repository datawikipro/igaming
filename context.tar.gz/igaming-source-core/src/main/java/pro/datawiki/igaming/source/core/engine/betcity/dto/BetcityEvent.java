package pro.datawiki.igaming.source.core.engine.betcity.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.Data;
import java.io.IOException;
import java.util.Map;
import com.fasterxml.jackson.databind.JavaType;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonDeserialize(using = BetcityEvent.Deserializer.class)
public class BetcityEvent {
    @JsonProperty("id_ev")
    private Integer idEv;
    
    @JsonProperty("name_ht")
    private String nameHt;
    
    @JsonProperty("name_at")
    private String nameAt;
    
    @JsonProperty("date_ev")
    private Long dateEv;
    
    @JsonProperty("sc_ev")
    private String scEv;
    
    private Map<String, BetcityMain> main;
    private Map<String, BetcityMain> ext;

    public static class Deserializer extends JsonDeserializer<BetcityEvent> {
        @Override
        public BetcityEvent deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
            if (p.currentToken() == JsonToken.START_OBJECT) {
                JsonNode node = p.getCodec().readTree(p);
                BetcityEvent event = new BetcityEvent();
                if (node.has("id_ev") && !node.get("id_ev").isNull()) event.setIdEv(node.get("id_ev").asInt());
                if (node.has("name_ht") && !node.get("name_ht").isNull()) event.setNameHt(node.get("name_ht").asText());
                if (node.has("name_at") && !node.get("name_at").isNull()) event.setNameAt(node.get("name_at").asText());
                if (node.has("date_ev") && !node.get("date_ev").isNull()) event.setDateEv(node.get("date_ev").asLong());
                if (node.has("sc_ev") && !node.get("sc_ev").isNull()) event.setScEv(node.get("sc_ev").asText());
                if (node.has("main") && !node.get("main").isNull()) {
                    JavaType type = ctxt.getTypeFactory().constructMapType(Map.class, String.class, BetcityMain.class);
                    event.setMain(ctxt.readTreeAsValue(node.get("main"), type));
                }
                if (node.has("ext") && !node.get("ext").isNull()) {
                    JavaType type = ctxt.getTypeFactory().constructMapType(Map.class, String.class, BetcityMain.class);
                    event.setExt(ctxt.readTreeAsValue(node.get("ext"), type));
                }
                return event;
            }
            p.skipChildren();
            return null;
        }
    }
}
