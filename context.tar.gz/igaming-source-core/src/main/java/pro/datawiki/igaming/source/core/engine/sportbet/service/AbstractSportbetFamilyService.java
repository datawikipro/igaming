package pro.datawiki.igaming.source.core.engine.sportbet.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import pro.datawiki.igaming.dto.OddItem;
import pro.datawiki.igaming.dto.OddsUpdateRequest;
import pro.datawiki.igaming.source.core.aggregator.AggregatorClient;
import pro.datawiki.igaming.source.core.domain.MatchCache;
import pro.datawiki.igaming.source.core.domain.MatchFactor;
import pro.datawiki.igaming.source.core.engine.sportbet.dto.*;
import pro.datawiki.igaming.source.core.repository.MatchCacheRepository;
import pro.datawiki.igaming.source.core.repository.SportCacheRepository;
import pro.datawiki.igaming.source.core.service.UnmappedBetService;
import pro.datawiki.igaming.source.core.validation.JsonValidationService;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.dto.BetType;
import pro.datawiki.igaming.source.core.service.SportNormalizationService;
import pro.datawiki.igaming.source.core.service.BetTypeResolverService;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.LocalDateTime;
import java.util.*;

@Slf4j
public abstract class AbstractSportbetFamilyService {

    protected final MatchCacheRepository matchCacheRepository;
    protected final SportCacheRepository sportCacheRepository;
    protected final AggregatorClient aggregatorClient;
    protected final ObjectMapper objectMapper;
    protected final JsonValidationService jsonValidationService;
    protected final UnmappedBetService unmappedBetService;
    protected final SportNormalizationService sportNormalizationService;
    protected final BetTypeResolverService betTypeResolver;

    public AbstractSportbetFamilyService(MatchCacheRepository matchCacheRepository,
                                        SportCacheRepository sportCacheRepository,
                                        AggregatorClient aggregatorClient,
                                        ObjectMapper objectMapper,
                                        JsonValidationService jsonValidationService,
                                        UnmappedBetService unmappedBetService,
                                        SportNormalizationService sportNormalizationService,
                                        BetTypeResolverService betTypeResolver) {
        this.matchCacheRepository = matchCacheRepository;
        this.sportCacheRepository = sportCacheRepository;
        this.aggregatorClient = aggregatorClient;
        this.objectMapper = objectMapper;
        this.jsonValidationService = jsonValidationService;
        this.unmappedBetService = unmappedBetService;
        this.sportNormalizationService = sportNormalizationService;
        this.betTypeResolver = betTypeResolver;
    }

    @Value("${app.bookmaker.name:sportbet}")
    protected String bookmakerName;

    @Value("${app.bookmaker.region:ru}")
    protected String region;

    /**
     * Discovery role: processes the full line JSON and saves metadata to MatchCache.
     */
    public int discoverEvents(String json, boolean isLive) {
        if (json == null || json.isEmpty()) {
            return 0;
        }

        // 1. Strict JSON Schema Validation
        try {
            jsonValidationService.validate(json, "sportbet-schema.json");
        } catch (Exception e) {
            String snippet = json.length() > 1000 ? json.substring(0, 1000) + "..." : json;
            log.error("CRITICAL: Sportbet API structure changed! Skipping discovery cycle. Error: {}. JSON Snippet: {}", e.getMessage(), snippet);
            return 0;
        }

        SportbetResponse response;
        try {
            response = objectMapper.readValue(json, SportbetResponse.class);
        } catch (Exception e) {
            log.error("Failed to deserialize SportbetResponse: {}", e.getMessage());
            return 0;
        }

        if (response == null || response.getFixtures() == null || response.getFixtures().isEmpty()) {
            return 0;
        }

        int discoveredCount = 0;
        for (Map.Entry<String, SportbetFixture> entry : response.getFixtures().entrySet()) {
            String externalId = entry.getKey();
            SportbetFixture fixture = entry.getValue();

            try {
                saveOrUpdateMatchMetadata(externalId, fixture, response, isLive);
                discoveredCount++;
            } catch (Exception e) {
                log.error("Error saving metadata for Sportbet event {}: {}", externalId, e.getMessage());
            }
        }

        log.info("[{}/{}] Discovered {} {} events", bookmakerName, region, discoveredCount, isLive ? "live" : "prematch");
        return discoveredCount;
    }

    /**
     * Backward-compatible method: simply calls discoverEvents.
     */
    public int processResponse(String json, boolean isLive) {
        return discoverEvents(json, isLive);
    }

    protected final java.util.concurrent.ConcurrentHashMap<String, String> localHashCache = new java.util.concurrent.ConcurrentHashMap<>();
    protected final java.util.concurrent.ConcurrentHashMap<String, Long> localTimeCache = new java.util.concurrent.ConcurrentHashMap<>();

    protected void saveOrUpdateMatchMetadata(String externalId, SportbetFixture fixture, SportbetResponse response, boolean isLive) {
        String jsonPayload;
        try {
            jsonPayload = objectMapper.writeValueAsString(fixture);
        } catch (Exception e) {
            jsonPayload = "{}";
        }

        String newHash = computeHash(jsonPayload);
        String cacheKey = externalId + "_" + isLive;
        if (newHash.equals(localHashCache.get(cacheKey))) {
            return;
        }

        Optional<MatchCache> existing = matchCacheRepository.findByExternalId(externalId);
        MatchCache match = existing.orElseGet(MatchCache::new);
        match.setExternalId(externalId);

        // Resolve Sport via Tournament -> Category -> Sport
        if (fixture.getTid() != null && response.getT() != null) {
            SportbetTournament t = response.getT().get(String.valueOf(fixture.getTid()));
            if (t != null && t.getCid() != null && response.getC() != null) {
                SportbetCategory c = response.getC().get(String.valueOf(t.getCid()));
                if (c != null && c.getSid() != null && response.getS() != null) {
                    SportbetSport s = response.getS().get(String.valueOf(c.getSid()));
                    if (s != null) {
                        match.setSportId(s.getId() != null ? s.getId() : c.getSid());
                        match.setSportName(s.getN() != null ? s.getN() : "Sport_" + c.getSid());
                    } else {
                        match.setSportId(c.getSid());
                        match.setSportName("Sport_" + c.getSid());
                    }
                }
            }
        }

        if (match.getSportName() == null) {
            match.setSportName("UnknownSport_" + fixture.getTid());
        }

        String eventName = String.valueOf(fixture.getExtra().getOrDefault("n", ""));
        if (eventName != null && eventName.contains(" - ")) {
            String[] parts = eventName.split(" - ");
            match.setTeam1(parts[0].trim());
            match.setTeam2(parts.length > 1 ? parts[1].trim() : "Team2");
        } else {
            match.setTeam1(String.valueOf(fixture.getExtra().getOrDefault("team1", "Team1_" + externalId)));
            match.setTeam2(String.valueOf(fixture.getExtra().getOrDefault("team2", "Team2_" + externalId)));
        }

        if (fixture.getD() != null) {
            long ts = fixture.getD();
            if (ts < 10000000000L) ts *= 1000;
            match.setStartTime(ts);
        }

        match.setIsLive(isLive);
        match.setUpdatedAt(LocalDateTime.now());
        if (match.getCreatedAt() == null) {
            match.setCreatedAt(LocalDateTime.now());
        }

        if (match.getPayloadHash() == null || !match.getPayloadHash().equals(newHash)) {
            match.setStatus(MatchCache.Status.NEW);
        }

        match.setJsonPayload(jsonPayload);
        match.setPayloadHash(newHash);
        
        // Relational factors sync
        syncFactors(match, fixture);
        
        matchCacheRepository.save(match);
        localHashCache.put(cacheKey, newHash);
    }

    /**
     * Match-loader worker role: continuously pops the oldest matches from DB and enriches them.
     */
    public int loadMatchCards(int batchSize) {
        List<MatchCache> batch = matchCacheRepository.findAndLockOnlyNewPendingMatches(org.springframework.data.domain.PageRequest.of(0, batchSize));

        if (batch.isEmpty()) return 0;
        int processed = 0;

        for (MatchCache cache : batch) {
            try {
                pushToAggregator(cache);
                
                cache.setStatus(MatchCache.Status.PROCESSED);
                cache.setUpdatedAt(LocalDateTime.now());
                matchCacheRepository.save(cache);
                processed++;
            } catch (Exception e) {
                log.error("Failed to load Sportbet match card for {}: {}", cache.getExternalId(), e.getMessage());
                cache.setStatus(MatchCache.Status.FAILED);
                cache.setUpdatedAt(LocalDateTime.now());
                matchCacheRepository.save(cache);
            }
        }
        return processed;
    }

    protected void pushToAggregator(MatchCache match) {
        SportbetFixture fixture;
        try {
            fixture = objectMapper.readValue(match.getJsonPayload(), SportbetFixture.class);
        } catch (Exception e) {
            log.error("Failed to parse cached payload for {}: {}", match.getExternalId(), e.getMessage());
            return;
        }

        OddsUpdateRequest request = buildOddsUpdateRequest(match, fixture);
        List<OddItem> odds = processOdds(match, fixture, request.getSportType());

        if (!odds.isEmpty()) {
            request.setOdds(odds);
            aggregatorClient.pushOddsUpdate(request);
        }
    }

    private OddsUpdateRequest buildOddsUpdateRequest(MatchCache match, SportbetFixture fixture) {
        OddsUpdateRequest request = new OddsUpdateRequest();
        request.setBookmaker(bookmakerName);
        request.setRegion(region);
        request.setEventUrl(generateEventUrl(match, fixture, match.getIsLive()));
        request.setExternalEventId(match.getExternalId());
        request.setSportName(match.getSportName());
        request.setTeam1(match.getTeam1());
        request.setTeam2(match.getTeam2());
        request.setStartTime(match.getStartTime());
        request.setIsLive(match.getIsLive());
        request.setPayloadHash(match.getPayloadHash());

        SportType sportType = resolveSportbetSportType(match.getSportName());
        request.setSportType(sportType);
        return request;
    }

    private List<OddItem> processOdds(MatchCache match, SportbetFixture fixture, SportType sportType) {
        List<OddItem> odds = new ArrayList<>();
        Map<String, OddItem> resolvedOdds = new HashMap<>();

        if (fixture.getGm() != null) {
            for (SportbetMarketGroup gm : fixture.getGm()) {
                if (gm.getM() != null) {
                    for (SportbetMarket m : gm.getM()) {
                        String marketName = m.getN();
                        if (m.getSel() != null) {
                            for (SportbetSelection sel : m.getSel()) {
                                if (sel.getO() != null) {
                                    BetType betType = betTypeResolver.resolve(bookmakerName, sportType, marketName, 
                                            sel.getN() != null ? String.valueOf(sel.getN()) : null);
                                    
                                    if ("UNKNOWN".equals(betType.code())) {
                                        unmappedBetService.saveAndNotify(bookmakerName, sportType.name(), 
                                                sel.getN() != null ? String.valueOf(sel.getN()) : String.valueOf(sel.getI()), 
                                                marketName, match.getExternalId());
                                        continue;
                                    }

                                    // Inject param into parametric bet types (totals, handicaps)
                                    if (betType.isParametric() && sel.getN() != null) {
                                        try {
                                            String nStr = String.valueOf(sel.getN());
                                            // Extract the first valid number from the name
                                            java.util.regex.Matcher matcher = java.util.regex.Pattern.compile("[-+]?\\d*\\.\\d+|[-+]?\\d+").matcher(nStr);
                                            if (matcher.find()) {
                                                double param = Double.parseDouble(matcher.group());
                                                if (param != 0.0) {
                                                    betType = betType.withParam(param * betType.paramMultiplier());
                                                }
                                            }
                                        } catch (NumberFormatException | UnsupportedOperationException ignored) {}
                                    }

                                    OddItem item = new OddItem();
                                    item.setFactorId(sel.getI() != null ? sel.getI() : 0);
                                    item.setName(sel.getN() != null ? String.valueOf(sel.getN()) : String.valueOf(sel.getI()));
                                    item.setValue(sel.getO());
                                    item.setBetType(betType);

                                    // Semantic duplicate check
                                    String semanticKey = betType.code();
                                    if (resolvedOdds.containsKey(semanticKey)) {
                                        OddItem existing = resolvedOdds.get(semanticKey);
                                        if (!existing.getValue().equals(item.getValue())) {
                                            log.error("DUPLICATE COEFFICIENT ATTEMPT: Tried to map 1 coefficient twice with DIFFERENT values! " +
                                                      "Event={}, SemanticKey={}, ExistingValue={}, NewValue={}, ExistingOriginalName='{}', NewOriginalName='{}'",
                                                      match.getExternalId(), semanticKey, existing.getValue(), item.getValue(),
                                                      existing.getName(), item.getName());
                                        }
                                        continue;
                                    }

                                    resolvedOdds.put(semanticKey, item);
                                    odds.add(item);
                                }
                            }
                        }
                    }
                }
            }
        }
        return odds;
    }

    private void syncFactors(MatchCache match, SportbetFixture fixture) {
        match.getFactors().clear();
        if (fixture.getGm() != null) {
            for (SportbetMarketGroup gm : fixture.getGm()) {
                if (gm.getM() != null) {
                    for (SportbetMarket m : gm.getM()) {
                        if (m.getSel() != null) {
                            for (SportbetSelection sel : m.getSel()) {
                                if (sel.getO() != null) {
                                    MatchFactor factor = new MatchFactor();
                                    factor.setMatch(match);
                                    factor.setFactorId(sel.getI() != null ? sel.getI() : 0);
                                    factor.setName(sel.getN() != null ? String.valueOf(sel.getN()) : String.valueOf(sel.getI()));
                                    factor.setValue(sel.getO());
                                    match.getFactors().add(factor);
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private String computeHash(String content) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(content.getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(hash);
        } catch (Exception e) {
            return String.valueOf(content.hashCode());
        }
    }

    protected SportType resolveSportbetSportType(String sportName) {
        if (sportName == null) return SportType.UNKNOWN;
        
        // Centralized normalization (covers common Russian and English names)
        return sportNormalizationService.normalize(sportName);
    }

    protected abstract String generateEventUrl(MatchCache match, SportbetFixture fixture, boolean isLive);
}
