package pro.datawiki.igaming.source.marathonbet.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import pro.datawiki.igaming.dto.BetType;
import pro.datawiki.igaming.dto.OddItem;
import pro.datawiki.igaming.dto.OddsUpdateRequest;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.source.core.service.BetTypeResolverService;
import pro.datawiki.igaming.source.core.service.SportNormalizationService;
import pro.datawiki.igaming.source.core.service.UnmappedBetService;
import pro.datawiki.igaming.source.marathonbet.dto.marathon.MarathonEvent;
import pro.datawiki.igaming.source.marathonbet.dto.marathon.MarathonOdd;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component
@Slf4j
@RequiredArgsConstructor
public class MarathonOddsMapper {

    private final UnmappedBetService unmappedBetService;
    private final SportNormalizationService sportNormalizationService;
    private final BetTypeResolverService betTypeResolver;
    private final MarathonOddParamNormalizer normalizer;

    private static final Pattern PARAM_PATTERN = Pattern.compile(".*[_\\.]([\\d,\\.]+)$");
    private static final Pattern GROUP_INDEX_PATTERN = Pattern.compile("\\.(\\d+)\\.[^.]+$");
    private static final Pattern STRIP_INDEX_PATTERN = Pattern.compile("([A-Z_])\\d$");
    private static final Pattern SUPPRESS_M_PATTERN = Pattern.compile(".*(IN_BOTH_HALVES|AT_LEAST_ONE_HALF|GOAL_-_|1ST_TO_SCORE|SCORE_DRAW|STAT_|OUTRIGHT_PLACE|WINNING_MARGIN|HALF_TIME_/_FULL_TIME|SET_BETTING|QUARTER_WITH_MOST_POINTS|NUMBER_OF_POINTS_IN_GAME|TO_WIN_POINTS_IN_A_ROW|TO_WIN_.*_SET_BY|RESULT_AFTER_FIRST_K|.*_MAP_RESULT|MOST_3-POINT_FIELD_GOALS|TOTAL_[23]-POINT_FIELD_GOALS|PENALTY_SHOOT-OUT|GAME_TOTAL|SET_\\{0\\}|FIRST_TEAM_TOTAL_POINTS|SECOND_TEAM_TOTAL_POINTS|QUARTER_POINTS|ALLINNINGSGOALS|_INNING_RESULT).*");
    private static final Pattern SUPPRESS_O_PATTERN = Pattern.compile("^(ODD|EVEN|HB_D)$");
    private static final Pattern REFINE_NAME_PATTERN = Pattern.compile("^\\d+\\..*");

    public OddsUpdateRequest buildOddsUpdateRequest(MarathonEvent event) {
        OddsUpdateRequest request = new OddsUpdateRequest();
        request.setBookmaker("marathonbet");
        request.setExternalEventId(event.getEventId());
        request.setSportName(event.getSportName());

        SportType sportType = resolveMarathonSportType(event.getSportName());
        request.setSportType(sportType);

        request.setTeam1(event.getTeam1());
        request.setTeam2(event.getTeam2());
        request.setScore1(event.getScore1());
        request.setScore2(event.getScore2());
        request.setIsLive(event.getIsLive() != null ? event.getIsLive() : false);
        request.setStartTime(event.getStartTime());
        
        // Generate event URL
        request.setEventUrl(String.format("https://www.marathonbet.ru/su/betting/%s", event.getEventId()));
        
        return request;
    }

    public List<OddItem> processOdds(MarathonEvent event, SportType sportType) {
        List<OddItem> oddItems = new ArrayList<>();
        Map<String, OddItem> resolvedOdds = new HashMap<>();

        if (event.getOdds() == null)
            return oddItems;

        for (MarathonOdd o : event.getOdds()) {
            if (o.getValue() == null)
                continue;

            resolveParamFallback(o);
            BetType betType = resolveMarathonBetType(sportType, o);

            if (betType == null)
                continue;

            if ("UNKNOWN".equals(betType.code())) {
                handleUnknownBet(event, o);
                continue;
            }

            if (isInvalidParametricOdd(betType, o))
                continue;

            OddItem item = buildOddItem(o, betType);

            // Deduplication logic for identical source odds
            if (oddItems.stream().anyMatch(i -> i.getFactorId().equals(item.getFactorId()))) {
                continue;
            }

            // Semantic duplicate check
            // For interval/ambiguous markets, include the index from the name to distinguish them
            String keyExtra = "";
            BetType injectedBetType = item.getBetType();
            if (injectedBetType.code().contains("TIME_INTERVAL") || (o.getGroupName() != null && o.getGroupName().matches(".*\\d+.*"))) {
                // Extract index like .8. or .7. from name ADD_xxx.Group.8.Outcome
                Matcher m = GROUP_INDEX_PATTERN.matcher(o.getName());
                if (m.find()) {
                    keyExtra = "_IDX" + m.group(1);
                }
            }

            String semanticKey = injectedBetType.code() + keyExtra;
            if (resolvedOdds.containsKey(semanticKey)) {
                OddItem existing = resolvedOdds.get(semanticKey);
                checkAndLogDuplicate(event.getEventId(), semanticKey, item, existing);

                // User strategy: take the MINIMUM coefficient if multiple are found
                if (item.getValue() < existing.getValue()) {
                    existing.setValue(item.getValue());
                }
                continue;
            }

            resolvedOdds.put(semanticKey, item);
            oddItems.add(item);
        }
        return oddItems;
    }

    private void resolveParamFallback(MarathonOdd o) {
        if (o.getParam() == null || o.getParam() == 0.0) {
            String name = o.getName();
            if (name != null) {
                Matcher m = PARAM_PATTERN.matcher(name);
                if (m.matches()) {
                    try {
                        double parsedParam = Double.parseDouble(m.group(1).replace(',', '.'));
                        parsedParam = normalizer.normalizeParam(name, parsedParam);
                        if (parsedParam != 0.0)
                            o.setParam(parsedParam);
                    } catch (NumberFormatException ignored) {
                    }
                }
            }
        }
    }

    private void handleUnknownBet(MarathonEvent event, MarathonOdd o) {
        String rawTitle = o.getName() != null ? o.getName()
                : (o.getGroupName() != null ? o.getGroupName() + "_UNKNOWN" : "UNKNOWN_BET");
        unmappedBetService.saveAndNotify("marathonbet", event.getSportName(), rawTitle, o.getGroupName(),
                event.getEventId());
    }

    private boolean isInvalidParametricOdd(BetType betType, MarathonOdd o) {
        return betType.isParametric() && (o.getParam() == null || o.getParam() == 0.0);
    }

    private OddItem buildOddItem(MarathonOdd o, BetType betType) {
        OddItem item = new OddItem();
        item.setFactorId(parseFactorId(o.getId(), o.getName(), o.getGroupName()));
        item.setName(o.getName());
        item.setValue(o.getValue());
        
        if (betType.isParametric() && o.getParam() != null) {
            try {
                betType = betType.withParam(o.getParam() * betType.paramMultiplier());
            } catch (UnsupportedOperationException e) {
                // Ignore if it's still a legacy enum
            }
        }
        
        item.setGroupName(o.getGroupName());
        item.setBetType(betType);
        return item;
    }

    private Integer parseFactorId(String id, String name, String groupName) {
        if (id != null && !id.isEmpty()) {
            return id.hashCode() & 0x7FFFFFFF;
        }
        String compositeKey = (groupName != null ? groupName : "") + ":" + (name != null ? name : "");
        return Math.abs(compositeKey.hashCode());
    }

    private BetType resolveMarathonBetType(SportType sportType, MarathonOdd odd) {
        String oddName = odd.getName();
        String groupName = odd.getGroupName();
        String refinedName = refineOddName(oddName);

        int splitDot = refinedName.indexOf('.');
        String m = splitDot >= 0 ? refinedName.substring(0, splitDot).toUpperCase() : refinedName.toUpperCase();
        String o = splitDot >= 0 ? refinedName.substring(splitDot + 1).toUpperCase() : "";

        if (o.matches("\\d+\\..*"))
            o = o.substring(o.indexOf('.') + 1);

        // Strip group index/id prefixes like Total_Goals9 -> Total_Goals
        // Refined to only strip single digits or known indices to avoid breaking things like 'Total_Goals15'
        Matcher stripMatcher = STRIP_INDEX_PATTERN.matcher(m);
        if (stripMatcher.find()) {
            m = stripMatcher.replaceAll("$1");
        }

        if (groupName != null && !groupName.isEmpty()) {
            String upperGroup = groupName.toUpperCase();
            if (upperGroup.contains("1ST HALF") || upperGroup.contains("1-Й ТАЙМ") || upperGroup.contains("1-Й_ТАЙМ") ||
                    upperGroup.contains("1ST-HALF") || upperGroup.contains("1 ST HALF")) {
                if (!m.contains("1ST_HALF") && !m.contains("1-Й_ТАЙМ")) {
                    m = m + "_-_1ST_HALF";
                }
            } else if (upperGroup.contains("2ND HALF") || upperGroup.contains("2-Й ТАЙМ")
                    || upperGroup.contains("2-Й_ТАЙМ") ||
                    upperGroup.contains("2ND-HALF") || upperGroup.contains("2 ND HALF")) {
                if (!m.contains("2ND_HALF") && !m.contains("2-Й_ТАЙМ")) {
                    m = m + "_-_2ND_HALF";
                }
            }
            
            // Inject statistical markers into m
            if (upperGroup.contains("УГЛОВЫЕ") || upperGroup.contains("CORNERS")) {
                m = "CORNERS_" + m;
            } else if (upperGroup.contains("ЖЕЛТЫЕ КАРТОЧКИ") || upperGroup.contains("YELLOW CARDS")) {
                m = "YELLOW_CARDS_" + m;
            } else if (upperGroup.contains("ФОЛЫ") || upperGroup.contains("FOULS")) {
                m = "FOULS_" + m;
            } else if (upperGroup.contains("ОФСАЙДЫ") || upperGroup.contains("OFFSIDES")) {
                m = "OFFSIDES_" + m;
            } else if (upperGroup.contains("УДАРЫ В СТВОР") || upperGroup.contains("SHOTS ON TARGET") || upperGroup.contains("УДАРЫ_В_СТВОР")) {
                m = "ATTEMPTS_ON_TARGET_" + m;
            }
        }
        
        if (m.contains("CORRECT_SCORE") && odd.getLabel() != null) {
            o = odd.getLabel();
        }

        if (isSuppressed(m, o))
            return null;

        return betTypeResolver.resolve("marathonbet", sportType, m, o);
    }

    private String refineOddName(String oddName) {
        if (oddName.startsWith("ADD_")) {
            int dotIndex = oddName.indexOf('.');
            return dotIndex != -1 ? oddName.substring(dotIndex + 1) : oddName;
        }
        if (REFINE_NAME_PATTERN.matcher(oddName).matches()) {
            return oddName.substring(oddName.indexOf('.') + 1);
        }
        return oddName;
    }

    private boolean isSuppressed(String m, String o) {
        return SUPPRESS_M_PATTERN.matcher(m).matches() || SUPPRESS_O_PATTERN.matcher(o).matches();
    }

    private void checkAndLogDuplicate(String eventId, String semanticKey, OddItem newItem, OddItem existingItem) {
        if (!Objects.equals(existingItem.getValue(), newItem.getValue())) {
            if (!Objects.equals(existingItem.getName(), newItem.getName()) || 
                !Objects.equals(existingItem.getGroupName(), newItem.getGroupName())) {
                
                boolean isTechnicalGroup = (newItem.getGroupName() != null && newItem.getGroupName().matches(".*\\d+.*")) ||
                                           (existingItem.getGroupName() != null && existingItem.getGroupName().matches(".*\\d+.*"));
                
                if (isTechnicalGroup) {
                    log.trace("Redundant technical block ignored for Event={}, Key={}: {} vs {}", 
                              eventId, semanticKey, existingItem.getValue(), newItem.getValue());
                } else {
                    log.debug("DUPLICATE COEFFICIENT ATTEMPT: Event={}, Key={}, Existing={}, New={}, ExistingName='{}', NewName='{}', ExistingGroup='{}', NewGroup='{}'",
                              eventId, semanticKey, existingItem.getValue(), newItem.getValue(), 
                              existingItem.getName(), newItem.getName(), existingItem.getGroupName(), newItem.getGroupName());
                }
            } else {
                log.trace("Redundant coefficient ignored for Event={}, Key={}: {} vs {}", 
                          eventId, semanticKey, existingItem.getValue(), newItem.getValue());
            }
        }
    }

    private SportType resolveMarathonSportType(String sportName) {
        if (sportName == null)
            return SportType.UNKNOWN;
        return sportNormalizationService.normalizeAndNotify("marathonbet", sportName);
    }
}
