package pro.datawiki.igaming.source.core.engine.fonbet.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class FonbetEventMisc {
    private Integer id;
    private String score1;
    private String score2;
    private String timer;
    private String comment;
}
