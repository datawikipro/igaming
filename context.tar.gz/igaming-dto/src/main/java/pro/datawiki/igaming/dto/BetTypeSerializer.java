package pro.datawiki.igaming.dto;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;

import java.io.IOException;

/**
 * Jackson serializer: BetType → String code.
 * E.g. MatchResultBet → "WIN1", TotalBet → "TOTAL_OVER"
 */
public class BetTypeSerializer extends JsonSerializer<BetType> {

    @Override
    public void serialize(BetType value, JsonGenerator gen, SerializerProvider serializers) throws IOException {
        if (value == null) {
            gen.writeNull();
        } else {
            gen.writeString(value.code());
        }
    }
}
