package pro.datawiki.igaming.admin;

import com.google.cloud.compute.v1.*;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.api.gax.core.FixedCredentialsProvider;

import java.io.FileInputStream;
import java.util.UUID;
import java.util.List;

public class ProvisionStableWorker {
    public static void main(String[] args) throws Exception {
        String spotProjectId = "project-ec074516-4738-4d28-ad5";
        String spotZone = "europe-north2-b"; 
        String spotCredentialsPath = "C:\\Users\\chernousov_a\\AppData\\Roaming\\gcloud\\legacy_credentials\\developer.usa.test1@gmail.com\\adc.json";
        String tailscaleAuthKey = "tskey-auth-kZotQnypWz11CNTRL-tZfx6Wiowm2GwL6euwP5n2Ti4487uRHab";
        String masterTailscaleIp = "100.86.137.112"; 
        
        String model = "STANDARD";
        String role = "WORKER";
        String machineType = "e2-custom-4-16384";

        String instanceName = "main-worker-gcp"; 
        provisionInstance(spotProjectId, spotZone, spotCredentialsPath, instanceName, machineType, model, role, tailscaleAuthKey, masterTailscaleIp);
    }

    private static void provisionInstance(String projectId, String zone, String credentialsPath, String instanceName, 
                                        String machineType, String model, String role, String tailscaleAuthKey, String masterIp) throws Exception {
        
        System.out.println("Provisioning STABLE GCP instance: " + instanceName);
        String region = zone.substring(0, zone.lastIndexOf("-"));

        String startupScript = "#!/bin/bash\n" +
                "set -e\n" +
                "exec > /var/log/startup-script.log 2>&1\n" +
                "sleep 10\n" +
                "curl -fsSL https://tailscale.com/install.sh | sh\n" +
                "tailscale up --authkey=\"" + tailscaleAuthKey + "\" --ssh\n" +
                "TAILSCALE_IP=$(tailscale ip -4)\n" +
                "curl -sfL https://get.k3s.io | \\\n" +
                "  KUBECONFIG_MODE=\"644\" \\\n" +
                "  K3S_URL=\"https://" + masterIp + ":6443\" \\\n" +
                "  K3S_TOKEN=\"K10c7e23826108f187591e9533b0f508af002ac6670d728c57e0b4919cac2725b15::server:84cc0f96d1b83f1620ba81127b42d739\" \\\n" +
                "  INSTALL_K3S_EXEC=\"agent --node-ip=$TAILSCALE_IP --node-external-ip=$TAILSCALE_IP --node-label=node-type=" + model.toLowerCase() + " --node-label=provisioning=" + model.toLowerCase() + " --node-label=role=" + role.toLowerCase() + " --node-label=provider=gcp\" \\\n" +
                "  sh -\n";

        InstancesSettings.Builder settingsBuilder = InstancesSettings.newBuilder();
        try (FileInputStream fis = new FileInputStream(credentialsPath)) {
            GoogleCredentials credentials = GoogleCredentials.fromStream(fis)
                    .createScoped(List.of("https://www.googleapis.com/auth/cloud-platform"));
            settingsBuilder.setCredentialsProvider(FixedCredentialsProvider.create(credentials));
        }

        try (InstancesClient client = InstancesClient.create(settingsBuilder.build())) {
            Instance instanceResource = Instance.newBuilder()
                    .setName(instanceName)
                    .setMachineType(String.format("projects/%s/zones/%s/machineTypes/%s", projectId, zone, machineType))
                    .setScheduling(Scheduling.newBuilder()
                            .setProvisioningModel("STANDARD")
                            .setPreemptible(false)
                            .build())
                    .addServiceAccounts(ServiceAccount.newBuilder()
                            .setEmail("default")
                            .addAllScopes(List.of("https://www.googleapis.com/auth/cloud-platform"))
                            .build())
                    .addNetworkInterfaces(NetworkInterface.newBuilder()
                            .setNetwork(String.format("projects/%s/global/networks/default", projectId))
                            .setSubnetwork(String.format("projects/%s/regions/%s/subnetworks/default", projectId, region))
                            .addAccessConfigs(AccessConfig.newBuilder()
                                    .setName("External NAT")
                                    .setType(AccessConfig.Type.ONE_TO_ONE_NAT.toString())
                                    .setNetworkTier(AccessConfig.NetworkTier.PREMIUM.toString())
                                    .build())
                            .build())
                    .addDisks(AttachedDisk.newBuilder()
                            .setBoot(true)
                            .setAutoDelete(true)
                            .setType(AttachedDisk.Type.PERSISTENT.toString())
                            .setInitializeParams(AttachedDiskInitializeParams.newBuilder()
                                    .setSourceImage("projects/centos-cloud/global/images/family/centos-stream-9")
                                    .setDiskSizeGb(100L)
                                    .build())
                            .build())
                    .setMetadata(Metadata.newBuilder()
                            .addItems(Items.newBuilder()
                                    .setKey("startup-script")
                                    .setValue(startupScript)
                                    .build())
                            .build())
                    .build();

            Operation response = client.insertAsync(projectId, zone, instanceResource).get();
            if (response.hasError()) {
                System.err.println("Error provisioning " + instanceName + ": " + response.getError());
            } else {
                System.out.println("Successfully provisioned " + instanceName);
            }
        }
    }
}
