package pro.datawiki.igaming.source.marathonbet.mapper.hockey;

import org.springframework.stereotype.Component;
import pro.datawiki.igaming.dto.BetType;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.dto.market.BetScope;
import pro.datawiki.igaming.dto.market.HandicapBet;
import pro.datawiki.igaming.dto.market.StatType;
import pro.datawiki.igaming.source.core.mapper.AbstractBetTypeMapper;

@Component
public class MarathonHockeyHandicapMapper extends AbstractBetTypeMapper {

    @Override
    public boolean supports(String bookmaker, SportType sportType) {
        return "marathonbet".equals(bookmaker) && sportType == SportType.HOCKEY;
    }

    @Override
    public BetType map(String m, String o) {
        if (m == null || o == null) return null;

        // --- Handicap ---
        if (m.matches("^(HANDICAP|HANDICAP_BETTING_POINTS)$")) {
            HandicapBet.Team team = (o.matches("1|HB_H|HB_ASN_H")) ? HandicapBet.Team.TEAM1 : HandicapBet.Team.TEAM2;
            return new HandicapBet(BetScope.FULL_MATCH, team, 0.0, false, StatType.MATCH);
        }

        return null;
    }
}
