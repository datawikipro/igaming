package pro.datawiki.igaming.source.core.service;

/**
 * Callback interface for source services to implement event-specific odds refresh.
 * When the aggregator detects a surebet involving a bookmaker, it puts the event
 * in a refresh queue. The source service's OddsRefreshPoller picks it up and
 * calls this callback to re-fetch odds for that specific event.
 */
public interface RefreshCallback {

    /**
     * Re-fetch odds for a specific event from the bookmaker API and push to aggregator.
     *
     * @param externalEventId the bookmaker's event ID (same as OddsUpdateRequest.externalEventId)
     */
    void refreshEvent(String externalEventId);
}
