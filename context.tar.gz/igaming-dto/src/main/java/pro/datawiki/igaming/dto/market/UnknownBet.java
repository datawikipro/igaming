package pro.datawiki.igaming.dto.market;

import pro.datawiki.igaming.dto.BetType;

/**
 * Fallback implementation for unmapped or unknown bet types.
 */
public record UnknownBet(String rawMarket, String rawOutcome) implements BetType {

    public UnknownBet() {
        this(null, null);
    }

    @Override
    public String code() {
        return "UNKNOWN";
    }

    @Override
    public String marketCode() {
        return "UNKNOWN";
    }

    @Override
    public String description() {
        return "Unknown bet type" + (rawMarket != null ? " (" + rawMarket + " / " + rawOutcome + ")" : "");
    }

    @Override
    public boolean isParametric() {
        return false;
    }
}
