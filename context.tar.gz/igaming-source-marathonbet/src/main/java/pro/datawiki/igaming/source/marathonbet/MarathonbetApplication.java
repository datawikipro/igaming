package pro.datawiki.igaming.source.marathonbet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.cloud.openfeign.EnableFeignClients;

@EnableScheduling
@SpringBootApplication(scanBasePackages = {"pro.datawiki.igaming.source.marathonbet", "pro.datawiki.igaming.source.core"})
@EntityScan(basePackages = {"pro.datawiki.igaming.source.marathonbet.domain", "pro.datawiki.igaming.source.core.domain"})
@EnableJpaRepositories(basePackages = {"pro.datawiki.igaming.source.marathonbet.repository", "pro.datawiki.igaming.source.core.repository"})
@EnableFeignClients
public class MarathonbetApplication {

    public static void main(String[] args) {
        SpringApplication.run(MarathonbetApplication.class, args);
    }
}




