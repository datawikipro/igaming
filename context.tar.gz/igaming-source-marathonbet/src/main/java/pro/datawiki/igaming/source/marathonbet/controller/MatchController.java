package pro.datawiki.igaming.source.marathonbet.controller;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pro.datawiki.igaming.dto.ServiceStatusResponse;
import pro.datawiki.igaming.dto.SourceRefreshResponse;
import pro.datawiki.igaming.dto.SourceStatsResponse;
import pro.datawiki.igaming.source.core.domain.MatchCache;
import pro.datawiki.igaming.source.core.repository.MatchCacheRepository;
import pro.datawiki.igaming.source.marathonbet.service.MatchService;

import java.util.List;

@RestController
@RequestMapping("/api/matches")
@RequiredArgsConstructor
@Slf4j
public class MatchController {

    private final MatchService matchService;
    private final MatchCacheRepository matchCacheRepository;

    @PostMapping("/refresh")
    public ResponseEntity<SourceRefreshResponse> refreshAll() {
        log.info("Manual refresh all requested via API");
        return ResponseEntity.ok(matchService.queueLeagues());
    }

    @PostMapping("/load-url")
    public ResponseEntity<SourceRefreshResponse> loadUrl(@RequestParam String url) {
        log.info("Manual url load triggered for: {}", url);
        return ResponseEntity.ok(matchService.processEventByUrl(url));
    }

    @GetMapping
    public ResponseEntity<List<MatchCache>> getAllMatches() {
        return ResponseEntity.ok(matchCacheRepository.findAll());
    }

    @GetMapping("/live")
    public ResponseEntity<List<MatchCache>> getLiveMatches() {
        return ResponseEntity.ok(matchCacheRepository.findByIsLiveTrue());
    }

    @GetMapping("/sport/{sportName}")
    public ResponseEntity<List<MatchCache>> getMatchesBySport(@PathVariable String sportName) {
        return ResponseEntity.ok(matchCacheRepository.findBySportName(sportName));
    }

    @GetMapping("/stats")
    public ResponseEntity<SourceStatsResponse> getStats() {
        return ResponseEntity.ok(matchService.getStats());
    }

    @GetMapping("/health")
    public ResponseEntity<ServiceStatusResponse> health() {
        return ResponseEntity.ok(ServiceStatusResponse.builder()
                .status("UP")
                .service("igaming-source-marathonbet")
                .build());
    }
}
