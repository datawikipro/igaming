package pro.datawiki.igaming.source.core.engine.betcity.mapper;

import org.springframework.stereotype.Component;
import pro.datawiki.igaming.dto.BetType;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.dto.market.*;
import pro.datawiki.igaming.source.core.mapper.AbstractBetTypeMapper;

@Component
public class BetcityTennisSpecialMapper extends AbstractBetTypeMapper {

    @Override
    public boolean supports(String bookmaker, SportType sportType) {
        return bookmaker != null && bookmaker.toLowerCase().contains("betcity") && sportType == SportType.TENNIS;
    }

    @Override
    public BetType map(String m, String o) {
        if (m == null || o == null) return null;
        String group = m.toLowerCase().trim();
        String outcome = o.toUpperCase().trim();

        // --- Game Handicap ---
        BetScope scope = resolveScope(group);
        if (scope != null && group.contains("фора")) {
            if (outcome.equals("1") || outcome.startsWith("Ф1")) 
                return new HandicapBet(scope, HandicapBet.Team.TEAM1, 0.0, false, StatType.GAMES);
            if (outcome.equals("2") || outcome.startsWith("Ф2")) 
                return new HandicapBet(scope, HandicapBet.Team.TEAM2, 0.0, false, StatType.GAMES);
        }

        // --- Set Handicap ---
        if (group.contains("фора по сетам") || group.contains("handicap sets")) {
             if (outcome.equals("1") || outcome.startsWith("Ф1")) 
                 return new HandicapBet(BetScope.FULL_MATCH, HandicapBet.Team.TEAM1, 0.0, false, StatType.SETS);
             if (outcome.equals("2") || outcome.startsWith("Ф2")) 
                 return new HandicapBet(BetScope.FULL_MATCH, HandicapBet.Team.TEAM2, 0.0, false, StatType.SETS);
        }

        // --- Correct Score ---
        if (group.contains("счет по сетам") || group.contains("set betting")) {
             return new CorrectScoreBet(BetScope.FULL_MATCH, 0, 0, true);
        }

        return null;
    }

    private BetScope resolveScope(String group) {
        if (group.contains("1-й сет")) return BetScope.SET_1;
        if (group.contains("2-й сет")) return BetScope.SET_2;
        if (group.contains("3-й сет")) return BetScope.SET_3;
        return null;
    }
}
