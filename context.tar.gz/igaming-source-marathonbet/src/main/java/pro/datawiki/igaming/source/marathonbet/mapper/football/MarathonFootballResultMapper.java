package pro.datawiki.igaming.source.marathonbet.mapper.football;

import org.springframework.stereotype.Component;
import pro.datawiki.igaming.dto.BetType;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.dto.market.BetScope;
import pro.datawiki.igaming.dto.market.MatchResultBet;
import pro.datawiki.igaming.dto.market.StatType;
import pro.datawiki.igaming.source.core.mapper.AbstractBetTypeMapper;

@Component
public class MarathonFootballResultMapper extends AbstractBetTypeMapper {

    @Override
    public boolean supports(String bookmaker, SportType sportType) {
        return "marathonbet".equals(bookmaker) && sportType == SportType.FOOTBALL;
    }

    @Override
    public BetType map(String m, String o) {
        if (m == null || o == null) return null;
        String upperM = m.toUpperCase().trim();
        String upperO = o.toUpperCase().trim();

        // 1. Match Result (1X2 & Double Chance)
        if (upperM.matches("^(RESULT|MATCH_RESULT|DOUBLE_CHANCE|RESULT_.*|MATCH_RESULT_.*)$")) {
            String cleanO = upperO;
            if (cleanO.startsWith(upperM + ".")) {
                cleanO = cleanO.substring(upperM.length() + 1);
            }
            BetType res = map1X2DCRecord(cleanO, BetScope.FULL_MATCH, StatType.MATCH);
            if (res != null) return res;
            
            return switch (upperO) {
                case "DRAW", "X" -> new MatchResultBet(BetScope.FULL_MATCH, MatchResultBet.Outcome.DRAW, StatType.MATCH);
                case "HD", "1X" -> new MatchResultBet(BetScope.FULL_MATCH, MatchResultBet.Outcome.DC_1X, StatType.MATCH);
                case "HA", "12" -> new MatchResultBet(BetScope.FULL_MATCH, MatchResultBet.Outcome.DC_12, StatType.MATCH);
                case "AD", "X2" -> new MatchResultBet(BetScope.FULL_MATCH, MatchResultBet.Outcome.DC_X2, StatType.MATCH);
                default -> null;
            };
        }
        if ("1".equals(upperM)) return new MatchResultBet(BetScope.FULL_MATCH, MatchResultBet.Outcome.WIN1, StatType.MATCH);
        if ("X".equals(upperM)) return new MatchResultBet(BetScope.FULL_MATCH, MatchResultBet.Outcome.DRAW, StatType.MATCH);
        if ("2".equals(upperM)) return new MatchResultBet(BetScope.FULL_MATCH, MatchResultBet.Outcome.WIN2, StatType.MATCH);

        // 2. Halftime Results
        if (upperM.equals("RESULT_-_1ST_HALF") || upperM.endsWith("_-_1ST_HALF")) {
            if (!upperM.contains("CORNER") && !upperM.contains("CARD")) 
                return map1X2DCRecord(upperO, BetScope.HALF_1, StatType.MATCH);
        }
        if (upperM.equals("RESULT_-_2ND_HALF") || upperM.endsWith("_-_2ND_HALF")) {
            if (!upperM.contains("CORNER") && !upperM.contains("CARD")) 
                return map1X2DCRecord(upperO, BetScope.HALF_2, StatType.MATCH);
        }

        return null;
    }
}
