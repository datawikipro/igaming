package pro.datawiki.igaming.source.core.engine.zenit.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ZenitSport {
    private Integer id;
    private String nm;
}
