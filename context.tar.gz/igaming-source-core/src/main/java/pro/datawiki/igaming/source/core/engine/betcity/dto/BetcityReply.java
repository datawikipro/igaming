package pro.datawiki.igaming.source.core.engine.betcity.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import java.util.Map;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class BetcityReply {
    private Map<String, BetcitySport> sports;
}
