package pro.datawiki.igaming.source.core.engine.fonbet.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class FonbetEvent {
    private Integer id;
    @JsonProperty("sportId")
    private Integer sportId;
    @JsonProperty("tournamentId")
    private Integer tournamentId;
    @JsonProperty("parentId")
    private Integer parentId;
    private String team1;
    private String team2;
    private String name;
    @JsonProperty("startTime")
    private Long startTime;
    private Integer level;
}
