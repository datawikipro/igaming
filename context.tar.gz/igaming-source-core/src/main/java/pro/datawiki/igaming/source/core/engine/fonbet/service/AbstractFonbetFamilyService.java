package pro.datawiki.igaming.source.core.engine.fonbet.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import pro.datawiki.igaming.dto.OddItem;
import pro.datawiki.igaming.dto.OddsUpdateRequest;
import pro.datawiki.igaming.source.core.aggregator.AggregatorClient;
import pro.datawiki.igaming.source.core.domain.MatchCache;
import pro.datawiki.igaming.source.core.domain.SportCache;
import pro.datawiki.igaming.source.core.engine.fonbet.dto.FonbetCustomFactor;
import pro.datawiki.igaming.source.core.engine.fonbet.dto.FonbetEvent;
import pro.datawiki.igaming.source.core.engine.fonbet.dto.FonbetEventMisc;
import pro.datawiki.igaming.source.core.engine.fonbet.dto.FonbetLineResponse;
import pro.datawiki.igaming.source.core.engine.fonbet.dto.FonbetSport;
import pro.datawiki.igaming.source.core.domain.MatchFactor;
import pro.datawiki.igaming.source.core.repository.MatchCacheRepository;
import pro.datawiki.igaming.source.core.repository.MatchFactorRepository;
import pro.datawiki.igaming.source.core.repository.SportCacheRepository;
import pro.datawiki.igaming.source.core.service.UnmappedBetService;
import pro.datawiki.igaming.source.core.validation.JsonValidationService;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.dto.BetType;
import pro.datawiki.igaming.source.core.service.BetTypeResolverService;
import pro.datawiki.igaming.source.core.service.SportNormalizationService;
import pro.datawiki.igaming.source.core.service.AbstractApiErrorTracker;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HexFormat;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Slf4j
public abstract class AbstractFonbetFamilyService {

    protected final MatchCacheRepository matchCacheRepository;
    protected final MatchFactorRepository matchFactorRepository;
    protected final SportCacheRepository sportCacheRepository;
    protected final AggregatorClient aggregatorClient;
    protected final ObjectMapper objectMapper;
    protected final JsonValidationService jsonValidationService;
    protected final UnmappedBetService unmappedBetService;
    protected final SportNormalizationService sportNormalizationService;
    protected final BetTypeResolverService betTypeResolver;
    protected AbstractApiErrorTracker errorTracker;

    public AbstractFonbetFamilyService(MatchCacheRepository matchCacheRepository,
                                     MatchFactorRepository matchFactorRepository,
                                     SportCacheRepository sportCacheRepository,
                                     AggregatorClient aggregatorClient,
                                     ObjectMapper objectMapper,
                                     JsonValidationService jsonValidationService,
                                     UnmappedBetService unmappedBetService,
                                     SportNormalizationService sportNormalizationService,
                                     BetTypeResolverService betTypeResolver) {
        this.matchCacheRepository = matchCacheRepository;
        this.matchFactorRepository = matchFactorRepository;
        this.sportCacheRepository = sportCacheRepository;
        this.aggregatorClient = aggregatorClient;
        this.objectMapper = objectMapper;
        this.jsonValidationService = jsonValidationService;
        this.unmappedBetService = unmappedBetService;
        this.sportNormalizationService = sportNormalizationService;
        this.betTypeResolver = betTypeResolver;
    }

    @Value("${app.bookmaker.name:fonbet}")
    protected String bookmakerName;

    @Value("${app.bookmaker.region:ru}")
    protected String region;

    /**
     * Discovery role: processes a full line response from the API and saves/updates match metadata in DB.
     * Sets status to NEW for further processing by match-loader.
     */
    public int discoverEvents(String rawResponse, boolean isLive) {
        if (rawResponse == null || rawResponse.trim().isEmpty()) {
            return 0;
        }

        // 1. JSON Schema Validation
        try {
            jsonValidationService.validate(rawResponse, "fonbet-schema.json");
        } catch (Exception e) {
            log.error("CRITICAL: Fonbet API structure changed! Validation failed. Details: {}", e.getMessage());
            if (errorTracker != null) {
                errorTracker.recordError("Validation failed: " + e.getMessage());
            }
            return 0; 
        }

        FonbetLineResponse response;
        try {
            response = objectMapper.readValue(rawResponse, FonbetLineResponse.class);
        } catch (Exception e) {
            log.error("Failed to parse Fonbet response after validation: {}", e.getMessage());
            return 0;
        }

        if (response == null) {
            return 0;
        }

        // Index sports by ID and store hierarchy
        Map<Integer, FonbetSport> sportsMap = new HashMap<>();
        if (response.getSports() != null) {
            for (FonbetSport sport : response.getSports()) {
                sportsMap.put(sport.getId(), sport);
                saveSport(sport);
            }
        }

        // Index event miscs by event ID (for scores)
        Map<Integer, FonbetEventMisc> miscsMap = new HashMap<>();
        if (response.getEventMiscs() != null) {
            for (FonbetEventMisc misc : response.getEventMiscs()) {
                miscsMap.put(misc.getId(), misc);
            }
        }

        // Index factors by event ID
        Map<Integer, List<FonbetCustomFactor>> factorsMap = new HashMap<>();
        if (response.getFactors() != null) {
            for (FonbetCustomFactor factor : response.getFactors()) {
                if (factor.getE() == null || factor.getF() == null) continue;
                factorsMap.computeIfAbsent(factor.getE(), k -> new ArrayList<>()).add(factor);
            }
        }
        if (response.getCustomFactors() != null) {
            for (pro.datawiki.igaming.source.core.engine.fonbet.dto.FonbetCustomFactorGroup group : response.getCustomFactors()) {
                Integer eventId = group.getE();
                if (eventId == null || group.getFactors() == null) continue;
                for (FonbetCustomFactor factor : group.getFactors()) {
                    if (factor.getF() == null) continue;
                    factorsMap.computeIfAbsent(eventId, k -> new ArrayList<>()).add(factor);
                }
            }
        }

        // Group events
        Map<Integer, List<FonbetEvent>> childEventsMap = new HashMap<>();
        List<FonbetEvent> rootEvents = new ArrayList<>();
        
        if (response.getEvents() != null) {
            for (FonbetEvent event : response.getEvents()) {
                if (event.getLevel() != null && event.getLevel() > 1) {
                    // Try to resolve exactly to root event (in most cases parentId is the root)
                    Integer parentId = event.getParentId();
                    if (parentId != null) {
                        childEventsMap.computeIfAbsent(parentId, k -> new ArrayList<>()).add(event);
                    }
                } else if (event.getTeam1() != null && event.getTeam2() != null) {
                    rootEvents.add(event);
                }
            }
        }

        // Process root events
        int discoveredCount = 0;
        for (FonbetEvent event : rootEvents) {
            try {
                List<FonbetEvent> childEvents = childEventsMap.getOrDefault(event.getId(), new ArrayList<>());
                saveOrUpdateMatchMetadata(event, childEvents, sportsMap, miscsMap, factorsMap, isLive);
                    discoveredCount++;
            } catch (Exception e) {
                log.error("Error saving metadata for event {}: {}", event.getId(), e.getMessage());
            }
        }

        log.info("[{}/{}] Discovered {} {} events", bookmakerName, region, discoveredCount, isLive ? "live" : "prematch");
        return discoveredCount;
    }

    /**
     * Backward-compatible method: simply calls discoverEvents.
     */
    public int processLineResponse(String rawResponse, boolean isLive) {
        return discoverEvents(rawResponse, isLive);
    }

    protected final java.util.concurrent.ConcurrentHashMap<String, String> localHashCache = new java.util.concurrent.ConcurrentHashMap<>();
    protected final java.util.concurrent.ConcurrentHashMap<String, Long> localTimeCache = new java.util.concurrent.ConcurrentHashMap<>();

    protected void saveOrUpdateMatchMetadata(FonbetEvent event,
                                           List<FonbetEvent> childEvents,
                                           Map<Integer, FonbetSport> sportsMap,
                                           Map<Integer, FonbetEventMisc> miscsMap,
                                           Map<Integer, List<FonbetCustomFactor>> factorsMap,
                                           boolean isLive) {
        String jsonPayload;
        try {
            FonbetSport currentSport = event.getSportId() != null ? sportsMap.get(event.getSportId()) : null;
            FonbetEventMisc misc = miscsMap.get(event.getId());
            Map<String, Object> payload = buildPayload(event, childEvents, currentSport, misc, factorsMap, isLive);
            jsonPayload = objectMapper.writeValueAsString(payload);
        } catch (Exception e) {
            jsonPayload = "{}";
        }

        String newHash = computeHash(jsonPayload);
        String externalId = String.valueOf(event.getId());
        String cacheKey = externalId + "_" + isLive;
        
        long now = System.currentTimeMillis();
        Long lastUpdate = localTimeCache.get(cacheKey);
        if (newHash.equals(localHashCache.get(cacheKey)) && lastUpdate != null && (now - lastUpdate) < 3 * 60 * 1000) {
            return;
        }

        Optional<MatchCache> existing = matchCacheRepository.findByExternalId(externalId);
        MatchCache match = existing.orElseGet(MatchCache::new);
        match.setExternalId(externalId);
        
        Integer sportId = event.getSportId();
        match.setSportId(sportId);
        match.setTeam1(event.getTeam1());
        match.setTeam2(event.getTeam2());
        match.setStartTime(event.getStartTime());
        match.setIsLive(isLive);
        match.setEventUrl(generateEventUrl(match, event, isLive));
        match.setUpdatedAt(LocalDateTime.now());


        if (match.getCreatedAt() == null) {
            match.setCreatedAt(LocalDateTime.now());
        }

        FonbetSport currentSport = sportId != null ? sportsMap.get(sportId) : null;
        if (currentSport != null) {
            FonbetSport rootSport = findRootSport(currentSport, sportsMap);
            match.setSportName(rootSport != null ? rootSport.getName() : currentSport.getName());
            if (rootSport != null && !rootSport.getId().equals(currentSport.getId())) {
                match.setLeagueName(currentSport.getName());
            }
        }

        String format = extractFormat(event, currentSport);
        if (format != null) match.setFormatInfo(format);

        FonbetEventMisc misc = miscsMap.get(event.getId());
        if (misc != null) {
            match.setScore1(misc.getScore1());
            match.setScore2(misc.getScore2());
        }

        if (match.getPayloadHash() == null || !match.getPayloadHash().equals(newHash)) {
            match.setStatus(MatchCache.Status.NEW); // Mark for processing by loader
        }

        match.setJsonPayload(jsonPayload);
        match.setPayloadHash(newHash);
        
        syncFactors(match, event, childEvents, factorsMap);
        matchCacheRepository.saveAndFlush(match);
        localHashCache.put(cacheKey, newHash);
        localTimeCache.put(cacheKey, now);
    }

    /**
     * Match-loader worker role: continuously pops the oldest matches from DB and enriches them.
     */
    @org.springframework.transaction.annotation.Transactional
    public int loadMatchCards(int batchSize) {
        List<MatchCache> batch = matchCacheRepository.findAndLockOnlyNewPendingMatches(org.springframework.data.domain.PageRequest.of(0, batchSize));

        if (batch.isEmpty()) return 0;
        int processed = 0;

        for (MatchCache cache : batch) {
            try {
                // For Fonbet, all odds are already in JSON payload saved during discovery.
                pushToAggregator(cache);
                
                // Use atomic status update to bypass version conflicts and fulfill transaction requirements
                matchCacheRepository.updateStatus(cache.getId(), MatchCache.Status.PROCESSED, LocalDateTime.now());
                processed++;
            } catch (Exception e) {
                log.error("Failed to load match card for {}: {}", cache.getExternalId(), e.getMessage());
                matchCacheRepository.updateStatus(cache.getId(), MatchCache.Status.FAILED, LocalDateTime.now());
            }
        }
        return processed;
    }

    protected void pushToAggregator(MatchCache match) {
        Map<String, Object> payload = null;
        try {
            if (match.getJsonPayload() != null && !match.getJsonPayload().isEmpty()) {
                payload = objectMapper.readValue(match.getJsonPayload(), new com.fasterxml.jackson.core.type.TypeReference<Map<String, Object>>() {});
            }
        } catch (Exception e) {
            log.error("Failed to parse cached payload for {}: {}", match.getExternalId(), e.getMessage());
        }

        if (payload == null) return;

        OddsUpdateRequest request = buildOddsUpdateRequest(match, payload);
        List<OddItem> odds = processOdds(match, payload, request.getSportType());

        if (!odds.isEmpty()) {
            request.setOdds(odds);
            boolean isOutright = (request.getTeam1() == null || request.getTeam1().isEmpty())
                    && (request.getTeam2() == null || request.getTeam2().isEmpty());
            
            if (isOutright) {
                aggregatorClient.pushOutrightUpdate(request);
            } else {
                aggregatorClient.pushOddsUpdate(request);
            }
        }
    }

    private OddsUpdateRequest buildOddsUpdateRequest(MatchCache match, Map<String, Object> payload) {
        OddsUpdateRequest request = new OddsUpdateRequest();
        request.setBookmaker(bookmakerName);
        request.setRegion(region);
        request.setExternalEventId(match.getExternalId());
        request.setSportName(match.getSportName());
        request.setLeagueName(match.getLeagueName());
        request.setTeam1(match.getTeam1());
        request.setTeam2(match.getTeam2());
        request.setScore1(match.getScore1());
        request.setScore2(match.getScore2());
        request.setStartTime(match.getStartTime());
        request.setIsLive(match.getIsLive());
        request.setPayloadHash(match.getPayloadHash());
        request.setFormatInfo(match.getFormatInfo());
        request.setEventUrl(match.getEventUrl());


        SportType sportType = resolveFonbetSportType(match.getSportName());
        request.setSportType(sportType);
        return request;
    }

    private List<OddItem> processOdds(MatchCache match, Map<String, Object> payload, SportType sportType) {
        List<OddItem> odds = new ArrayList<>();
        Map<String, OddItem> resolvedOdds = new HashMap<>();

        if (payload.get("odds") != null) {
            List<Map<String, Object>> payloadOdds = (List<Map<String, Object>>) payload.get("odds");
            for (Map<String, Object> oddMap : payloadOdds) {
                Integer factorId = oddMap.get("factorId") instanceof Number ? ((Number) oddMap.get("factorId")).intValue() : null;
                if (factorId == null) continue;

                Double value = oddMap.get("value") instanceof Number ? ((Number) oddMap.get("value")).doubleValue() : null;
                Double param = oddMap.get("param") instanceof Number ? ((Number) oddMap.get("param")).doubleValue() : null;
                String factorName = (String) oddMap.get("factorName");
                String groupName = (String) oddMap.get("groupName");

                BetType betType = resolveBetType(sportType, factorId, groupName);
                
                if (betType == null || "UNKNOWN".equals(betType.code())) {
                    String rawName = factorName != null ? factorName : "ID:" + factorId;
                    unmappedBetService.saveAndNotify(bookmakerName, sportType.name(), rawName, "FONBET_MAIN", match.getExternalId());
                    continue;
                }

                // Inject param into parametric bet types (totals, handicaps)
                if (betType.isParametric() && param != null && param != 0.0) {
                    try {
                        betType = betType.withParam(param * betType.paramMultiplier());
                    } catch (UnsupportedOperationException e) {
                        log.trace("BetType {} does not support withParam", betType.code());
                    }
                }

                OddItem item = new OddItem();
                item.setFactorId(factorId);
                item.setName(factorName);
                item.setValue(value);
                item.setBetType(betType);

                // Semantic duplicate check
                String semanticKey = betType.code();
                if (resolvedOdds.containsKey(semanticKey)) {
                    OddItem existing = resolvedOdds.get(semanticKey);
                    if (!existing.getValue().equals(item.getValue())) {
                        log.error("DUPLICATE COEFFICIENT ATTEMPT: Tried to map 1 coefficient twice with DIFFERENT values! " +
                                  "Event={}, SemanticKey={}, ExistingValue={}, NewValue={}, ExistingOriginalName='{}', NewOriginalName='{}'",
                                  match.getExternalId(), semanticKey, existing.getValue(), item.getValue(),
                                  existing.getName(), item.getName());
                    }
                    continue;
                }

                resolvedOdds.put(semanticKey, item);
                odds.add(item);
            }
        }
        return odds;
    }

    protected BetType resolveBetType(SportType sportType, Integer factorId, String groupName) {
        return betTypeResolver.resolve("fonbet", sportType, groupName, String.valueOf(factorId));
    }

    protected Map<String, Object> buildPayload(FonbetEvent event, List<FonbetEvent> childEvents, FonbetSport sport, FonbetEventMisc misc,
                                             Map<Integer, List<FonbetCustomFactor>> factorsMap, boolean isLive) {
        Map<String, Object> payload = new HashMap<>();
        payload.put("eventId", event.getId());
        payload.put("team1", event.getTeam1());
        payload.put("team2", event.getTeam2());
        payload.put("startTime", event.getStartTime());
        payload.put("isLive", isLive);
        payload.put("eventUrl", generateEventUrl(null, event, isLive));


        if (sport != null) {
            payload.put("sportId", sport.getId());
            payload.put("sportName", sport.getName());
        }

        if (misc != null) {
            Map<String, String> scores = new HashMap<>();
            scores.put("score1", misc.getScore1());
            scores.put("score2", misc.getScore2());
            scores.put("timer", misc.getTimer());
            payload.put("scores", scores);
        }

        List<Map<String, Object>> odds = new ArrayList<>();
        
        // Root factors
        List<FonbetCustomFactor> rootFactors = factorsMap.getOrDefault(event.getId(), List.of());
        for (FonbetCustomFactor factor : rootFactors) {
            Map<String, Object> odd = new HashMap<>();
            odd.put("factorId", factor.getF());
            odd.put("factorName", FonbetOddsService.getFactorName(factor.getF()));
            odd.put("value", factor.getV());
            if (factor.getP() != null) {
                odd.put("param", factor.getP());
            }
            odds.add(odd);
        }

        // Child events factors (periods, halves, corners, etc)
        if (childEvents != null) {
            for (FonbetEvent child : childEvents) {
                List<FonbetCustomFactor> childFactors = factorsMap.getOrDefault(child.getId(), List.of());
                for (FonbetCustomFactor factor : childFactors) {
                    Map<String, Object> odd = new HashMap<>();
                    odd.put("factorId", factor.getF());
                    
                    String baseName = FonbetOddsService.getFactorName(factor.getF());
                    String groupName = child.getName() != null ? child.getName() : "Level " + child.getLevel();
                    
                    odd.put("factorName", groupName + " - " + baseName);
                    odd.put("groupName", groupName);
                    odd.put("value", factor.getV());
                    if (factor.getP() != null) {
                        odd.put("param", factor.getP());
                    }
                    odds.add(odd);
                }
            }
        }

        payload.put("odds", odds);
        return payload;
    }

    private static final ThreadLocal<java.security.MessageDigest> SHA256_DIGEST = ThreadLocal.withInitial(() -> {
        try {
            return java.security.MessageDigest.getInstance("SHA-256");
        } catch (Exception e) {
            throw new RuntimeException("SHA-256 not available", e);
        }
    });

    protected String computeHash(String content) {
        try {
            java.security.MessageDigest digest = SHA256_DIGEST.get();
            digest.reset();
            byte[] hash = digest.digest(content.getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(hash);
        } catch (Exception e) {
            return String.valueOf(content.hashCode());
        }
    }

    protected void saveSport(FonbetSport fonbetSport) {
        try {
            Optional<SportCache> existing = sportCacheRepository.findByExternalId(fonbetSport.getId());
            SportCache sport = existing.orElseGet(SportCache::new);
            sport.setExternalId(fonbetSport.getId());
            sport.setName(fonbetSport.getName());
            sport.setKind(fonbetSport.getKind());
            sport.setUpdatedAt(LocalDateTime.now());
            sportCacheRepository.save(sport);
        } catch (Exception e) {
            log.debug("Error saving sport {}: {}", fonbetSport.getId(), e.getMessage());
        }
    }

    protected void syncFactors(MatchCache match, FonbetEvent rootEvent, List<FonbetEvent> childEvents, Map<Integer, List<FonbetCustomFactor>> factorsMap) {
        match.getFactors().clear();
        
        // Sync root factors
        List<FonbetCustomFactor> rootFactors = factorsMap.getOrDefault(rootEvent.getId(), List.of());
        for (FonbetCustomFactor sf : rootFactors) {
            if (sf.getF() == null) continue;
            MatchFactor mf = new MatchFactor();
            mf.setMatch(match);
            mf.setFactorId(sf.getF());
            mf.setName(FonbetOddsService.getFactorName(sf.getF()));
            mf.setValue(sf.getV());
            match.getFactors().add(mf);
        }

        // Sync child factors
        if (childEvents != null) {
            for (FonbetEvent child : childEvents) {
                List<FonbetCustomFactor> childFactors = factorsMap.getOrDefault(child.getId(), List.of());
                String groupName = child.getName() != null ? child.getName() : "Level " + child.getLevel();
                for (FonbetCustomFactor sf : childFactors) {
                    if (sf.getF() == null) continue;
                    MatchFactor mf = new MatchFactor();
                    mf.setMatch(match);
                    mf.setFactorId(sf.getF());
                    mf.setName(groupName + " - " + FonbetOddsService.getFactorName(sf.getF()));
                    mf.setValue(sf.getV());
                    match.getFactors().add(mf);
                }
            }
        }
    }

    protected FonbetSport findRootSport(FonbetSport current, Map<Integer, FonbetSport> sportsMap) {
        FonbetSport root = current;
        int depth = 0;
        while (root.getParentId() != null && sportsMap.containsKey(root.getParentId()) && depth < 5) {
            root = sportsMap.get(root.getParentId());
            depth++;
        }
        return root;
    }

    protected String extractFormat(FonbetEvent event, FonbetSport sport) {
        String searchTarget = "";
        if (event.getName() != null) searchTarget += event.getName();
        if (sport != null && sport.getName() != null) searchTarget += " " + sport.getName();
        
        if (searchTarget.isEmpty()) return null;

        java.util.regex.Pattern pattern = java.util.regex.Pattern.compile("BO(\\d+)|Best of (\\d+)", java.util.regex.Pattern.CASE_INSENSITIVE);
        java.util.regex.Matcher matcher = pattern.matcher(searchTarget);
        if (matcher.find()) {
            String val = matcher.group(1) != null ? matcher.group(1) : matcher.group(2);
            return "BO" + val;
        }
        return null;
    }

    protected SportType resolveFonbetSportType(String sportName) {
        if (sportName == null) return SportType.UNKNOWN;
        return sportNormalizationService.normalize(sportName);
    }

    protected abstract String generateEventUrl(MatchCache match, FonbetEvent event, boolean isLive);

    public void setErrorTracker(AbstractApiErrorTracker errorTracker) {
        this.errorTracker = errorTracker;
    }
}
