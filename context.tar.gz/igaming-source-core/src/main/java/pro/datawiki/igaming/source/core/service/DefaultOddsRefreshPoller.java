package pro.datawiki.igaming.source.core.service;

import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.stereotype.Component;
import pro.datawiki.igaming.source.core.aggregator.AggregatorClient;

/**
 * Universal default implementation of OddsRefreshPoller.
 * If a specific source microservice does not define its own OddsRefreshPoller,
 * this default bean will be registered automatically by Spring.
 * It injects the available RefreshCallback (which could be the DefaultRefreshCallback 
 * or a custom one if only the poller is missing).
 */
@Component
@ConditionalOnMissingBean(OddsRefreshPoller.class)
public class DefaultOddsRefreshPoller extends OddsRefreshPoller {

    private final RefreshCallback defaultRefreshCallback;

    public DefaultOddsRefreshPoller(AggregatorClient aggregatorClient, RefreshCallback refreshCallback) {
        super(aggregatorClient);
        this.defaultRefreshCallback = refreshCallback;
    }

    @Override
    protected RefreshCallback getRefreshCallback() {
        return defaultRefreshCallback;
    }
}
