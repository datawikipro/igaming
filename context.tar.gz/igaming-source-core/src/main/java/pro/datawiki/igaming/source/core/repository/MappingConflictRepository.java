package pro.datawiki.igaming.source.core.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import pro.datawiki.igaming.source.core.domain.MappingConflict;

import java.util.Optional;

@Repository
public interface MappingConflictRepository extends JpaRepository<MappingConflict, Long> {
    Optional<MappingConflict> findFirstByBookmakerAndSportTypeAndMarketAndOutcome(
            String bookmaker, String sportType, String market, String outcome);
}
