package pro.datawiki.igaming.source.core.engine.fonbet.mapper;

import org.springframework.stereotype.Component;
import pro.datawiki.igaming.dto.BetType;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.dto.market.BetScope;
import pro.datawiki.igaming.dto.market.MatchResultBet;
import pro.datawiki.igaming.dto.market.MatchResultBet.Outcome;
import pro.datawiki.igaming.dto.market.StatType;
import pro.datawiki.igaming.source.core.mapper.AbstractBetTypeMapper;

import java.util.Map;
import java.util.Set;

@Component
public class FonbetCommonResultMapper extends AbstractBetTypeMapper {

    private static final Set<SportType> SPECIALIZED_SPORTS = Set.of(
            SportType.FOOTBALL, SportType.BASKETBALL, SportType.HOCKEY, SportType.TENNIS,
            SportType.ESPORTS, SportType.CYBER_FOOTBALL, SportType.CYBER_BASKETBALL, SportType.CYBER_HOCKEY,
            SportType.VOLLEYBALL, SportType.BEACH_VOLLEYBALL, SportType.TABLE_TENNIS
    );

    private static final Map<String, Outcome> ID_MAP = Map.of(
            "921", Outcome.WIN1,
            "922", Outcome.DRAW,
            "923", Outcome.WIN2,
            "924", Outcome.DC_1X,
            "925", Outcome.DC_12,
            "926", Outcome.DC_X2,
            "1571", Outcome.DC_12,
            "1572", Outcome.DC_1X,
            "1573", Outcome.DC_X2
    );

    @Override
    public boolean supports(String bookmaker, SportType sportType) {
        return "fonbet".equals(bookmaker) && !SPECIALIZED_SPORTS.contains(sportType);
    }

    @Override
    public BetType map(String market, String outcome) {
        if (outcome == null) return null;
        Outcome res = ID_MAP.get(outcome);
        if (res == null) return null;

        BetScope scope = resolveScope(market);
        StatType stat = resolveStat(market);
        
        return new MatchResultBet(scope, res, stat);
    }

    private BetScope resolveScope(String market) {
        if (market == null) return BetScope.FULL_MATCH;
        String m = market.toLowerCase();
        if (m.contains("1-й период") || m.contains("1-й тайм") || m.contains("1-я четверть") || m.contains("1-й сет")) return BetScope.PERIOD_1;
        if (m.contains("2-й период") || m.contains("2-й тайм") || m.contains("2-я четверть") || m.contains("2-й сет")) return BetScope.PERIOD_2;
        if (m.contains("3-й период") || m.contains("3-я четверть") || m.contains("3-й сет")) return BetScope.PERIOD_3;
        if (m.contains("4-я четверть")) return BetScope.QUARTER_4;
        if (m.contains("1-я половина")) return BetScope.HALF_1;
        if (m.contains("2-я половина")) return BetScope.HALF_2;
        return BetScope.FULL_MATCH;
    }

    private StatType resolveStat(String market) {
        if (market == null) return StatType.MATCH;
        String m = market.toLowerCase();
        if (m.contains("угловые")) return StatType.CORNERS;
        if (m.contains("желтые карточки") || m.contains("жк")) return StatType.CARDS;
        return StatType.MATCH;
    }
}
