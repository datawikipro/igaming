package pro.datawiki.igaming.admin;

import com.google.cloud.compute.v1.*;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.api.gax.core.FixedCredentialsProvider;

import java.io.FileInputStream;
import java.util.UUID;

public class ScratchGcp {
    public static void main(String[] args) throws Exception {
        String spotProjectId = "project-ec074516-4738-4d28-ad5";
        String spotZone = "europe-north2-b";
        String spotCredentialsPath = "C:\\Users\\chernousov_a\\AppData\\Roaming\\gcloud\\legacy_credentials\\developer.usa.test1@gmail.com\\adc.json";
        String tailscaleAuthKey = "tskey-auth-kZotQnypWz11CNTRL-tZfx6Wiowm2GwL6euwP5n2Ti4487uRHab";
        
        String model = "SPOT";
        String role = "LOADER";
        String machineType = "e2-custom-4-16384";

        String prefix = "spot-worker-";
        String instanceName = prefix + UUID.randomUUID().toString().substring(0, 8);
        System.out.println("Provisioning GCP instance: " + instanceName);

        String startupScript = "#!/bin/bash\n" +
                "sleep 10\n" +
                "curl -fsSL https://tailscale.com/install.sh | sh\n" +
                "tailscale up --authkey=\"" + tailscaleAuthKey + "\" --ssh\n" +
                "TAILSCALE_IP=$(tailscale ip -4)\n" +
                "curl -sfL https://get.k3s.io | \\\n" +
                "  K3S_URL=\"https://10.226.0.2:6443\" \\\n" +
                "  K3S_TOKEN=\"K10c7e23826108f187591e9533b0f508af002ac6670d728c57e0b4919cac2725b15::server:84cc0f96d1b83f1620ba81127b42d739\" \\\n" +
                "  INSTALL_K3S_EXEC=\"agent --node-ip=$TAILSCALE_IP --node-external-ip=$TAILSCALE_IP --node-label=node-type=" + model.toLowerCase() + " --node-label=provisioning=" + model.toLowerCase() + " --node-label=role=" + role.toLowerCase() + "\" \\\n" +
                "  sh -\n";

        InstancesSettings.Builder settingsBuilder = InstancesSettings.newBuilder();
        if (spotCredentialsPath != null && !spotCredentialsPath.isEmpty()) {
            try (FileInputStream fis = new FileInputStream(spotCredentialsPath)) {
                GoogleCredentials credentials = GoogleCredentials.fromStream(fis)
                        .createScoped(java.util.List.of("https://www.googleapis.com/auth/cloud-platform"));
                settingsBuilder.setCredentialsProvider(FixedCredentialsProvider.create(credentials));
            }
        }

        try (InstancesClient client = InstancesClient.create(settingsBuilder.build())) {
            Instance instanceResource = Instance.newBuilder()
                    .setName(instanceName)
                    .setMachineType(String.format("projects/%s/zones/%s/machineTypes/%s", spotProjectId, spotZone, machineType))
                    .setScheduling(Scheduling.newBuilder()
                            .setProvisioningModel("SPOT")
                            .setPreemptible(true)
                            .build())
                    .addServiceAccounts(ServiceAccount.newBuilder()
                            .setEmail("default")
                            .addAllScopes(java.util.List.of("https://www.googleapis.com/auth/cloud-platform"))
                            .build())
                    .addNetworkInterfaces(NetworkInterface.newBuilder()
                            .setNetwork(String.format("projects/%s/global/networks/default", spotProjectId))
                            .setSubnetwork(String.format("projects/%s/regions/%s/subnetworks/default", spotProjectId, "europe-north2"))
                            .addAccessConfigs(AccessConfig.newBuilder()
                                    .setName("External NAT")
                                    .setType(AccessConfig.Type.ONE_TO_ONE_NAT.toString())
                                    .setNetworkTier(AccessConfig.NetworkTier.PREMIUM.toString())
                                    .build())
                            .build())
                    .addDisks(AttachedDisk.newBuilder()
                            .setBoot(true)
                            .setAutoDelete(true)
                            .setType(AttachedDisk.Type.PERSISTENT.toString())
                            .setInitializeParams(AttachedDiskInitializeParams.newBuilder()
                                    .setSourceImage("projects/centos-cloud/global/images/family/centos-stream-9")
                                    .setDiskSizeGb(50L)
                                    .build())
                            .build())
                    .setMetadata(Metadata.newBuilder()
                            .addItems(Items.newBuilder()
                                    .setKey("startup-script")
                                    .setValue(startupScript)
                                    .build())
                            .build())
                    .build();

            System.out.println("Sending async request...");
            Operation response = client.insertAsync(spotProjectId, spotZone, instanceResource).get();
            if (response.hasError()) {
                System.out.println("Error: " + response.getError());
            } else {
                System.out.println("Success! Status: " + response.getStatus());
            }
        }
    }
}
