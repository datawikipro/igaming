package pro.datawiki.igaming.admin.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import pro.datawiki.igaming.admin.entity.ManagedInstance;

import java.util.List;

public interface ManagedInstanceRepository extends JpaRepository<ManagedInstance, String> {
    List<ManagedInstance> findByStatus(String status);
}
