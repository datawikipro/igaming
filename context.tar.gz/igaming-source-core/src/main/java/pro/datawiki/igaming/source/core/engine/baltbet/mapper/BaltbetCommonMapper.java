package pro.datawiki.igaming.source.core.engine.baltbet.mapper;

import org.springframework.stereotype.Component;
import pro.datawiki.igaming.dto.BetType;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.dto.market.*;
import pro.datawiki.igaming.source.core.mapper.AbstractBetTypeMapper;

import java.util.Map;
import java.util.Set;

import static pro.datawiki.igaming.dto.market.MatchResultBet.Outcome.*;

/**
 * Common mapper for Baltbet-family bookmakers.
 */
@Component
public class BaltbetCommonMapper extends AbstractBetTypeMapper {

    private static final Set<SportType> SPECIALIZED_SPORTS = Set.of(
            SportType.FOOTBALL, SportType.BASKETBALL, SportType.HOCKEY, SportType.TENNIS,
            SportType.ESPORTS, SportType.CYBER_FOOTBALL, SportType.CYBER_BASKETBALL, SportType.CYBER_HOCKEY,
            SportType.VOLLEYBALL, SportType.BEACH_VOLLEYBALL, SportType.TABLE_TENNIS
    );

    private static final Map<String, BetType> ID_MAP = Map.ofEntries(
            Map.entry("1", new MatchResultBet(BetScope.FULL_MATCH, WIN1, StatType.MATCH)),
            Map.entry("2", new MatchResultBet(BetScope.FULL_MATCH, DRAW, StatType.MATCH)),
            Map.entry("3", new MatchResultBet(BetScope.FULL_MATCH, WIN2, StatType.MATCH)),
            Map.entry("4", new MatchResultBet(BetScope.FULL_MATCH, DC_1X, StatType.MATCH)),
            Map.entry("5", new MatchResultBet(BetScope.FULL_MATCH, DC_12, StatType.MATCH)),
            Map.entry("6", new MatchResultBet(BetScope.FULL_MATCH, DC_X2, StatType.MATCH)),
            Map.entry("7", new HandicapBet(BetScope.FULL_MATCH, HandicapBet.Team.TEAM1, 0.0, false, StatType.MATCH)),
            Map.entry("8", new HandicapBet(BetScope.FULL_MATCH, HandicapBet.Team.TEAM2, 0.0, false, StatType.MATCH)),
            Map.entry("9", new TotalBet(BetScope.FULL_MATCH, BetSubject.MATCH, TotalBet.Direction.OVER, 0.0, false, StatType.MATCH)),
            Map.entry("10", new TotalBet(BetScope.FULL_MATCH, BetSubject.MATCH, TotalBet.Direction.UNDER, 0.0, false, StatType.MATCH))
    );

    @Override
    public boolean supports(String bookmaker, SportType sportType) {
        return bookmaker != null && bookmaker.toLowerCase().contains("baltbet") && !SPECIALIZED_SPORTS.contains(sportType);
    }

    @Override
    public BetType map(String m, String o) {
        return ID_MAP.get(m);
    }
}
