package pro.datawiki.igaming.source.core.service;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import pro.datawiki.igaming.dto.SportType;

import static org.junit.jupiter.api.Assertions.assertEquals;

class SportNormalizationServiceTest {

    private final UnmappedSportService unmappedSportService = Mockito.mock(UnmappedSportService.class);
    private final SportNormalizationService service = new SportNormalizationService(unmappedSportService);

    @Test
    void testNormalizeRussianSports() {
        assertEquals(SportType.FOOTBALL, service.normalize("Футбол"));
        assertEquals(SportType.TENNIS, service.normalize("Теннис"));
        assertEquals(SportType.BASKETBALL, service.normalize("Баскетбол"));
        assertEquals(SportType.HOCKEY, service.normalize("Хоккей"));
        assertEquals(SportType.VOLLEYBALL, service.normalize("Волейбол"));
        assertEquals(SportType.HANDBALL, service.normalize("Гандбол"));
        assertEquals(SportType.TABLE_TENNIS, service.normalize("Настольный теннис"));
        assertEquals(SportType.ESPORTS, service.normalize("Киберспорт"));
        assertEquals(SportType.BEACH_VOLLEYBALL, service.normalize("Пляжный волейбол"));
        assertEquals(SportType.MMA, service.normalize("ММА"));
    }

    @Test
    void testNormalizeEnglishSports() {
        assertEquals(SportType.FOOTBALL, service.normalize("Football"));
        assertEquals(SportType.TENNIS, service.normalize("Tennis"));
        assertEquals(SportType.BASKETBALL, service.normalize("Basketball"));
        assertEquals(SportType.HOCKEY, service.normalize("Hockey"));
        assertEquals(SportType.ESPORTS, service.normalize("ESports"));
    }

    @Test
    void testPartialMatches() {
        // Test that "Футбол. Чемпионат Англии" resolve to FOOTBALL
        assertEquals(SportType.FOOTBALL, service.normalize("Футбол. Чемпионат Англии"));
        // Test that "Теннис. ATP" resolve to TENNIS
        assertEquals(SportType.TENNIS, service.normalize("Теннис. ATP"));
    }

    @Test
    void testUnknownSports() {
        assertEquals(SportType.UNKNOWN, service.normalize("Some Weird Sport"));
        assertEquals(SportType.UNKNOWN, service.normalize(null));
        assertEquals(SportType.UNKNOWN, service.normalize(""));
    }

    @Test
    void testNewlyAddedSports() {
        assertEquals(SportType.CHESS, service.normalize("Шахматы"));
        assertEquals(SportType.PADEL, service.normalize("Падель-теннис"));
        assertEquals(SportType.SKIING, service.normalize("Лыжные гонки"));
        assertEquals(SportType.BOWLING, service.normalize("Боулинг"));
        assertEquals(SportType.MOTORSPORTS, service.normalize("Формула 1"));
    }
}
