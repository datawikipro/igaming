package pro.datawiki.igaming.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

/**
 * Marker interface for all bet types (sport-specific and common).
 * In the new structural architecture, implementations are Records like TotalBet, MatchResultBet.
 */
@JsonDeserialize(using = BetTypeDeserializer.class)
@JsonSerialize(using = BetTypeSerializer.class)
public interface BetType {

    /** Unique canonical code, used for JSON serialization and DB storage (OddsType.code). */
    String code();

    /**
     * Market code that groups related bet types together.
     * Maps 1:1 to Market.code in DB.
     * E.g. WIN1 + DRAW + WIN2 all share marketCode "MATCH_RESULT".
     */
    String marketCode();

    /** Human-readable description. */
    String description();

    /** Whether this bet type requires a numeric parameter (e.g. total line, handicap value). */
    boolean isParametric();

    /**
     * Multiplier for the param value in paired parametric outcomes.
     */
    default double paramMultiplier() {
        return 1.0;
    }

    /**
     * Injects a parameter into the bet type if applicable.
     */
    default BetType withParam(double param) {
        throw new UnsupportedOperationException("This BetType does not support params");
    }

    /**
     * Returns the numeric parameter of this bet type (e.g. 2.5 for Total Over 2.5).
     * Returns null for non-parametric bet types.
     */
    default Double getParam() {
        return null;
    }
}
