package pro.datawiki.igaming.source.core.engine.sportbet.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class SportbetSelection {
    private Integer i; // id
    private Object n; // name (often string or number)
    private Double o; // odds
    private Boolean lc;
}
