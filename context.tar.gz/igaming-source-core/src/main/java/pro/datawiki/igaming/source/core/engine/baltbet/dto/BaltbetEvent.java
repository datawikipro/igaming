package pro.datawiki.igaming.source.core.engine.baltbet.dto;

import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class BaltbetEvent {
    @JsonProperty("i")
    private Integer id;
    
    @JsonProperty("x")
    private Integer sportId;
    
    @JsonProperty("t")
    private String time;
    
    @JsonProperty("m")
    private String period;
    
    @JsonProperty("s")
    private Map<String, Object> score;
    
    @JsonProperty("c")
    private List<BaltbetCoef> coefs;

    private Map<String, Object> extra = new HashMap<>();

    @JsonAnySetter
    public void setExtra(String key, Object value) {
        extra.put(key, value);
    }
}
