package pro.datawiki.igaming.source.core.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import com.fasterxml.jackson.annotation.JsonAlias;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class VpnConfigDto {
    private String id;

    @JsonAlias({"proxyHost", "proxy_host"})
    private String proxyHost;

    @JsonAlias({"enabled", "is_enabled"})
    private Boolean enabled;
}
