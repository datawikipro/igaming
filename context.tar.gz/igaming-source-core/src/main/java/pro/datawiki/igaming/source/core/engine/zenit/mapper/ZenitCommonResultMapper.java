package pro.datawiki.igaming.source.core.engine.zenit.mapper;

import org.springframework.stereotype.Component;
import pro.datawiki.igaming.dto.BetType;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.dto.market.BetScope;
import pro.datawiki.igaming.dto.market.StatType;
import pro.datawiki.igaming.source.core.mapper.AbstractBetTypeMapper;

import java.util.Map;
import java.util.Set;

@Component
public class ZenitCommonResultMapper extends AbstractBetTypeMapper {

    private static final Set<SportType> SPECIALIZED_SPORTS = Set.of(
            SportType.FOOTBALL, SportType.BASKETBALL, SportType.HOCKEY, SportType.TENNIS,
            SportType.ESPORTS, SportType.CYBER_FOOTBALL, SportType.CYBER_BASKETBALL, SportType.CYBER_HOCKEY,
            SportType.VOLLEYBALL, SportType.BEACH_VOLLEYBALL, SportType.TABLE_TENNIS
    );

    @Override
    public boolean supports(String bookmaker, SportType sportType) {
        return "zenit".equals(bookmaker) && !SPECIALIZED_SPORTS.contains(sportType);
    }

    @Override
    public BetType map(String market, String outcome) {
        if (outcome == null) return null;

        BetType mapped = switch (outcome) {
            case "1", "4" -> map1X2DCRecord("1", BetScope.FULL_MATCH, StatType.MATCH);
            case "2", "5" -> map1X2DCRecord("X", BetScope.FULL_MATCH, StatType.MATCH);
            case "3", "6" -> map1X2DCRecord("2", BetScope.FULL_MATCH, StatType.MATCH);
            case "8" -> map1X2DCRecord("1X", BetScope.FULL_MATCH, StatType.MATCH);
            case "9" -> map1X2DCRecord("12", BetScope.FULL_MATCH, StatType.MATCH);
            case "10" -> map1X2DCRecord("X2", BetScope.FULL_MATCH, StatType.MATCH);
            default -> null;
        };

        if (mapped != null) return mapped;

        if (market == null) return null;
        String upperM = market.toUpperCase().trim();
        
        if (upperM.contains("ИСХОД") || upperM.contains("РЕЗУЛЬТАТ") || upperM.contains("1X2")) {
             // Logic based on outcome name if ID not found
             // But Zenit usually provides IDs
        }

        return null;
    }
}
