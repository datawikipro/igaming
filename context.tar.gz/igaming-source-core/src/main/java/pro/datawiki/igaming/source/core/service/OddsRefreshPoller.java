package pro.datawiki.igaming.source.core.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import pro.datawiki.igaming.dto.OddsRefreshRequestDto;
import pro.datawiki.igaming.source.core.aggregator.AggregatorClient;

import java.util.List;

/**
 * Polls the aggregator's refresh queue for events that need targeted odds re-fetch.
 * Two separate polling cycles:
 * - Prematch queue (HIGH/MEDIUM/LOW): every 30 seconds
 * - Live queue (LIVE): every 15 seconds
 *
 * Each source service provides a RefreshCallback implementation to handle
 * the actual event refresh.
 */
@Slf4j
public abstract class OddsRefreshPoller {

    protected final AggregatorClient aggregatorClient;

    @Value("${app.bookmaker.name:unknown}")
    protected String sourceId;

    @Value("${app.odds-refresh.prematch-poll-ms:30000}")
    protected long prematchPollMs;

    @Value("${app.odds-refresh.live-poll-ms:15000}")
    protected long livePollMs;

    @Value("${app.odds-refresh.enabled:true}")
    protected boolean refreshEnabled;

    public OddsRefreshPoller(AggregatorClient aggregatorClient) {
        this.aggregatorClient = aggregatorClient;
    }

    /**
     * Subclasses must provide a RefreshCallback that knows how to re-fetch
     * odds for a specific event from the bookmaker's API.
     */
    protected abstract RefreshCallback getRefreshCallback();

    /**
     * Poll prematch refresh queue every 30 seconds.
     * Handles HIGH (0-4h), MEDIUM (4-24h), and LOW (>24h) priority events.
     */
    @Scheduled(fixedDelayString = "${app.odds-refresh.prematch-poll-ms:30000}")
    public void pollPrematchRefreshQueue() {
        if (!refreshEnabled) return;

        try {
            List<OddsRefreshRequestDto> queue = aggregatorClient.fetchPrematchRefreshQueue(sourceId);
            if (queue == null || queue.isEmpty()) return;

            log.info("[{}] Prematch refresh queue: {} events to refresh", sourceId, queue.size());

            for (OddsRefreshRequestDto req : queue) {
                try {
                    getRefreshCallback().refreshEvent(req.getExternalEventId());
                    aggregatorClient.acknowledgeRefresh(sourceId, req.getExternalEventId());
                    log.debug("[{}] Refreshed prematch event {} (priority={})",
                            sourceId, req.getExternalEventId(), req.getPriority());
                } catch (Exception e) {
                    log.warn("[{}] Failed to refresh prematch event {}: {}",
                            sourceId, req.getExternalEventId(), e.getMessage());
                }
            }
        } catch (Exception e) {
            log.debug("[{}] Error polling prematch refresh queue: {}", sourceId, e.getMessage());
        }
    }

    /**
     * Poll live refresh queue every 15 seconds.
     * Handles LIVE priority events (match in progress).
     */
    @Scheduled(fixedDelayString = "${app.odds-refresh.live-poll-ms:15000}")
    public void pollLiveRefreshQueue() {
        if (!refreshEnabled) return;

        try {
            List<OddsRefreshRequestDto> queue = aggregatorClient.fetchLiveRefreshQueue(sourceId);
            if (queue == null || queue.isEmpty()) return;

            log.info("[{}] Live refresh queue: {} events to refresh", sourceId, queue.size());

            for (OddsRefreshRequestDto req : queue) {
                try {
                    getRefreshCallback().refreshEvent(req.getExternalEventId());
                    aggregatorClient.acknowledgeRefresh(sourceId, req.getExternalEventId());
                    log.debug("[{}] Refreshed live event {} ", sourceId, req.getExternalEventId());
                } catch (Exception e) {
                    log.warn("[{}] Failed to refresh live event {}: {}",
                            sourceId, req.getExternalEventId(), e.getMessage());
                }
            }
        } catch (Exception e) {
            log.debug("[{}] Error polling live refresh queue: {}", sourceId, e.getMessage());
        }
    }
}
