package pro.datawiki.igaming.source.core.repository;
 
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import pro.datawiki.igaming.source.core.domain.MatchFactor;
 
@Repository
public interface MatchFactorRepository extends JpaRepository<MatchFactor, Long> {
}
