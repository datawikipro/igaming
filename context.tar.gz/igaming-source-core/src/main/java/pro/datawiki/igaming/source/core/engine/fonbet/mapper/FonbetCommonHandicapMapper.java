package pro.datawiki.igaming.source.core.engine.fonbet.mapper;

import org.springframework.stereotype.Component;
import pro.datawiki.igaming.dto.BetType;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.dto.market.BetScope;
import pro.datawiki.igaming.dto.market.HandicapBet;
import pro.datawiki.igaming.dto.market.HandicapBet.Team;
import pro.datawiki.igaming.dto.market.StatType;
import pro.datawiki.igaming.source.core.mapper.AbstractBetTypeMapper;

import java.util.Set;

@Component
public class FonbetCommonHandicapMapper extends AbstractBetTypeMapper {

    private static final Set<SportType> SPECIALIZED_SPORTS = Set.of(
            SportType.FOOTBALL, SportType.BASKETBALL, SportType.HOCKEY, SportType.TENNIS,
            SportType.ESPORTS, SportType.CYBER_FOOTBALL, SportType.CYBER_BASKETBALL, SportType.CYBER_HOCKEY,
            SportType.VOLLEYBALL, SportType.BEACH_VOLLEYBALL, SportType.TABLE_TENNIS
    );

    private static final Set<String> TEAM1_IDS = Set.of(
            "927", "910", "989", "1569", "1672", "1677", "1680", "1683", "1686", "1873"
    );

    private static final Set<String> TEAM2_IDS = Set.of(
            "928", "912", "991", "1675", "1678", "1681", "1684", "1687", "1874"
    );

    @Override
    public boolean supports(String bookmaker, SportType sportType) {
        return "fonbet".equals(bookmaker) && !SPECIALIZED_SPORTS.contains(sportType);
    }

    @Override
    public BetType map(String market, String outcome) {
        if (outcome == null) return null;
        
        Team team = null;
        if (TEAM1_IDS.contains(outcome)) team = Team.TEAM1;
        else if (TEAM2_IDS.contains(outcome)) team = Team.TEAM2;
        
        if (team == null) return null;

        BetScope scope = resolveScope(market);
        StatType stat = resolveStat(market);

        return new HandicapBet(scope, team, 0.0, false, stat);
    }

    private BetScope resolveScope(String market) {
        if (market == null) return BetScope.FULL_MATCH;
        String m = market.toLowerCase();
        if (m.contains("1-й период") || m.contains("1-й тайм") || m.contains("1-я четверть") || m.contains("1-й сет")) return BetScope.PERIOD_1;
        if (m.contains("2-й период") || m.contains("2-й тайм") || m.contains("2-я четверть") || m.contains("2-й сет")) return BetScope.PERIOD_2;
        if (m.contains("3-й период") || m.contains("3-я четверть") || m.contains("3-й сет")) return BetScope.PERIOD_3;
        if (m.contains("4-я четверть")) return BetScope.QUARTER_4;
        if (m.contains("1-я половина")) return BetScope.HALF_1;
        if (m.contains("2-я половина")) return BetScope.HALF_2;
        return BetScope.FULL_MATCH;
    }

    private StatType resolveStat(String market) {
        if (market == null) return StatType.MATCH;
        String m = market.toLowerCase();
        if (m.contains("угловые")) return StatType.CORNERS;
        if (m.contains("желтые карточки") || m.contains("жк")) return StatType.CARDS;
        return StatType.MATCH;
    }
}
