package pro.datawiki.igaming.source.core.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import pro.datawiki.igaming.source.core.domain.SportCache;

import java.util.Optional;

@Repository
public interface SportCacheRepository extends JpaRepository<SportCache, Long> {
    Optional<SportCache> findByExternalId(Integer externalId);
}
