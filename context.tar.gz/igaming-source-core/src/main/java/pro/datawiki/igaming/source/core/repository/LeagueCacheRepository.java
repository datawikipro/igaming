package pro.datawiki.igaming.source.core.repository;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import pro.datawiki.igaming.source.core.domain.LeagueCache;

import jakarta.persistence.LockModeType;
import jakarta.persistence.QueryHint;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface LeagueCacheRepository extends JpaRepository<LeagueCache, Long> {

    Optional<LeagueCache> findByExternalId(String externalId);

    @Query(value = """
            SELECT * FROM league_cache 
            ORDER BY 
              CASE WHEN status = 'NEW' THEN 0 ELSE 1 END ASC, 
              updated_at ASC
            LIMIT :limit
            FOR UPDATE SKIP LOCKED
            """, nativeQuery = true)
    List<LeagueCache> _findAndLockPendingLeaguesWithLimit(@Param("limit") int limit);

    default List<LeagueCache> findAndLockPendingLeagues(Pageable pageable) {
        return _findAndLockPendingLeaguesWithLimit(pageable.getPageSize());
    }

    @org.springframework.data.jpa.repository.Modifying
    @org.springframework.data.jpa.repository.Query("UPDATE LeagueCache lc SET lc.status = :status, lc.updatedAt = :updatedAt WHERE lc.id = :id")
    void updateStatus(@Param("id") Long id, @Param("status") pro.datawiki.igaming.source.core.domain.LeagueCache.Status status, @Param("updatedAt") LocalDateTime updatedAt);
}
