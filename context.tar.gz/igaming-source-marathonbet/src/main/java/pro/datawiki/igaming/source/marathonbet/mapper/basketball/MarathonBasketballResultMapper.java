package pro.datawiki.igaming.source.marathonbet.mapper.basketball;

import org.springframework.stereotype.Component;
import pro.datawiki.igaming.dto.BetType;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.dto.market.BetScope;
import pro.datawiki.igaming.dto.market.MatchResultBet;
import pro.datawiki.igaming.dto.market.StatType;
import pro.datawiki.igaming.source.core.mapper.AbstractBetTypeMapper;

@Component
public class MarathonBasketballResultMapper extends AbstractBetTypeMapper {

    @Override
    public boolean supports(String bookmaker, SportType sportType) {
        return "marathonbet".equals(bookmaker) && sportType == SportType.BASKETBALL;
    }

    @Override
    public BetType map(String m, String o) {
        if (m == null || o == null) return null;
        String upperM = m.toUpperCase().trim();
        String upperO = o.toUpperCase().trim();

        // 1. Match Winner (2-way)
        if (upperM.matches("^(MATCH_WINNER_INCLUDING_ALL_OT|MATCH_RESULT_INCLUDING_OVERTIME|RESULT|MATCH_RESULT|WINNER)$") || "1".equals(m) || "2".equals(m)) {
            MatchResultBet.Outcome outcome = switch (upperO) {
                case "1", "HB_H", "HOME" -> MatchResultBet.Outcome.WIN1_2WAY;
                case "2", "3", "HB_A", "AWAY" -> MatchResultBet.Outcome.WIN2_2WAY;
                default -> "1".equals(m) ? MatchResultBet.Outcome.WIN1_2WAY : ("2".equals(m) ? MatchResultBet.Outcome.WIN2_2WAY : null);
            };
            if (outcome != null) {
                return new MatchResultBet(BetScope.FULL_MATCH, outcome, StatType.MATCH);
            }
        }

        // 3. Quarter Results
        if (upperM.matches("^RESULT_-_([1-4])(ST|ND|RD|TH)_QUARTER$")) {
            String q = upperM.replaceAll("^RESULT_-_([1-4]).*", "$1");
            BetScope scope = switch (q) {
                case "1" -> BetScope.QUARTER_1;
                case "2" -> BetScope.QUARTER_2;
                case "3" -> BetScope.QUARTER_3;
                case "4" -> BetScope.QUARTER_4;
                default -> null;
            };
            if (scope != null) return map1X2Record(upperO, scope, StatType.MATCH);
        }

        return null;
    }
}
