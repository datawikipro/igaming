package pro.datawiki.igaming.admin.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import pro.datawiki.igaming.admin.entity.ScalingConfig;

public interface ScalingConfigRepository extends JpaRepository<ScalingConfig, String> {
}
