package pro.datawiki.igaming.source.core.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import pro.datawiki.igaming.source.core.domain.UnmappedSport;
import pro.datawiki.igaming.source.core.repository.UnmappedSportRepository;

import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
public class UnmappedSportService {

    private final UnmappedSportRepository unmappedSportRepository;

    public void saveIfUnknown(String bookmaker, String rawName) {
        if (rawName == null || rawName.trim().isEmpty() || "null".equalsIgnoreCase(rawName.trim())) {
            return;
        }

        Optional<UnmappedSport> existing = unmappedSportRepository.findFirstByBookmakerAndRawName(bookmaker, rawName);
        if (existing.isEmpty()) {
            log.debug("New unmapped sport found for {}: '{}'", bookmaker, rawName);
            
            unmappedSportRepository.save(UnmappedSport.builder()
                    .bookmaker(bookmaker)
                    .rawName(rawName)
                    .build());
        }
    }
}
