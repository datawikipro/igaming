package pro.datawiki.igaming.source.marathonbet.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import pro.datawiki.igaming.dto.OddItem;
import pro.datawiki.igaming.dto.OddsUpdateRequest;
import pro.datawiki.igaming.dto.SourceRefreshResponse;
import pro.datawiki.igaming.dto.SourceStatsResponse;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.source.core.aggregator.AggregatorClient;
import pro.datawiki.igaming.source.core.domain.LeagueCache;
import pro.datawiki.igaming.source.core.domain.MatchCache;
import pro.datawiki.igaming.source.core.engine.AbstractMatchService;
import pro.datawiki.igaming.source.core.repository.LeagueCacheRepository;
import pro.datawiki.igaming.source.core.repository.MatchCacheRepository;
import pro.datawiki.igaming.source.core.service.MatchPersistenceService;
import pro.datawiki.igaming.source.core.service.SportNormalizationService;
import pro.datawiki.igaming.source.marathonbet.dto.marathon.MarathonEvent;

import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

@Service
@Slf4j
public class MatchService extends AbstractMatchService<MarathonEvent> {

    private final MarathonbetApiClient apiClient;
    private final LeagueCacheRepository leagueCacheRepository;
    private final MarathonOddsMapper oddsMapper;
    private final MarathonDiscoveryService discoveryService;

    private final AtomicLong totalProcessed = new AtomicLong(0);
    private final AtomicLong totalUpdated = new AtomicLong(0);

    @Autowired
    @Lazy
    private MatchService self;

    public MatchService(MatchCacheRepository matchCacheRepository,
                        MatchPersistenceService persistenceService,
                        AggregatorClient aggregatorClient,
                        ObjectMapper objectMapper,
                        SportNormalizationService sportNormalizationService,
                        MarathonbetApiClient apiClient,
                        LeagueCacheRepository leagueCacheRepository,
                        MarathonOddsMapper oddsMapper,
                        MarathonDiscoveryService discoveryService) {
        super(matchCacheRepository, persistenceService, aggregatorClient, objectMapper, sportNormalizationService);
        this.apiClient = apiClient;
        this.leagueCacheRepository = leagueCacheRepository;
        this.oddsMapper = oddsMapper;
        this.discoveryService = discoveryService;
    }

    @Override
    protected String getBookmakerName() {
        return "marathonbet";
    }

    @Override
    protected boolean isValidEvent(MarathonEvent event) {
        return event != null && event.getEventId() != null;
    }

    /**
     * League-crawler master role.
     */
    public SourceRefreshResponse queueLeagues() {
        long startTime = System.currentTimeMillis();
        int queued = discoveryService.queueLeagues();
        return SourceRefreshResponse.builder()
                .status("ok")
                .leaguesProcessed(queued)
                .durationMs(System.currentTimeMillis() - startTime)
                .build();
    }

    /**
     * League-crawler worker role.
     */
    public int processPendingLeagues(int batchSize) {
        List<LeagueCache> batch = self.fetchLeaguesToProcess(batchSize);
        if (batch.isEmpty()) return 0;

        int totalEvents = 0;
        for (LeagueCache cache : batch) {
            try {
                totalEvents += discoveryService.processEventsInLeague(cache);
                self.markLeagueAsProcessed(cache.getId());
            } catch (Exception e) {
                log.error("Failed to process league {}: {}", cache.getLeagueName(), e.getMessage());
                self.markLeagueAsFailed(cache.getId());
            }
        }
        totalProcessed.addAndGet(totalEvents);
        return batch.size();
    }

    @Transactional
    public List<LeagueCache> fetchLeaguesToProcess(int batchSize) {
        List<LeagueCache> batch = leagueCacheRepository.findAndLockPendingLeagues(PageRequest.of(0, batchSize));
        for (LeagueCache cache : batch) {
            cache.setStatus(LeagueCache.Status.PENDING);
            cache.setUpdatedAt(LocalDateTime.now());
        }
        return leagueCacheRepository.saveAll(batch);
    }

    @Transactional
    public void markLeagueAsProcessed(Long id) {
        leagueCacheRepository.updateStatus(id, LeagueCache.Status.PROCESSED, LocalDateTime.now());
    }

    @Transactional
    public void markLeagueAsFailed(Long id) {
        leagueCacheRepository.updateStatus(id, LeagueCache.Status.FAILED, LocalDateTime.now());
    }

    @Override
    public int loadMatchCards(int batchSize) {
        List<MatchCache> batch = self.fetchMatchBatchToProcess(batchSize);
        if (batch.isEmpty()) return 0;

        int processed = 0;
        for (MatchCache cache : batch) {
            try {
                MarathonEvent event = parseEventPayload(cache);
                if (event != null) {
                    apiClient.enrichWithAllMarkets(event);
                    self.processEnrichedMatch(cache.getId(), event);
                    processed++;
                }
            } catch (Exception e) {
                log.error("Failed to enrich match {}: {}", cache.getExternalId(), e.getMessage());
                self.markMatchAsFailed(cache.getId());
            }
        }
        return processed;
    }

    @Transactional
    public List<MatchCache> fetchMatchBatchToProcess(int batchSize) {
        List<MatchCache> batch = matchCacheRepository.findAndLockPendingMatches(PageRequest.of(0, batchSize));
        for (MatchCache match : batch) {
            match.setStatus(MatchCache.Status.PENDING);
            match.setUpdatedAt(LocalDateTime.now());
        }
        return matchCacheRepository.saveAll(batch);
    }

    @Transactional
    public void processEnrichedMatch(Long id, MarathonEvent event) throws Exception {
        MatchCache cache = matchCacheRepository.findById(id).orElseThrow();
        
        // Restore sportName if missing
        if ((event.getSportName() == null || event.getSportName().isEmpty()) && cache.getSportName() != null) {
            event.setSportName(cache.getSportName());
        }

        String payload = objectMapper.writeValueAsString(event);
        persistenceService.saveOrUpdateMatchMetadata(cache, payload);
        
        pushToAggregator(cache); // AbstractMatchService helper
        totalUpdated.incrementAndGet();
        
        cache.setStatus(MatchCache.Status.PROCESSED);
        matchCacheRepository.save(cache);
    }

    @Transactional
    public void markMatchAsFailed(Long id) {
        matchCacheRepository.updateStatus(id, MatchCache.Status.FAILED, LocalDateTime.now());
    }

    /**
     * Targeted refresh.
     */
    @Transactional
    public SourceRefreshResponse processEventByUrl(String url) {
        long startTime = System.currentTimeMillis();
        MarathonEvent event = apiClient.fetchEventByUrl(url);
        if (event == null) return SourceRefreshResponse.builder().status("error").build();

        try {
            discoveryService.saveOrUpdateEvent(event);
            totalUpdated.incrementAndGet();
            totalProcessed.incrementAndGet();
            return SourceRefreshResponse.builder()
                    .status("ok")
                    .eventsProcessed(1)
                    .eventsUpdated(1)
                    .durationMs(System.currentTimeMillis() - startTime)
                    .build();
        } catch (Exception e) {
            return SourceRefreshResponse.builder().status("error").build();
        }
    }

    @Override
    protected MarathonEvent parseEventPayload(MatchCache match) {
        try {
            return objectMapper.readValue(match.getJsonPayload(), MarathonEvent.class);
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    protected OddsUpdateRequest buildOddsUpdateRequest(MatchCache match) {
        MarathonEvent event = parseEventPayload(match);
        if (event == null) return null;
        return oddsMapper.buildOddsUpdateRequest(event);
    }

    @Override
    protected List<OddItem> processOdds(MatchCache match, MarathonEvent event, SportType sportType) {
        return oddsMapper.processOdds(event, sportType);
    }

    public void discoverEvents() {
        // Not used as queueLeagues is the entry point
    }

    @Override
    protected void processEventDiscovery(MarathonEvent event, boolean isLive) throws Exception {
        discoveryService.saveOrUpdateEvent(event);
    }

    public SourceStatsResponse getStats() {
        return SourceStatsResponse.builder()
                .totalCached(matchCacheRepository.count())
                .liveEvents((long) matchCacheRepository.findByIsLiveTrue().size())
                .totalProcessed(totalProcessed.get())
                .totalUpdated(totalUpdated.get())
                .build();
    }
}
