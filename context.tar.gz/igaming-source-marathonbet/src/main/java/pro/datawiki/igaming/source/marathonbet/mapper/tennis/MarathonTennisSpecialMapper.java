package pro.datawiki.igaming.source.marathonbet.mapper.tennis;

import org.springframework.stereotype.Component;
import pro.datawiki.igaming.dto.BetType;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.dto.market.BetScope;
import pro.datawiki.igaming.source.core.mapper.AbstractBetTypeMapper;

@Component
public class MarathonTennisSpecialMapper extends AbstractBetTypeMapper {

    @Override
    public boolean supports(String bookmaker, SportType sportType) {
        return "marathonbet".equals(bookmaker) && sportType == SportType.TENNIS;
    }

    @Override
    public BetType map(String m, String o) {
        if (m == null || o == null) return null;

        // 5. Correct Score (Sets)
        if ("SET_BETTING".equals(m) || "CORRECT_SCORE".equals(m)) {
            return mapCorrectScoreRecord(o, BetScope.FULL_MATCH);
        }

        return null;
    }
}
