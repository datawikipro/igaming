package pro.datawiki.igaming.source.marathonbet.scheduler;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import pro.datawiki.igaming.source.marathonbet.service.MatchService;

/**
 * Periodically triggers global league discovery.
 */
@Component
@RequiredArgsConstructor
@Slf4j
@ConditionalOnProperty(name = "app.role", havingValue = "league-crawler", matchIfMissing = true)
public class MatchFetchScheduler {

    private final MatchService matchService;

    @Scheduled(fixedDelayString = "${app.marathonbet.queue-interval-seconds:300}000")
    public void queueLeagues() {
        log.debug("Starting scheduled league queueing (master role)...");
        matchService.queueLeagues();
    }

    @Scheduled(fixedDelayString = "${app.marathonbet.process-interval-seconds:5}000")
    public void processLeagues() {
        log.debug("Checking for pending leagues to process...");
        matchService.processPendingLeagues(3);
    }
}
