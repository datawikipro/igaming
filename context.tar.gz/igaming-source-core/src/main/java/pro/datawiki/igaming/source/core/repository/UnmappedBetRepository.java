package pro.datawiki.igaming.source.core.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import pro.datawiki.igaming.source.core.domain.UnmappedBet;
import java.util.Optional;

@Repository
public interface UnmappedBetRepository extends JpaRepository<UnmappedBet, Long> {
    Optional<UnmappedBet> findFirstBySportNameAndRawName(String sportName, String rawName);
}
