package pro.datawiki.igaming.source.core.engine.fonbet.mapper;

import org.springframework.stereotype.Component;
import pro.datawiki.igaming.dto.BetType;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.dto.market.BetScope;
import pro.datawiki.igaming.dto.market.BetSubject;
import pro.datawiki.igaming.dto.market.BinaryMarketBet;
import pro.datawiki.igaming.dto.market.StatType;
import pro.datawiki.igaming.source.core.mapper.AbstractBetTypeMapper;

import java.util.Map;
import java.util.Set;

@Component
public class FonbetCommonSpecialMapper extends AbstractBetTypeMapper {

    private static final Set<SportType> SPECIALIZED_SPORTS = Set.of(
            SportType.FOOTBALL, SportType.BASKETBALL, SportType.HOCKEY, SportType.TENNIS,
            SportType.ESPORTS, SportType.CYBER_FOOTBALL, SportType.CYBER_BASKETBALL, SportType.CYBER_HOCKEY,
            SportType.VOLLEYBALL, SportType.BEACH_VOLLEYBALL, SportType.TABLE_TENNIS
    );

    private static final Map<String, BinaryMarketBet.Outcome> BTTS_MAP = Map.of(
            "1845", BinaryMarketBet.Outcome.YES,
            "1846", BinaryMarketBet.Outcome.NO,
            "4241", BinaryMarketBet.Outcome.YES,
            "4242", BinaryMarketBet.Outcome.NO
    );

    @Override
    public boolean supports(String bookmaker, SportType sportType) {
        return "fonbet".equals(bookmaker) && !SPECIALIZED_SPORTS.contains(sportType);
    }

    @Override
    public BetType map(String market, String outcome) {
        if (outcome == null) return null;
        BinaryMarketBet.Outcome res = BTTS_MAP.get(outcome);
        if (res == null) return null;

        BetScope scope = resolveScope(market);
        
        return new BinaryMarketBet(scope, BetSubject.MATCH, BinaryMarketBet.MarketType.BTTS, res, StatType.MATCH);
    }

    private BetScope resolveScope(String market) {
        if (market == null) return BetScope.FULL_MATCH;
        String m = market.toLowerCase();
        if (m.contains("1-й тайм")) return BetScope.HALF_1;
        if (m.contains("2-й тайм")) return BetScope.HALF_2;
        return BetScope.FULL_MATCH;
    }
}
