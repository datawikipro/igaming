package pro.datawiki.igaming.source.marathonbet.mapper.hockey;

import org.springframework.stereotype.Component;
import pro.datawiki.igaming.dto.BetType;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.dto.market.*;
import pro.datawiki.igaming.source.core.mapper.AbstractBetTypeMapper;

@Component
public class MarathonHockeyTotalMapper extends AbstractBetTypeMapper {

    @Override
    public boolean supports(String bookmaker, SportType sportType) {
        return "marathonbet".equals(bookmaker) && sportType == SportType.HOCKEY;
    }

    @Override
    public BetType map(String m, String o) {
        if (m == null || o == null) return null;

        // --- Totals ---
        if (m.matches("^(TOTAL_GOALS|TOTAL_POINTS)$")) {
            if ("ODD".equals(o)) return new BinaryMarketBet(BetScope.FULL_MATCH, BetSubject.MATCH, BinaryMarketBet.MarketType.ODD_EVEN, BinaryMarketBet.Outcome.ODD, StatType.MATCH);
            if ("EVEN".equals(o)) return new BinaryMarketBet(BetScope.FULL_MATCH, BetSubject.MATCH, BinaryMarketBet.MarketType.ODD_EVEN, BinaryMarketBet.Outcome.EVEN, StatType.MATCH);
            return mapTotalRecord(o, BetScope.FULL_MATCH, BetSubject.MATCH, StatType.MATCH, false);
        }
        if ("ASIAN_TOTAL_GOALS".equals(m)) {
            return mapTotalRecord(o, BetScope.FULL_MATCH, BetSubject.MATCH, StatType.MATCH, true);
        }
        if (m.matches("^(TOTAL_GOALS|TEAM1_TOTAL_GOALS)_\\(FIRST_TEAM\\)$") || "TEAM1_TOTAL_GOALS".equals(m)) {
            return mapTotalRecord(o, BetScope.FULL_MATCH, BetSubject.TEAM1, StatType.MATCH, false);
        }
        if (m.matches("^(TOTAL_GOALS|TEAM2_TOTAL_GOALS)_\\(SECOND_TEAM\\)$") || "TEAM2_TOTAL_GOALS".equals(m)) {
            return mapTotalRecord(o, BetScope.FULL_MATCH, BetSubject.TEAM2, StatType.MATCH, false);
        }
        if ("TOTAL_GOALS_-_1ST_PERIOD".equals(m)) return mapTotalRecord(o, BetScope.PERIOD_1, BetSubject.MATCH, StatType.MATCH, false);

        return null;
    }
}
