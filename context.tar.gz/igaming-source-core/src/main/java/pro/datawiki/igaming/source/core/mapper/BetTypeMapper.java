package pro.datawiki.igaming.source.core.mapper;

import pro.datawiki.igaming.dto.BetType;
import pro.datawiki.igaming.dto.SportType;

/**
 * Universal interface for sport-specific bet type mapping across different bookmakers.
 * Each implementation handles a specific (bookmaker, sport) combination.
 */
public interface BetTypeMapper {

    /**
     * Checks if this mapper supports the given bookmaker and sport.
     * @param bookmaker The bookmaker identifier (e.g., "marathonbet")
     * @param sportType Canonical sport type
     * @return true if supported
     */
    boolean supports(String bookmaker, SportType sportType);

    /**
     * Resolves the market and outcome to a canonical BetType.
     * @param m Normalized market name
     * @param o Normalized outcome name
     * @return Resolved BetType or null if not handled by this mapper
     */
    BetType map(String m, String o);

    /**
     * Result of a mapping attempt, carrying the resolved BetType and the name of the mapper that produced it.
     * Used by {@link pro.datawiki.igaming.source.core.service.BetTypeResolverService} for conflict diagnostics.
     */
    record MappingResult(BetType betType, String mapperName) {}
}
