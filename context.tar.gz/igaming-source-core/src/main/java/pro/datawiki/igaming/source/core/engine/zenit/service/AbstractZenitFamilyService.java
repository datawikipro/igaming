package pro.datawiki.igaming.source.core.engine.zenit.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.transaction.annotation.Transactional;
import pro.datawiki.igaming.dto.OddItem;
import pro.datawiki.igaming.dto.OddsUpdateRequest;
import pro.datawiki.igaming.source.core.aggregator.AggregatorClient;
import pro.datawiki.igaming.source.core.domain.MatchCache;
import pro.datawiki.igaming.source.core.domain.MatchFactor;
import pro.datawiki.igaming.source.core.domain.SportCache;
import pro.datawiki.igaming.source.core.engine.zenit.dto.ZenitGame;
import pro.datawiki.igaming.source.core.engine.zenit.dto.ZenitOdd;
import pro.datawiki.igaming.source.core.engine.zenit.dto.ZenitResponse;
import pro.datawiki.igaming.source.core.engine.zenit.dto.ZenitSport;
import pro.datawiki.igaming.source.core.repository.MatchCacheRepository;
import pro.datawiki.igaming.source.core.repository.SportCacheRepository;
import pro.datawiki.igaming.source.core.service.UnmappedBetService;
import pro.datawiki.igaming.source.core.validation.JsonValidationService;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.dto.BetType;
import pro.datawiki.igaming.source.core.service.BetTypeResolverService;
import pro.datawiki.igaming.source.core.service.SportNormalizationService;
import pro.datawiki.igaming.source.core.service.AbstractApiErrorTracker;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.LocalDateTime;
import java.util.*;

@Slf4j
public abstract class AbstractZenitFamilyService {

    protected final MatchCacheRepository matchCacheRepository;
    protected final SportCacheRepository sportCacheRepository;
    protected final AggregatorClient aggregatorClient;
    protected final ObjectMapper objectMapper;
    protected final JsonValidationService jsonValidationService;
    protected final UnmappedBetService unmappedBetService;
    protected final SportNormalizationService sportNormalizationService;
    protected final BetTypeResolverService betTypeResolver;
    protected AbstractApiErrorTracker errorTracker;

    public AbstractZenitFamilyService(MatchCacheRepository matchCacheRepository,
                                     SportCacheRepository sportCacheRepository,
                                     AggregatorClient aggregatorClient,
                                     ObjectMapper objectMapper,
                                     JsonValidationService jsonValidationService,
                                     UnmappedBetService unmappedBetService,
                                     SportNormalizationService sportNormalizationService,
                                     BetTypeResolverService betTypeResolver) {
        this.matchCacheRepository = matchCacheRepository;
        this.sportCacheRepository = sportCacheRepository;
        this.aggregatorClient = aggregatorClient;
        this.objectMapper = objectMapper;
        this.jsonValidationService = jsonValidationService;
        this.unmappedBetService = unmappedBetService;
        this.sportNormalizationService = sportNormalizationService;
        this.betTypeResolver = betTypeResolver;
    }

    @Value("${app.bookmaker.name:zenit}")
    protected String bookmakerName;

    @Value("${app.bookmaker.region:ru}")
    protected String region;

    /**
     * Discovery role: processes the full line JSON and saves metadata to MatchCache.
     */
    public int discoverEvents(String json, boolean isLive) {
        if (json == null || json.isEmpty()) {
            return 0;
        }

        // 1. Strict JSON Schema Validation
        try {
            jsonValidationService.validate(json, "zenit-schema.json");
        } catch (Exception e) {
            log.error("CRITICAL: Zenit API structure changed! Skipping discovery cycle. Error: {}", e.getMessage());
            if (errorTracker != null) {
                errorTracker.recordError("Validation failed: " + e.getMessage());
            }
            return 0;
        }

        ZenitResponse response;
        try {
            response = objectMapper.readValue(json, ZenitResponse.class);
        } catch (Exception e) {
            log.error("Failed to deserialize ZenitResponse: {}", e.getMessage());
            return 0;
        }

        if (response == null || response.getGames() == null || response.getGames().isEmpty()) {
            return 0;
        }

        Map<Integer, String> sportNames = new HashMap<>();
        if (response.getSport() != null) {
            for (ZenitSport s : response.getSport()) {
                if (s.getId() != null && s.getNm() != null) {
                    sportNames.put(s.getId(), s.getNm());
                    saveSport(s);
                }
            }
        }

        int discoveredCount = 0;
        for (Map.Entry<String, ZenitGame> entry : response.getGames().entrySet()) {
            String externalId = entry.getKey();
            ZenitGame game = entry.getValue();

            try {
                saveOrUpdateMatchMetadata(externalId, game, sportNames, isLive);
                discoveredCount++;
            } catch (Exception e) {
                log.error("Error saving metadata for Zenit event {}: {}", externalId, e.getMessage());
            }
        }

        log.info("[{}/{}] Discovered {} {} events", bookmakerName, region, discoveredCount, isLive ? "live" : "prematch");
        return discoveredCount;
    }

    /**
     * Backward-compatible method: simply calls discoverEvents.
     */
    public int processResponse(String json, boolean isLive) {
        return discoverEvents(json, isLive);
    }

    protected void saveOrUpdateMatchMetadata(String externalId, ZenitGame game, Map<Integer, String> sportNames, boolean isLive) {
        Optional<MatchCache> existing = matchCacheRepository.findByExternalId(externalId);

        MatchCache match = existing.orElseGet(MatchCache::new);
        match.setExternalId(externalId);
        
        if (game.getSid() != null) {
            match.setSportId(game.getSid());
            match.setSportName(sportNames.getOrDefault(game.getSid(), "Sport_" + game.getSid()));
        }

        String t1 = game.getU1() != null ? game.getU1() : game.getTeam1();
        String t2 = game.getU2() != null ? game.getU2() : game.getTeam2();
        if (t1 == null || t1.equals("null")) t1 = "Team1_" + externalId;
        if (t2 == null || t2.equals("null")) t2 = "Team2_" + externalId;

        match.setTeam1(t1);
        match.setTeam2(t2);

        if (game.getTime() != null) {
            long ts = game.getTime();
            if (ts < 10000000000L) ts *= 1000;
            match.setStartTime(ts);
        }

        match.setIsLive(isLive);
        
        if (game.getScore() != null) {
            String scoreStr = game.getScore().split(" ")[0];
            String[] scores = scoreStr.split(":");
            if (scores.length >= 2) {
                match.setScore1(scores[0]);
                match.setScore2(scores[1]);
            }
        }

        match.setUpdatedAt(LocalDateTime.now());
        if (match.getCreatedAt() == null) {
            match.setCreatedAt(LocalDateTime.now());
        }

        String jsonPayload;
        try {
            jsonPayload = objectMapper.writeValueAsString(game);
        } catch (Exception e) {
            jsonPayload = "{}";
        }

        String newHash = computeHash(jsonPayload);
        if (match.getPayloadHash() == null || !match.getPayloadHash().equals(newHash)) {
            match.setStatus(MatchCache.Status.NEW);
        }

        match.setJsonPayload(jsonPayload);
        match.setPayloadHash(newHash);
        
        // Relational factors sync
        syncFactors(match, game);
        
        matchCacheRepository.save(match);
    }

    /**
     * Match-loader worker role: continuously pops the oldest matches from DB and enriches them.
     */
    @Transactional
    public int loadMatchCards(int batchSize) {
        List<MatchCache> batch = matchCacheRepository.findAndLockOnlyNewPendingMatches(org.springframework.data.domain.PageRequest.of(0, batchSize));

        if (batch.isEmpty()) return 0;
        int processed = 0;

        for (MatchCache cache : batch) {
            try {
                pushToAggregator(cache);
                
                cache.setStatus(MatchCache.Status.PROCESSED);
                cache.setUpdatedAt(LocalDateTime.now());
                matchCacheRepository.save(cache);
                processed++;
            } catch (Exception e) {
                log.error("Failed to load Zenit match card for {}: {}", cache.getExternalId(), e.getMessage());
                cache.setStatus(MatchCache.Status.FAILED);
                cache.setUpdatedAt(LocalDateTime.now());
                matchCacheRepository.save(cache);
            }
        }
        return processed;
    }

    protected void pushToAggregator(MatchCache match) {
        ZenitGame game;
        try {
            game = objectMapper.readValue(match.getJsonPayload(), ZenitGame.class);
        } catch (Exception e) {
            log.error("Failed to parse cached payload for {}: {}", match.getExternalId(), e.getMessage());
            return;
        }

        OddsUpdateRequest request = buildOddsUpdateRequest(match, game);
        List<OddItem> odds = processOdds(match, game, request.getSportType());

        if (!odds.isEmpty()) {
            request.setOdds(odds);
            aggregatorClient.pushOddsUpdate(request);
        }
    }

    private OddsUpdateRequest buildOddsUpdateRequest(MatchCache match, ZenitGame game) {
        OddsUpdateRequest request = new OddsUpdateRequest();
        request.setBookmaker(bookmakerName);
        request.setRegion(region);
        request.setEventUrl(generateEventUrl(match, game, match.getIsLive()));
        request.setExternalEventId(match.getExternalId());
        request.setSportName(match.getSportName());
        request.setTeam1(match.getTeam1());
        request.setTeam2(match.getTeam2());
        request.setScore1(match.getScore1());
        request.setScore2(match.getScore2());
        request.setStartTime(match.getStartTime());
        request.setIsLive(match.getIsLive());
        request.setPayloadHash(match.getPayloadHash());

        SportType sportType = resolveZenitSportType(match.getSportName());
        request.setSportType(sportType);
        return request;
    }

    private List<OddItem> processOdds(MatchCache match, ZenitGame game, SportType sportType) {
        List<OddItem> odds = new ArrayList<>();
        Map<String, OddItem> resolvedOdds = new HashMap<>();

        if (game.getF_l() != null) {
            for (ZenitOdd odd : game.getF_l()) {
                if (odd.getH() != null) {
                    Integer factorId = odd.getO();
                    String rawName = odd.getOddKey() != null ? odd.getOddKey() : String.valueOf(factorId);
                    BetType betType = betTypeResolver.resolve("zenit", sportType, rawName, String.valueOf(factorId));

                    if ("UNKNOWN".equals(betType.code())) {
                        unmappedBetService.saveAndNotify(bookmakerName, sportType.name(), rawName, "ZENIT_MAIN", match.getExternalId());
                        continue;
                    }

                    // Inject param into parametric bet types (totals, handicaps)
                    if (betType.isParametric() && rawName != null) {
                        try {
                            // Find the last number in the string (often in parens or at the end like "Тотал 2.5 Больше")
                            java.util.regex.Matcher m = java.util.regex.Pattern.compile("[-+]?\\d*\\.\\d+|[-+]?\\d+").matcher(rawName);
                            double lastParam = 0.0;
                            boolean found = false;
                            while (m.find()) {
                                // Skip standalone 1 or 2 as they might be team indices "ИТ1", "Фора 1" unless it's the only number
                                double val = Double.parseDouble(m.group());
                                if (m.group().contains(".") || (val != 1.0 && val != 2.0)) {
                                    lastParam = val;
                                    found = true;
                                } else if (!found) {
                                    lastParam = val;
                                }
                            }
                            if (lastParam != 0.0) {
                                betType = betType.withParam(lastParam * betType.paramMultiplier());
                            }
                        } catch (NumberFormatException | UnsupportedOperationException ignored) {}
                    }

                    OddItem item = new OddItem();
                    item.setFactorId(factorId != null ? factorId : 0);
                    item.setName(rawName);
                    item.setValue(odd.getH());
                    item.setBetType(betType);

                    // Semantic duplicate check
                    String semanticKey = betType.code();
                    if (resolvedOdds.containsKey(semanticKey)) {
                        OddItem existing = resolvedOdds.get(semanticKey);
                        if (!existing.getValue().equals(item.getValue())) {
                            log.error("DUPLICATE COEFFICIENT ATTEMPT: Tried to map 1 coefficient twice with DIFFERENT values! " +
                                      "Event={}, SemanticKey={}, ExistingValue={}, NewValue={}, ExistingOriginalName='{}', NewOriginalName='{}'",
                                      match.getExternalId(), semanticKey, existing.getValue(), item.getValue(),
                                      existing.getName(), item.getName());
                        }
                        continue;
                    }

                    resolvedOdds.put(semanticKey, item);
                    odds.add(item);
                }
            }
        }
        return odds;
    }

    private void syncFactors(MatchCache match, ZenitGame game) {
        if (game.getF_l() == null) return;
        match.getFactors().clear();
        for (ZenitOdd odd : game.getF_l()) {
            if (odd.getH() != null) {
                MatchFactor factor = new MatchFactor();
                factor.setMatch(match);
                factor.setFactorId(odd.getO() != null ? odd.getO() : 0);
                factor.setName(odd.getOddKey() != null ? odd.getOddKey() : String.valueOf(odd.getO()));
                factor.setValue(odd.getH());
                match.getFactors().add(factor);
            }
        }
    }

    private Double parseDoubleSafe(String value) {
        if (value == null || value.isEmpty()) return null;
        try {
            return Double.parseDouble(value);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private String computeHash(String content) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(content.getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(hash);
        } catch (Exception e) {
            return String.valueOf(content.hashCode());
        }
    }

    private void saveSport(ZenitSport s) {
        try {
            Optional<SportCache> existing = sportCacheRepository.findByExternalId(s.getId());
            SportCache sport = existing.orElseGet(SportCache::new);
            sport.setExternalId(s.getId());
            sport.setName(s.getNm());
            sport.setUpdatedAt(LocalDateTime.now());
            sportCacheRepository.save(sport);
        } catch (Exception e) {
            log.trace("Sport cache save ignored: {}", e.getMessage());
        }
    }

    protected SportType resolveZenitSportType(String sportName) {
        if (sportName == null) return SportType.UNKNOWN;
        
        // 1. Source-specific ID overrides from "old alias table"
        String s = sportName.toUpperCase();
        if (s.contains("SPORT_26")) return SportType.FLOORBALL;
        if (s.contains("SPORT_134")) return SportType.ESPORTS;
        if (s.contains("SPORT_177")) return SportType.CYBER_FOOTBALL;
        if (s.contains("SPORT_32")) return SportType.BASEBALL;
        if (s.contains("SPORT_41")) return SportType.MMA;

        // 2. Centralized normalization (covers common Russian and English names)
        return sportNormalizationService.normalize(sportName);
    }

    protected abstract String generateEventUrl(MatchCache match, ZenitGame game, boolean isLive);

    public void setErrorTracker(AbstractApiErrorTracker errorTracker) {
        this.errorTracker = errorTracker;
    }
}
