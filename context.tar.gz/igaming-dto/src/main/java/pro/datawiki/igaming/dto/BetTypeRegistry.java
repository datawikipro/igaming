package pro.datawiki.igaming.dto;

import java.util.*;
import pro.datawiki.igaming.dto.market.*;

/**
 * Central registry of all BetType implementations.
 * Used by {@link BetTypeDeserializer} to resolve code strings back to enum constants.
 */
public final class BetTypeRegistry {

    private static final Map<String, BetType> REGISTRY = new HashMap<>();

    static {
        // Register common MatchResult outcomes for FULL_MATCH scope
        for (MatchResultBet.Outcome outcome : MatchResultBet.Outcome.values()) {
            register(new MatchResultBet(BetScope.FULL_MATCH, outcome, null));
        }

        // Register common BinaryMarket outcomes for FULL_MATCH scope
        for (BinaryMarketBet.MarketType market : BinaryMarketBet.MarketType.values()) {
            for (BinaryMarketBet.Outcome outcome : BinaryMarketBet.Outcome.values()) {
                register(new BinaryMarketBet(BetScope.FULL_MATCH, BetSubject.MATCH, market, outcome, null));
            }
        }
    }

    private BetTypeRegistry() {
        // utility class
    }

    /**
     * Resolve a code string to BetType.
     * Returns UnknownBet if the code is not registered.
     */
    public static BetType fromCode(String code) {
        if (code == null || code.isEmpty()) return new UnknownBet();
        
        BetType type = REGISTRY.get(code);
        if (type != null) return type;

        // Fallback for parametric types like TOTAL_OVER_2.5
        if (code.contains("TOTAL_")) {
            return parseTotalBet(code);
        }
        if (code.contains("HANDICAP_")) {
            return parseHandicapBet(code);
        }

        return new UnknownBet(code, null);
    }

    private static BetType parseTotalBet(String code) {
        try {
            // Very basic parser for FULL_MATCH scope
            // Expected format: [SCOPE_][SUBJECT_]TOTAL_DIRECTION_PARAM
            String[] parts = code.split("_");
            TotalBet.Direction dir = TotalBet.Direction.valueOf(parts[parts.length - 2]);
            double param = Double.parseDouble(parts[parts.length - 1]);
            return new TotalBet(BetScope.FULL_MATCH, BetSubject.MATCH, dir, param, false, null);
        } catch (Exception e) {
            return new UnknownBet(code, null);
        }
    }

    private static BetType parseHandicapBet(String code) {
        try {
            // Expected format: HANDICAP_TEAM_PARAM
            String[] parts = code.split("_");
            HandicapBet.Team team = HandicapBet.Team.valueOf(parts[parts.length - 2]);
            double param = Double.parseDouble(parts[parts.length - 1]);
            return new HandicapBet(BetScope.FULL_MATCH, team, param, false, null);
        } catch (Exception e) {
            return new UnknownBet(code, null);
        }
    }

    private static void register(BetType type) {
        REGISTRY.put(type.code(), type);
    }

    public static Set<String> allCodes() {
        return Collections.unmodifiableSet(REGISTRY.keySet());
    }

    private static void register(BetType[] types) {
        for (BetType t : types) {
            REGISTRY.put(t.code(), t);
        }
    }

    /**
     * Attempts to resolve a raw odds name into a BetType using regex patterns.
     * Supports Totals (Over/Under), Handicaps, and Match Results.
     */
    public static Optional<BetType> resolve(String rawName) {
        if (rawName == null || rawName.isEmpty()) return Optional.empty();

        String normalized = rawName.toUpperCase().replace(" ", "").replace(",", ".");

        // 1. Totals: "Over 2.5", "Больше 2.5", "Tm(2.5)", "T Over 2.5"
        if (normalized.matches(".*(OVER|UNDER|ТБ|ТМ|БОЛЬШЕ|МЕНЬШЕ|TOTAL|ТОТАЛ).*\\d+.*")) {
             try {
                 double param = extractNumeric(normalized);
                 TotalBet.Direction dir = normalized.matches(".*(OVER|ТБ|БОЛЬШЕ).*") ? TotalBet.Direction.OVER : TotalBet.Direction.UNDER;
                 return Optional.of(new TotalBet(BetScope.FULL_MATCH, BetSubject.MATCH, dir, param, false, null));
             } catch (Exception ignored) {}
        }

        // 2. Handicaps: "1 (-1.5)", "F1(-1.5)", "Фора 1 (-1.5)", "1 (+2.5)"
        if (normalized.matches(".*(F|Ф|HANDICAP|ФОРА)[12].*\\d+.*") || 
            normalized.matches("^[12]\\([-+]?\\d*\\.?\\d+\\)$")) {
            try {
                double param = extractNumeric(normalized);
                HandicapBet.Team team = normalized.startsWith("1") ? HandicapBet.Team.TEAM1 : HandicapBet.Team.TEAM2;
                return Optional.of(new HandicapBet(BetScope.FULL_MATCH, team, param, false, null));
            } catch (Exception ignored) {}
        }

        // 3. Match Results: "1", "X", "2", "Draw"
        if (normalized.equals("1") || normalized.equals("W1") || normalized.equals("П1")) 
            return Optional.of(new MatchResultBet(BetScope.FULL_MATCH, MatchResultBet.Outcome.WIN1, null));
        if (normalized.equals("X") || normalized.equals("DRAW") || normalized.equals("НИЧЬЯ") || normalized.equals("ПХ")) 
            return Optional.of(new MatchResultBet(BetScope.FULL_MATCH, MatchResultBet.Outcome.DRAW, null));
        if (normalized.equals("2") || normalized.equals("W2") || normalized.equals("П2")) 
            return Optional.of(new MatchResultBet(BetScope.FULL_MATCH, MatchResultBet.Outcome.WIN2, null));

        return Optional.empty();
    }

    private static double extractNumeric(String text) {
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("-?\\d+(\\.\\d+)?").matcher(text);
        if (m.find()) return Double.parseDouble(m.group());
        throw new IllegalArgumentException("No numeric found");
    }
}
