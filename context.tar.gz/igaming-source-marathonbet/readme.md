# igaming-source-marathonbet

Сервис-источник для сбора данных о матчах и коэффициентах с **marathonbet.ru**.

## Архитектура

- **JSON API** — получение дерева спортов/лиг через `/su/react/event/menu/prematch`
- **HTML парсинг** — извлечение событий и коэффициентов через Jsoup из HTML-страниц лиг
- **Кэширование** — хеширование payload для обнаружения изменений, PostgreSQL для хранения
- **Агрегация** — отправка обновлений в `igaming-aggregator` через REST

## Конфигурация

| Переменная | Описание | По умолчанию |
|---|---|---|
| `SERVER_PORT` | Порт приложения | 3036 |
| `SPRING_DATASOURCE_URL` | JDBC URL PostgreSQL | `jdbc:postgresql://localhost:5432/igaming_source_marathonbet` |
| `AGGREGATOR_URL` | URL агрегатора | `http://localhost:3034` |
| `MARATHONBET_FETCH_INTERVAL` | Интервал опроса (сек) | 120 |
| `MARATHONBET_PREMATCH_FETCH_INTERVAL` | Интервал премatch (сек) | 300 |

## Порты

- **Приложение**: 3036
- **PostgreSQL (dev)**: 36432
- **Redis (dev)**: 6382

## API

| Метод | Путь | Описание |
|---|---|---|
| `POST` | `/api/matches/refresh` | Ручной запуск обновления |
| `GET` | `/api/matches` | Все кэшированные матчи |
| `GET` | `/api/matches/live` | Только live матчи |
| `GET` | `/api/matches/sport/{name}` | Матчи по виду спорта |
| `GET` | `/api/matches/stats` | Статистика обработки |
| `GET` | `/api/matches/health` | Healthcheck |

## Запуск

```bash
# Docker Compose
docker-compose up -d

# Maven
mvn clean compile
mvn spring-boot:run
```
