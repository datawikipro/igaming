package pro.datawiki.igaming.source.core.engine.betcity.mapper;

import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import pro.datawiki.igaming.dto.BetType;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.dto.market.BetScope;
import pro.datawiki.igaming.dto.market.BetSubject;
import pro.datawiki.igaming.dto.market.StatType;
import pro.datawiki.igaming.dto.market.TotalBet;
import pro.datawiki.igaming.source.core.mapper.AbstractBetTypeMapper;

import java.util.Set;

@Component
@Order(Ordered.LOWEST_PRECEDENCE)
public class BetcityCommonTotalMapper extends AbstractBetTypeMapper {

    private static final Set<SportType> SPECIALIZED_SPORTS = Set.of(
            SportType.FOOTBALL, SportType.BASKETBALL, SportType.HOCKEY, SportType.TENNIS,
            SportType.ESPORTS, SportType.CYBER_FOOTBALL, SportType.CYBER_BASKETBALL, SportType.CYBER_HOCKEY,
            SportType.VOLLEYBALL, SportType.BEACH_VOLLEYBALL, SportType.TABLE_TENNIS
    );

    @Override
    public boolean supports(String bookmaker, SportType sportType) {
        return bookmaker != null && bookmaker.toLowerCase().contains("betcity") && !SPECIALIZED_SPORTS.contains(sportType);
    }

    @Override
    public BetType map(String m, String o) {
        if (m == null || o == null) return null;
        String group = m.toLowerCase().trim();
        String outcome = o.toUpperCase().trim();

        if (group.matches(".*(тотал|total|tb|tm|т1|т2|tm_.*|tb_.*|t1m|t2m).*")) {
            BetSubject subject = BetSubject.MATCH;
            if (group.contains("индивидуальный тотал 1") || group.contains("индивидуальный тотал первого") || group.contains("т1")) subject = BetSubject.TEAM1;
            else if (group.contains("индивидуальный тотал 2") || group.contains("индивидуальный тотал второго") || group.contains("т2")) subject = BetSubject.TEAM2;
            
            if (outcome.startsWith("БО") || outcome.equals("OVER") || outcome.equals("Б") || outcome.equals("TB") || outcome.startsWith("KF_T_OVER") || outcome.startsWith("T_OVER")) {
                return new TotalBet(BetScope.FULL_MATCH, subject, TotalBet.Direction.OVER, 0.0, false, StatType.MATCH);
            }
            if (outcome.startsWith("МЕ") || outcome.equals("UNDER") || outcome.equals("М") || outcome.equals("TM") || outcome.startsWith("KF_T_UNDER") || outcome.startsWith("T_UNDER")) {
                return new TotalBet(BetScope.FULL_MATCH, subject, TotalBet.Direction.UNDER, 0.0, false, StatType.MATCH);
            }
        }

        return null;
    }
}
