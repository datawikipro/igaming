package pro.datawiki.igaming.source.core.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import pro.datawiki.igaming.dto.BetType;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.dto.market.UnknownBet;
import pro.datawiki.igaming.source.core.mapper.BetTypeMapper;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * Central bet type resolution service.
 * Iterates ALL eligible mappers and asserts exactly 1 match.
 * <ul>
 *   <li>0 matches → returns UnknownBet</li>
 *   <li>1 match  → returns the resolved BetType</li>
 *   <li>2+ matches → logs + persists conflict, returns null (bet is skipped)</li>
 * </ul>
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class BetTypeResolverService {

    private final List<BetTypeMapper> mappers;
    private final MappingConflictService conflictService;

    public BetType resolve(String bookmaker, SportType sportType, String market, String outcome) {
        return resolve(bookmaker, sportType, market, outcome, null);
    }

    public BetType resolve(String bookmaker, SportType sportType, String market, String outcome, String eventId) {
        List<BetTypeMapper.MappingResult> results = mappers.stream()
                .filter(mapper -> mapper.supports(bookmaker, sportType))
                .map(mapper -> {
                    BetType result = mapper.map(market, outcome);
                    return result != null
                            ? new BetTypeMapper.MappingResult(result, mapper.getClass().getSimpleName())
                            : null;
                })
                .filter(Objects::nonNull)
                .toList();

        if (results.isEmpty()) {
            return new UnknownBet(market, outcome);
        }

        if (results.size() == 1) {
            return results.get(0).betType();
        }

        // 2+ matches — conflict
        String conflictDetail = results.stream()
                .map(r -> r.mapperName() + "->" + r.betType().code())
                .collect(Collectors.joining(", "));

        conflictService.saveIfNew(
                bookmaker,
                sportType.name(),
                market,
                outcome,
                conflictDetail,
                eventId
        );

        return null;
    }
}
