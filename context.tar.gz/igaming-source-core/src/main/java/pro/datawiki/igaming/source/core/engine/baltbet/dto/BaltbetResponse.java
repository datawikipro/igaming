package pro.datawiki.igaming.source.core.engine.baltbet.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class BaltbetResponse {
    private Long serverTimeUtc;
    private List<BaltbetEvent> events;
}
