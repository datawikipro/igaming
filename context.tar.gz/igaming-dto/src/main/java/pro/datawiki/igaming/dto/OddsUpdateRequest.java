package pro.datawiki.igaming.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.Data;

import java.util.List;

/**
 * Shared DTO for sending odds updates from source services to the aggregator.
 * Used by: source-fonbet, source-winline → aggregator.
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class OddsUpdateRequest {
    private String bookmaker;       // "fonbet" or "winline"
    private String region;          // "ru", "com", "global", etc.
    private String eventUrl;        // Link to the match page
    private String externalEventId;
    private String sportName;
    private SportType sportType;
    private String leagueName;
    private String formatInfo;
    private String team1;
    private String team2;
    private String score1;
    private String score2;
    private Long startTime;
    private Boolean isLive;
    private String payloadHash;
    private List<OddItem> odds;

}