package pro.datawiki.igaming.source.marathonbet.mapper.basketball;

import org.springframework.stereotype.Component;
import pro.datawiki.igaming.dto.BetType;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.dto.market.*;
import pro.datawiki.igaming.source.core.mapper.AbstractBetTypeMapper;

@Component
public class MarathonBasketballTotalMapper extends AbstractBetTypeMapper {

    @Override
    public boolean supports(String bookmaker, SportType sportType) {
        return "marathonbet".equals(bookmaker) && sportType == SportType.BASKETBALL;
    }

    @Override
    public BetType map(String m, String o) {
        if (m == null || o == null) return null;
        String upperM = m.toUpperCase().trim();
        String upperO = o.toUpperCase().trim();

        // 4. Totals (Match & Asian)
        if (upperM.matches("^(TOTAL_POINTS|TOTAL_GOALS|ASIAN_TOTAL_GOALS)$")) {
            BetType tb = mapTotalRecord(upperO, BetScope.FULL_MATCH, BetSubject.MATCH, StatType.MATCH, upperM.contains("ASIAN"));
            if (tb != null) return tb;
            if ("ODD".equals(upperO)) return new BinaryMarketBet(BetScope.FULL_MATCH, BetSubject.MATCH, BinaryMarketBet.MarketType.ODD_EVEN, BinaryMarketBet.Outcome.ODD, StatType.MATCH);
            if ("EVEN".equals(upperO)) return new BinaryMarketBet(BetScope.FULL_MATCH, BetSubject.MATCH, BinaryMarketBet.MarketType.ODD_EVEN, BinaryMarketBet.Outcome.EVEN, StatType.MATCH);
        }

        // 5. Quarter Totals
        if (upperM.matches("^TOTAL_POINTS_-_([1-4])(ST|ND|RD|TH)_QUARTER$")) {
            String q = upperM.replaceAll("^TOTAL_POINTS_-_([1-4]).*", "$1");
            BetScope scope = switch (q) {
                case "1" -> BetScope.QUARTER_1;
                case "2" -> BetScope.QUARTER_2;
                case "3" -> BetScope.QUARTER_3;
                case "4" -> BetScope.QUARTER_4;
                default -> null;
            };
            if (scope != null) return mapTotalRecord(upperO, scope, BetSubject.MATCH, StatType.MATCH, false);
        }

        // 6. Team Totals
        if (upperM.contains("TOTAL_GOALS") || upperM.contains("TEAM1_TOTAL") || upperM.contains("TEAM2_TOTAL")) {
            boolean isTeam1 = upperM.contains("(FIRST_TEAM)") || upperM.contains("TEAM1");
            boolean isTeam2 = upperM.contains("(SECOND_TEAM)") || upperM.contains("TEAM2");
            boolean isAsian = upperM.contains("ASIAN");

            if (isTeam1) return mapTotalRecord(upperO, BetScope.FULL_MATCH, BetSubject.TEAM1, StatType.MATCH, isAsian);
            if (isTeam2) return mapTotalRecord(upperO, BetScope.FULL_MATCH, BetSubject.TEAM2, StatType.MATCH, isAsian);
        }

        return null;
    }
}
