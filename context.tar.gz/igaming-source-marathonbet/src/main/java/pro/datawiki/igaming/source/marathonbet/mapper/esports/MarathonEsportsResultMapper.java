package pro.datawiki.igaming.source.marathonbet.mapper.esports;

import org.springframework.stereotype.Component;
import pro.datawiki.igaming.dto.BetType;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.dto.market.BetScope;
import pro.datawiki.igaming.dto.market.StatType;
import pro.datawiki.igaming.source.core.mapper.AbstractBetTypeMapper;

@Component
public class MarathonEsportsResultMapper extends AbstractBetTypeMapper {

    @Override
    public boolean supports(String bookmaker, SportType sportType) {
        return "marathonbet".equals(bookmaker) && (sportType == SportType.ESPORTS || sportType == SportType.CYBER_FOOTBALL || sportType == SportType.CYBER_BASKETBALL || sportType == SportType.CYBER_HOCKEY);
    }

    @Override
    public BetType map(String m, String o) {
        if (m == null || o == null) return null;
        String upperM = m.toUpperCase().trim();
        String upperO = o.toUpperCase().trim();

        if (upperM.matches("^(RESULT|MATCH_RESULT|WIN_-_MATCH|MATCH_WINNER|1|2)$")) {
            BetScope scope = BetScope.FULL_MATCH;
            return map1X2Record(upperO, scope, StatType.MATCH);
        }

        if (upperM.matches("^RESULT_-_([1-5])(ST|ND|RD|TH)?_MAP$")) {
            String mapNum = upperM.replaceAll("^RESULT_-_([1-5]).*", "$1");
            BetScope scope = switch (mapNum) {
                case "1" -> BetScope.MAP_1;
                case "2" -> BetScope.MAP_2;
                case "3" -> BetScope.MAP_3;
                case "4" -> BetScope.MAP_4;
                case "5" -> BetScope.MAP_5;
                default -> null;
            };
            if (scope != null) return map1X2Record(upperO, scope, StatType.MATCH);
        }

        return null;
    }
}
