package pro.datawiki.igaming.dto.market;

import pro.datawiki.igaming.dto.BetType;

public record MatchResultBet(
        BetScope scope,
        Outcome outcome,
        StatType statType
) implements BetType {

    public enum Outcome { WIN1, DRAW, WIN2, WIN1_2WAY, WIN2_2WAY, DC_1X, DC_12, DC_X2 }

    @Override
    public String code() {
        return scope.prefix() + (statType != null ? statType.prefix() : "") + outcome.name();
    }

    @Override
    public String marketCode() {
        return scope.prefix() + (statType != null ? statType.prefix() : "") + (outcome.name().contains("2WAY") ? "MATCH_RESULT_2WAY" : "MATCH_RESULT");
    }

    @Override
    public String description() {
        return "Result " + outcome;
    }

    @Override
    public boolean isParametric() {
        return false;
    }
}
