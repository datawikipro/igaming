package pro.datawiki.igaming.source.core.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.MapsId;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "match_payload")
@Getter
@Setter
@NoArgsConstructor
public class MatchPayload {

    @Id
    private Long id;

    @OneToOne(fetch = FetchType.LAZY)
    @MapsId
    @JoinColumn(name = "match_id")
    private MatchCache match;

    @Column(name = "data", columnDefinition = "TEXT")
    private String data;

    public MatchPayload(MatchCache match, String data) {
        this.match = match;
        this.data = data;
    }
}
