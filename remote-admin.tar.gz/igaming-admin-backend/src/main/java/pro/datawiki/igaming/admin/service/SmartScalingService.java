package pro.datawiki.igaming.admin.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import pro.datawiki.igaming.admin.repository.ManagedInstanceRepository;
import pro.datawiki.igaming.admin.repository.ScalingConfigRepository;
import pro.datawiki.igaming.admin.entity.ManagedInstance;
import pro.datawiki.igaming.admin.entity.ScalingConfig;

import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class SmartScalingService {

    private final GeoScalingBalancerService geoScalingBalancerService;
    private final GcpHardwareService hardwareService;
    private final ScalingConfigRepository configRepository;
    private final ManagedInstanceRepository instanceRepository;
    private final KubernetesNodeService kubernetesNodeService;
    
    private static final String TARGET_COUNT_KEY = "target_worker_count";

    @Value("${SMART_SCALING_TARGET:2}")
    private int fallbackTarget;

    @Transactional
    public void setDesiredCount(int count) {
        log.info("Saving desired worker count to DB: {}", count);
        ScalingConfig config = configRepository.findById(TARGET_COUNT_KEY)
                .orElse(new ScalingConfig(TARGET_COUNT_KEY, fallbackTarget));
        config.setConfigValue(count);
        configRepository.save(config);
    }

    public int getDesiredCount() {
        return configRepository.findById(TARGET_COUNT_KEY)
                .map(ScalingConfig::getConfigValue)
                .orElse(fallbackTarget);
    }

    @Transactional
    public void syncTargetWithCurrentCount() {
        Map<String, GcpHardwareService.GcpNodeInfo> hardwareInstances = hardwareService.getGcpInstancesInfo();
        java.util.List<ManagedInstance> allManaged = instanceRepository.findAll();
        java.util.Map<String, ManagedInstance> managedMap = allManaged.stream()
                .collect(java.util.stream.Collectors.toMap(ManagedInstance::getInstanceName, m -> m));

        long activeLoaders = hardwareInstances.keySet().stream()
                .filter(name -> {
                    ManagedInstance m = managedMap.get(name);
                    return m != null && "LOADER".equalsIgnoreCase(m.getRole());
                })
                .count();
        
        log.info("Syncing Auto-Scaler Target to current active loaders count: {}", activeLoaders);
        setDesiredCount((int) activeLoaders);
    }


    public void reconcile() {
        int target = getDesiredCount();
        
        // 1. Get real-time hardware info from GCP
        Map<String, GcpHardwareService.GcpNodeInfo> hardwareInstances = hardwareService.getGcpInstancesInfo();
        
        // 2. Identify Active Loaders (RUNNING in GCP and have role=loader label)
        java.util.List<String> activeLoaders = hardwareInstances.entrySet().stream()
                .filter(e -> "RUNNING".equalsIgnoreCase(e.getValue().status()))
                .filter(e -> {
                    Map<String, String> labels = e.getValue().labels();
                    return labels != null && "loader".equalsIgnoreCase(labels.get("role"));
                })
                .map(Map.Entry::getKey)
                .toList();

        // 3. Identify Provisioning Loaders (PROVISIONING/STAGING in GCP and have role=loader label)
        java.util.List<String> provisioningLoaders = hardwareInstances.entrySet().stream()
                .filter(e -> {
                    String status = e.getValue().status();
                    return "PROVISIONING".equalsIgnoreCase(status) || "STAGING".equalsIgnoreCase(status);
                })
                .filter(e -> {
                    Map<String, String> labels = e.getValue().labels();
                    return labels != null && "loader".equalsIgnoreCase(labels.get("role"));
                })
                .map(Map.Entry::getKey)
                .toList();

        long totalLoaders = activeLoaders.size() + provisioningLoaders.size();
  
        log.info("Reconciling Loaders (GCP-based): active = {}, provisioning = {}, total = {}, target = {}", 
                activeLoaders.size(), provisioningLoaders.size(), totalLoaders, target);

        if (totalLoaders < target) {
            int toCreate = target - (int)totalLoaders;
            log.info("Scaling UP: creating {} new spot workers", toCreate);
            for (int i = 0; i < toCreate; i++) {
                try {
                    geoScalingBalancerService.provisionNode("ANY", "SPOT", "LOADER", "e2-custom-4-16384", false);
                } catch (Exception e) {
                    log.error("Failed to provision spot worker: {}", e.getMessage());
                }
            }
        } else if (totalLoaders > target) {
            int toDelete = (int)totalLoaders - target;
            log.info("Scaling DOWN: terminating {} spot workers", toDelete);
            
            // Prioritize deleting provisioning ones first if they are stuck
            java.util.List<String> combined = new java.util.ArrayList<>();
            combined.addAll(provisioningLoaders);
            combined.addAll(activeLoaders);
            
            combined.stream()
                .limit(toDelete)
                .forEach(name -> {
                    log.info("Auto-scaling: terminating instance {}", name);
                    geoScalingBalancerService.terminateInstance(name);
                });
        }
    }
}
