package pro.datawiki.igaming.source.core.browser;
 
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;
import com.microsoft.playwright.options.Proxy;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
 
import java.util.Map;
import java.util.Arrays;
import java.util.Objects;
 
@Service
@RequiredArgsConstructor
@Slf4j
public class BrowserService {
 
    private final ObjectMapper objectMapper;
    
    private Playwright playwright;
    private Browser browser;
    private BrowserContext sharedContext;
    private String lastProxyUri;
    private java.util.concurrent.atomic.AtomicInteger requestCounter = new java.util.concurrent.atomic.AtomicInteger(0);
    private static final int CONTEXT_ROTATION_THRESHOLD = 20;

    @PostConstruct
    public void init() {
        log.info("Initializing Universal Browser Service (Playwright)");
        Map<String, String> env = new java.util.HashMap<>(System.getenv());
        env.put("PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD", "1");
        playwright = Playwright.create(new Playwright.CreateOptions().setEnv(env));
    }

    private synchronized Browser getBrowser() {
        if (browser == null || !browser.isConnected()) {
            // Close dead browser if it exists
            if (browser != null) {
                log.warn("BrowserService: Browser is disconnected, recreating...");
                try { browser.close(); } catch (Exception ignored) {}
                browser = null;
            }
            // Also reset the shared context since it depends on the browser
            if (sharedContext != null) {
                try { sharedContext.close(); } catch (Exception ignored) {}
                sharedContext = null;
            }
            BrowserType.LaunchOptions options = new BrowserType.LaunchOptions()
                    .setHeadless(true)
                    .setArgs(Arrays.asList(
                        "--disable-blink-features=AutomationControlled",
                        "--disable-dev-shm-usage",
                        "--no-sandbox",
                        "--disable-gpu",
                        "--disable-extensions",
                        "--disable-background-networking",
                        "--disable-default-apps",
                        "--disable-translate",
                        "--address-family=ipv4",
                        "--js-flags=--max-old-space-size=512"
                    ));

            String proxyHost = System.getProperty("https.proxyHost");
            if (proxyHost == null || proxyHost.isEmpty()) {
                proxyHost = System.getProperty("http.proxyHost");
            }
            
            String proxyPort = System.getProperty("https.proxyPort");
            if (proxyPort == null || proxyPort.isEmpty()) {
                proxyPort = System.getProperty("http.proxyPort");
            }

            // Fallback to environment variables if system properties are missing
            if (proxyHost == null || proxyHost.isEmpty()) {
                proxyHost = System.getenv("IGAMING_VPN_PROXY_RU_SERVICE_HOST");
                if (proxyHost != null && !proxyHost.isEmpty()) {
                    proxyPort = System.getenv("IGAMING_VPN_PROXY_RU_SERVICE_PORT");
                    log.info("BrowserService: Using Proxy from IGAMING_VPN_PROXY_RU_SERVICE env: {}:{}", proxyHost, proxyPort);
                }
            }

            if (proxyHost == null || proxyHost.isEmpty()) {
                proxyHost = System.getenv("HTTPS_PROXY");
                if (proxyHost == null || proxyHost.isEmpty()) {
                    proxyHost = System.getenv("HTTP_PROXY");
                }
                // Handle possible http:// prefix in env var
                if (proxyHost != null && proxyHost.contains("://")) {
                     try {
                         java.net.URI uri = java.net.URI.create(proxyHost);
                         proxyHost = uri.getHost();
                         proxyPort = String.valueOf(uri.getPort());
                     } catch (Exception ignored) {}
                }
            }

            if (proxyHost != null && !proxyHost.trim().isEmpty()) {
                if (proxyPort == null || proxyPort.isEmpty()) {
                    proxyPort = "3128";
                }
                                // Sanitize host: Replace localhost with 127.0.0.1 to avoid IPv6/IPv4 resolution conflicts in Node/Playwright
                String sanitizedHost = proxyHost.trim();
                boolean isLocal = sanitizedHost.equalsIgnoreCase("localhost") || sanitizedHost.equals("127.0.0.1");
                
                if (sanitizedHost.equalsIgnoreCase("localhost")) {
                    sanitizedHost = "127.0.0.1";
                }

                String proxyUri;
                if (sanitizedHost.contains("://")) {
                    // Protocol already specified (e.g. socks5://127.0.0.1, http://proxy-service)
                    proxyUri = sanitizedHost + ":" + proxyPort;
                } else if (isLocal && Integer.parseInt(proxyPort) > 10000) {
                    // High local ports are usually SOCKS5 (e.g. from v2ray/clash)
                    proxyUri = "socks5://" + sanitizedHost + ":" + proxyPort;
                } else {
                    // Standard cluster proxies (like squid) use http
                    proxyUri = "http://" + sanitizedHost + ":" + proxyPort;
                }

                log.info("BrowserService: Using Proxy URI: {}", proxyUri);
                options.setProxy(new Proxy(proxyUri));
                this.lastProxyUri = proxyUri;
            } else {
                this.lastProxyUri = null;
            }

            browser = playwright.chromium().launch(options);
        } else {
            // Check if proxy has changed since last launch
            String currentProxyUri = getCurrentProxyUri();
            if (!Objects.equals(currentProxyUri, lastProxyUri)) {
                log.warn("BrowserService: Proxy changed from {} to {}. Recreating browser...", lastProxyUri, currentProxyUri);
                closeBrowser();
                return getBrowser(); // Recursive call will handle the re-launch
            }
        }
        return browser;
    }

    private void closeBrowser() {
        if (sharedContext != null) {
            try { sharedContext.close(); } catch (Exception ignored) {}
            sharedContext = null;
        }
        if (browser != null) {
            try { browser.close(); } catch (Exception ignored) {}
            browser = null;
        }
        requestCounter.set(0);
    }

    private String getCurrentProxyUri() {
        String proxyHost = System.getProperty("https.proxyHost");
        if (proxyHost == null || proxyHost.isEmpty()) {
            proxyHost = System.getProperty("http.proxyHost");
        }
        
        String proxyPort = System.getProperty("https.proxyPort");
        if (proxyPort == null || proxyPort.isEmpty()) {
            proxyPort = System.getProperty("http.proxyPort");
        }

        if (proxyHost == null || proxyHost.isEmpty()) return null;
        if (proxyPort == null || proxyPort.isEmpty()) proxyPort = "3128";
        
        return "http://" + proxyHost.trim() + ":" + proxyPort;
    }

    public synchronized BrowserContext getSharedContext() {
        if (sharedContext == null || !isContextAlive(sharedContext) || requestCounter.get() >= CONTEXT_ROTATION_THRESHOLD) {
            // Close dead or old context if it exists
            if (sharedContext != null) {
                if (requestCounter.get() >= CONTEXT_ROTATION_THRESHOLD) {
                    log.info("BrowserService: Rotating context after {} requests to reclaim memory", requestCounter.get());
                } else {
                    log.warn("BrowserService: Shared context is dead, recreating...");
                }
                try { sharedContext.close(); } catch (Exception ignored) {}
                sharedContext = null;
                requestCounter.set(0);
            }
            sharedContext = getBrowser().newContext(new Browser.NewContextOptions()
                    .setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36")
                    .setIgnoreHTTPSErrors(true));
        }
        return sharedContext;
    }

    private void incrementRequestCounter() {
        requestCounter.incrementAndGet();
    }

    private boolean isContextAlive(BrowserContext ctx) {
        try {
            // Trying to access pages is a lightweight way to check if context is still alive
            ctx.pages();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Lightweight API request without creating a full Page.
     * Use for JSON API endpoints that don't need DOM rendering.
     */
    public <T> T apiGet(String url, Class<T> responseType, int timeoutMs) {
        log.debug("API GET (no page): {}", url);
        try {
            incrementRequestCounter();
            com.microsoft.playwright.APIResponse response = getSharedContext().request().get(url,
                com.microsoft.playwright.options.RequestOptions.create()
                    .setTimeout(timeoutMs));
            if (response != null && response.ok()) {
                return objectMapper.readValue(response.body(), responseType);
            }
            log.error("API GET failed for {} (Status: {})", url,
                response != null ? response.status() : "null");
            return null;
        } catch (Exception e) {
            log.error("API GET error {}: {}", url, e.getMessage());
            return null;
        }
    }
 
    /**
     * Executes a POST request and parses JSON response into a DTO.
     */
    public <T> T postForObject(String url, Object body, Class<T> responseType, Map<String, String> extraHeaders, int timeoutMs) {
        log.info("Browser POST (JSON): {}", url);
        try (Page page = getSharedContext().newPage()) {
            incrementRequestCounter();
            if (extraHeaders != null) {
                page.setExtraHTTPHeaders(extraHeaders);
            }
            
            com.microsoft.playwright.APIResponse response = page.request().post(url, 
                com.microsoft.playwright.options.RequestOptions.create()
                    .setData(body)
                    .setTimeout(timeoutMs));
            
            if (response == null || !response.ok()) {
                log.error("Failed POST fetch from {} (Status: {}, Reason: {})", 
                    url, 
                    response != null ? response.status() : "null",
                    response != null ? response.statusText() : "null");
                return null;
            }
 
            byte[] bodyBytes = response.body();
            return objectMapper.readValue(bodyBytes, responseType);
        } catch (Exception e) {
            log.error("Error fetching {} via BrowserService (POST): {}", url, e.getMessage());
            return null;
        }
    }
 
    /**
     * Executes a GET request and parses JSON response into a DTO.
     */
    public <T> T getForObject(String url, Class<T> responseType, Map<String, String> extraHeaders, int timeoutMs) {
        log.info("Browser GET (JSON): {}", url);
        try (Page page = getSharedContext().newPage()) {
            incrementRequestCounter();
            com.microsoft.playwright.options.RequestOptions options = com.microsoft.playwright.options.RequestOptions.create()
                    .setTimeout(timeoutMs);
            
            if (extraHeaders != null) {
                for (Map.Entry<String, String> entry : extraHeaders.entrySet()) {
                    options.setHeader(entry.getKey(), entry.getValue());
                }
            }
            
            com.microsoft.playwright.APIResponse response = page.request().get(url, options);
            
            if (response == null || !response.ok()) {
                log.error("Failed JSON fetch from {} (Status: {}, Reason: {})", 
                    url, 
                    response != null ? response.status() : "null",
                    response != null ? response.statusText() : "null");
                return null;
            }

            byte[] bodyBytes = response.body();
            return objectMapper.readValue(bodyBytes, responseType);
        } catch (Exception e) {
            log.error("Error fetching {} via BrowserService: {}", url, e.getMessage());
            return null;
        }
    }
 
    /**
     * Executes a GET request and returns raw text.
     */
    public String getForString(String url, Map<String, String> extraHeaders) {
        log.info("Browser GET (String): {}", url);
        try (Page page = getSharedContext().newPage()) {
            incrementRequestCounter();
            com.microsoft.playwright.options.RequestOptions options = com.microsoft.playwright.options.RequestOptions.create();
            
            if (extraHeaders != null) {
                for (Map.Entry<String, String> entry : extraHeaders.entrySet()) {
                    options.setHeader(entry.getKey(), entry.getValue());
                }
            }
            
            com.microsoft.playwright.APIResponse response = page.request().get(url, options);
            if (response != null && response.ok()) {
                return response.text().trim();
            }
            
            log.warn("GET (String) request was not successful for {}. Status: {}, Reason: {}", 
                url, 
                response != null ? response.status() : "null",
                response != null ? response.statusText() : "null");
            
            return null;
        } catch (Exception e) {
            log.error("Error fetching raw string from {}: {}", url, e.getMessage());
            return null;
        }
    }

    /**
     * Navigates to a URL and waits for a specific duration to let JS execute.
     */
    public void navigateAndWait(String url, int waitMs) {
        log.info("Browser Navigate and Wait ({}ms): {}", waitMs, url);
        try (Page page = getSharedContext().newPage()) {
            incrementRequestCounter();
            page.navigate(url);
            page.waitForTimeout(waitMs);
        } catch (Exception e) {
            log.error("Error during navigateAndWait to {}: {}", url, e.getMessage());
        }
    }

    /**
     * Navigates fully to a URL (executes JavaScript, solves bot-protection challenges like Servicepipe),
     * waits for the page to be fully loaded, and returns the visible page body text.
     * Use this instead of getForString() when the target is behind a JS challenge.
     *
     * @param url       URL to navigate to
     * @param waitMs    time to wait for JS challenge to be solved (in ms)
     * @return page body text, or null on error
     */
    public String navigateAndGetBody(String url, int waitMs) {
        log.debug("Browser Navigate+GetBody ({}ms): {}", waitMs, url);
        try (Page page = getSharedContext().newPage()) {
            incrementRequestCounter();
            try {
                // Wait for full page load to ensure JS-heavy elements (like betting tables) are ready
                page.navigate(url, new Page.NavigateOptions()
                    .setWaitUntil(com.microsoft.playwright.options.WaitUntilState.LOAD)
                    .setTimeout(waitMs + 15000)); // Reduced from 40s to 15s to limit resource hold time
            } catch (com.microsoft.playwright.TimeoutError te) {
                log.warn("Navigation timed out for {}, but will attempt to extract available content", url);
            }
            
            // FAST-PATH OPTIMIZATION: If the response is already JSON, return it immediately.
            // This skips the 8-second NETWORKIDLE timeout for pure JSON API endpoints.
            try {
                com.microsoft.playwright.Locator pre = page.locator("pre").first();
                if (pre.isVisible()) {
                    String innerText = pre.innerText();
                    if (innerText != null && (innerText.trim().startsWith("{") || innerText.trim().startsWith("["))) {
                        return innerText.trim();
                    }
                }
            } catch (Exception ignored) {}

            try {
                // Wait until network is idle instead of blindly sleeping. Massively speeds up extraction!
                page.waitForLoadState(com.microsoft.playwright.options.LoadState.NETWORKIDLE, 
                    new Page.WaitForLoadStateOptions().setTimeout(waitMs));
            } catch (Exception e) {
                log.trace("Timeout waiting for NETWORKIDLE on {}: {}", url, e.getMessage());
            }
            
            // Check for JSON response again in case it appeared after NETWORKIDLE
            try {
                com.microsoft.playwright.Locator pre = page.locator("pre").first();
                if (pre.isVisible()) {
                    String innerText = pre.innerText();
                    if (innerText != null && (innerText.trim().startsWith("{") || innerText.trim().startsWith("["))) {
                        return innerText.trim();
                    }
                }
            } catch (Exception ignored) {}

            // Always return full HTML content so that caller (e.g. Jsoup) can parse structured data
            try {
                return page.content();
            } catch (com.microsoft.playwright.PlaywrightException e) {
                if (e.getMessage() != null && e.getMessage().contains("page is navigating")) {
                    log.warn("Page is navigating, waiting before extracting content: {}", url);
                    try {
                        page.waitForLoadState(com.microsoft.playwright.options.LoadState.LOAD, new Page.WaitForLoadStateOptions().setTimeout(5000));
                        return page.content();
                    } catch (Exception ex) {
                        log.error("Failed to extract content after wait on redirect for {}: {}", url, ex.getMessage());
                        return null;
                    }
                }
                throw e;
            }
        } catch (Exception e) {
            log.error("Error during navigateAndGetBody to {}: {}", url, e.getMessage());
            return null;
        }
    }

    /**
     * Diagnostic method to discover actual API endpoints by navigating to a URL and observing network responses.
     */
    public void dumpNetworkCalls(String targetUrl, int waitMs) {
        log.info("Dumping network calls for: {}", targetUrl);
        try (Page page = getSharedContext().newPage()) {
            incrementRequestCounter();
            page.onResponse(response -> {
                String url = response.url();
                if ((url.contains("events") || url.contains("list") || url.contains("line")) && !url.contains(".js") && !url.contains(".css")) {
                    log.warn("INTERCEPTED API RESPONSE: {} - Status: {}", url, response.status());
                }
            });
            page.navigate(targetUrl, new Page.NavigateOptions().setTimeout(waitMs + 20000));
            page.waitForTimeout(waitMs);
        } catch (Exception e) {
            log.error("Error dumping network calls to {}: {}", targetUrl, e.getMessage());
        }
    }
 
    @PreDestroy
    public void shutdown() {
        log.info("Shutting down Universal Browser Service");
        if (sharedContext != null) sharedContext.close();
        if (browser != null) browser.close();
        if (playwright != null) playwright.close();
    }
}
