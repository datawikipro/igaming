package pro.datawiki.igaming.source.core.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import pro.datawiki.igaming.source.core.domain.MatchCache;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.QueryHints;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import jakarta.persistence.QueryHint;
import org.springframework.data.domain.Pageable;

@Repository
public interface MatchCacheRepository extends JpaRepository<MatchCache, Long> {
    
    @EntityGraph(attributePaths = {"factors", "payloadEntity"})
    Optional<MatchCache> findByExternalId(String externalId);
    
    long countByStatus(MatchCache.Status status);

    List<MatchCache> findTop50ByStatusOrderByUpdatedAtAsc(MatchCache.Status status);

    List<MatchCache> findByIsLiveTrue();

    List<MatchCache> findBySportName(String sportName);

    List<MatchCache> findBySportNameAndIsLiveTrue(String sportName);

    @Query(value = """
            SELECT mc.* FROM match_cache mc
            ORDER BY 
              CASE WHEN mc.status = 'TARGETED_REFRESH' THEN 0 
                   WHEN mc.status = 'NEW' THEN 1 
                   WHEN mc.status = 'PROCESSED' THEN 2 
                   ELSE 3 END ASC, 
              mc.updated_at ASC
            LIMIT :limit
            FOR UPDATE OF mc SKIP LOCKED
            """, nativeQuery = true)
    List<MatchCache> _findAndLockPendingMatchesWithLimit(@Param("limit") int limit);

    default List<MatchCache> findAndLockPendingMatches(Pageable pageable) {
        return _findAndLockPendingMatchesWithLimit(pageable.getPageSize());
    }

    @Query(value = """
            SELECT mc.* FROM match_cache mc
            WHERE mc.status IN ('TARGETED_REFRESH', 'NEW')
            ORDER BY 
              CASE WHEN mc.status = 'TARGETED_REFRESH' THEN 0 
                   WHEN mc.status = 'NEW' THEN 1 
                   ELSE 2 END ASC, 
              mc.updated_at ASC
            LIMIT :limit
            FOR UPDATE OF mc SKIP LOCKED
            """, nativeQuery = true)
    List<MatchCache> _findAndLockOnlyNewPendingMatchesWithLimit(@Param("limit") int limit);

    default List<MatchCache> findAndLockOnlyNewPendingMatches(Pageable pageable) {
        return _findAndLockOnlyNewPendingMatchesWithLimit(pageable.getPageSize());
    }

    @Modifying
    @Query("UPDATE MatchCache mc SET mc.status = :status, mc.updatedAt = :updatedAt WHERE mc.id = :id")
    void updateStatus(@Param("id") Long id, @Param("status") MatchCache.Status status, @Param("updatedAt") LocalDateTime updatedAt);

    @Modifying
    @Query(value = "DELETE FROM match_factor WHERE match_id IN (SELECT id FROM match_cache WHERE status IN :statuses AND (updated_at < :time OR (updated_at IS NULL AND created_at < :time) OR (updated_at IS NULL AND created_at IS NULL)))", nativeQuery = true)
    void deleteFactorsForOldMatchesByStatus(@Param("statuses") List<String> statuses, @Param("time") LocalDateTime time);

    @Modifying
    @Query(value = "DELETE FROM match_payload WHERE match_id IN (SELECT id FROM match_cache WHERE status IN :statuses AND (updated_at < :time OR (updated_at IS NULL AND created_at < :time) OR (updated_at IS NULL AND created_at IS NULL)))", nativeQuery = true)
    void deletePayloadsForOldMatchesByStatus(@Param("statuses") List<String> statuses, @Param("time") LocalDateTime time);

    @Modifying
    @Query(value = "DELETE FROM match_cache WHERE status IN :statuses AND (updated_at < :time OR (updated_at IS NULL AND created_at < :time) OR (updated_at IS NULL AND created_at IS NULL))", nativeQuery = true)
    int deleteOldMatchesByStatus(@Param("statuses") List<String> statuses, @Param("time") LocalDateTime time);

    @Modifying
    @Query(value = "DELETE FROM match_factor WHERE match_id IN (SELECT id FROM match_cache WHERE (updated_at < :time OR (updated_at IS NULL AND created_at < :time) OR (updated_at IS NULL AND created_at IS NULL)))", nativeQuery = true)
    void deleteFactorsForAllOldMatches(@Param("time") LocalDateTime time);

    @Modifying
    @Query(value = "DELETE FROM match_payload WHERE match_id IN (SELECT id FROM match_cache WHERE (updated_at < :time OR (updated_at IS NULL AND created_at < :time) OR (updated_at IS NULL AND created_at IS NULL)))", nativeQuery = true)
    void deletePayloadsForAllOldMatches(@Param("time") LocalDateTime time);

    @Modifying
    @Query(value = "DELETE FROM match_cache WHERE (updated_at < :time OR (updated_at IS NULL AND created_at < :time) OR (updated_at IS NULL AND created_at IS NULL))", nativeQuery = true)
    int deleteAllOldMatches(@Param("time") LocalDateTime time);
}
