package pro.datawiki.igaming.dto.market;

public enum StatType {
    NONE(""),
    MATCH(""), // Alias for main match statistics
    CORNERS("CORNER_"),
    CARDS("CARDS_"),
    YELLOW_CARDS("CARDS_"),
    OFFSIDES("OFFSIDES_"),
    FOULS("FOULS_"),
    SHOTS_ON_TARGET("SOT_"),
    GAMES("GAMES_"),
    SETS("SETS_"),
    MAPS("MAPS_"),
    ROUNDS("ROUNDS_"),
    KILLS("KILLS_"),
    POINTS("POINTS_");

    private final String prefix;

    StatType(String prefix) {
        this.prefix = prefix;
    }

    public String prefix() {
        return prefix;
    }
}
