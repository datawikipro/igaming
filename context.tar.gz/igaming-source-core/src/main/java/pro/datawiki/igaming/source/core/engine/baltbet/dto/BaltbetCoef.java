package pro.datawiki.igaming.source.core.engine.baltbet.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class BaltbetCoef {
    @JsonProperty("o")
    private Long id;
    
    @JsonProperty("t")
    private Integer type;
    
    @JsonProperty("v")
    private Double value;
    
    @JsonProperty("x")
    private String param;
}
