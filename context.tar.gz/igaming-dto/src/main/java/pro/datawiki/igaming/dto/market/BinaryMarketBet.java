package pro.datawiki.igaming.dto.market;

import pro.datawiki.igaming.dto.BetType;

/**
 * Record for binary markets like BTTS, Odd/Even, etc.
 */
public record BinaryMarketBet(
        BetScope scope,
        BetSubject subject,
        MarketType marketType,
        Outcome outcome,
        StatType statType
) implements BetType {

    public enum MarketType { BTTS, ODD_EVEN, RED_CARD, CLEAN_SHEET, QUALIFY, OWN_GOAL }
    public enum Outcome { YES, NO, ODD, EVEN, OVER, UNDER }

    @Override
    public String code() {
        return scope.prefix() + subject.prefix() + (statType != null ? statType.prefix() : "") + marketType.name() + "_" + outcome.name();
    }

    @Override
    public String marketCode() {
        return scope.prefix() + subject.prefix() + (statType != null ? statType.prefix() : "") + marketType.name();
    }

    @Override
    public String description() {
        return marketType + " " + outcome;
    }

    @Override
    public boolean isParametric() {
        return false;
    }
}
