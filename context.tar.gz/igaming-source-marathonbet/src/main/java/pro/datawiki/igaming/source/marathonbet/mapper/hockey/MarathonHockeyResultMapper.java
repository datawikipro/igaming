package pro.datawiki.igaming.source.marathonbet.mapper.hockey;

import org.springframework.stereotype.Component;
import pro.datawiki.igaming.dto.BetType;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.dto.market.BetScope;
import pro.datawiki.igaming.dto.market.MatchResultBet;
import pro.datawiki.igaming.dto.market.StatType;
import pro.datawiki.igaming.source.core.mapper.AbstractBetTypeMapper;

@Component
public class MarathonHockeyResultMapper extends AbstractBetTypeMapper {

    @Override
    public boolean supports(String bookmaker, SportType sportType) {
        return "marathonbet".equals(bookmaker) && sportType == SportType.HOCKEY;
    }

    @Override
    public BetType map(String m, String o) {
        if (m == null || o == null) return null;

        // --- Match Result ---
        if (m.matches("^(RESULT|MATCH_RESULT|1|X|2)$")) {
            return map1X2DCRecord(o, BetScope.FULL_MATCH, StatType.MATCH);
        }

        // --- Match Winner Including OT ---
        if (m.matches("^(MATCH_WINNER_INCLUDING_ALL_OT|MATCH_RESULT_INCLUDING_OVERTIME|MATCH_WINNER_INCLUDING_OVERTIME)$")) {
            return switch (o) {
                case "1", "HB_H" -> new MatchResultBet(BetScope.FULL_MATCH, MatchResultBet.Outcome.WIN1_2WAY, StatType.MATCH);
                case "3", "HB_A" -> new MatchResultBet(BetScope.FULL_MATCH, MatchResultBet.Outcome.WIN2_2WAY, StatType.MATCH);
                default -> null;
            };
        }

        // --- Period Results ---
        if (m.matches("^RESULT_-_1ST_PERIOD$") || m.matches(".*_-_1ST_(PERIOD|SET)$")) {
            return map1X2DCRecord(o, BetScope.PERIOD_1, StatType.MATCH);
        }
        if (m.matches("^RESULT_-_2ND_PERIOD$") || m.matches(".*_-_2ND_(PERIOD|SET)$")) {
            return map1X2DCRecord(o, BetScope.PERIOD_2, StatType.MATCH);
        }
        if (m.matches("^RESULT_-_3RD_PERIOD$") || m.matches(".*_-_3RD_(PERIOD|SET)$")) {
            return map1X2DCRecord(o, BetScope.PERIOD_3, StatType.MATCH);
        }

        return null;
    }
}
