package pro.datawiki.igaming.source.core.domain;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.FetchType;
import jakarta.persistence.Index;
import jakarta.persistence.Table;
import jakarta.persistence.Version;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "match_cache", indexes = {
        @Index(name = "idx_mc_status_updated", columnList = "status, updated_at"),
        @Index(name = "idx_mc_is_live", columnList = "is_live"),
        @Index(name = "idx_mc_sport_live", columnList = "sport_name, is_live")
})
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MatchCache {

    public enum Status {
        PENDING, PROCESSED, FAILED, NEW, TARGETED_REFRESH
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "external_id", unique = true, nullable = false)
    private String externalId;

    @Column(name = "sport_id")
    private Integer sportId;

    @Column(name = "sport_name")
    private String sportName;

    @Column(name = "league_name")
    private String leagueName;

    @Column(name = "format_info")
    private String formatInfo;

    @Column(name = "team1")
    private String team1;

    @Column(name = "team2")
    private String team2;

    @Column(name = "score1")
    private String score1;

    @Column(name = "score2")
    private String score2;

    @Builder.Default
    @Column(name = "is_live")
    private Boolean isLive = false;

    @Column(name = "start_time")
    private Long startTime;

    @Column(name = "event_url")
    private String eventUrl;


    @Builder.Default
    @Enumerated(EnumType.STRING)
    @Column(name = "status", length = 20)
    private Status status = Status.NEW;

    @Column(name = "json_payload", columnDefinition = "TEXT")
    private String jsonPayload;

    @Setter(lombok.AccessLevel.NONE)
    @Getter(lombok.AccessLevel.NONE)
    @OneToOne(mappedBy = "match", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    private MatchPayload payloadEntity;

    public void setJsonPayload(String json) {
        this.jsonPayload = json;
        if (this.payloadEntity == null) {
            this.payloadEntity = new MatchPayload(this, json);
        } else {
            this.payloadEntity.setData(json);
        }
    }

    public String getJsonPayload() {
        if (this.jsonPayload != null && !this.jsonPayload.isEmpty()) {
            return this.jsonPayload;
        }
        return this.payloadEntity != null ? this.payloadEntity.getData() : null;
    }
 
    @Builder.Default
    @OneToMany(mappedBy = "match", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<MatchFactor> factors = new ArrayList<>();

    @Column(name = "payload_hash", length = 64)
    private String payloadHash;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Version
    @Column(name = "version", nullable = false, columnDefinition = "int default 0")
    private Integer version = 0;

    @jakarta.persistence.PrePersist
    protected void onCreate() {
        if (this.createdAt == null) {
            this.createdAt = LocalDateTime.now();
        }
    }

    @jakarta.persistence.PreUpdate
    protected void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }
}
