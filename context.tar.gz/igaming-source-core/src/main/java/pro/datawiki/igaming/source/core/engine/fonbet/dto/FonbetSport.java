package pro.datawiki.igaming.source.core.engine.fonbet.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class FonbetSport {
    private Integer id;
    private String name;
    private String kind;
    @JsonProperty("parentId")
    private Integer parentId;
}
