package pro.datawiki.igaming.source.core.engine.betcity.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.Data;
import java.io.IOException;
import java.util.Map;
import com.fasterxml.jackson.databind.JavaType;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonDeserialize(using = BetcitySport.Deserializer.class)
public class BetcitySport {
    @JsonProperty("id_sp")
    private Integer idSp;
    
    @JsonProperty("name_sp")
    private String nameSp;
    
    private Map<String, BetcityChmp> chmps;

    public static class Deserializer extends JsonDeserializer<BetcitySport> {
        @Override
        public BetcitySport deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
            if (p.currentToken() == JsonToken.START_OBJECT) {
                JsonNode node = p.getCodec().readTree(p);
                BetcitySport sport = new BetcitySport();
                if (node.has("id_sp") && !node.get("id_sp").isNull()) sport.setIdSp(node.get("id_sp").asInt());
                if (node.has("name_sp") && !node.get("name_sp").isNull()) sport.setNameSp(node.get("name_sp").asText());
                if (node.has("chmps")) {
                    JavaType type = ctxt.getTypeFactory().constructMapType(Map.class, String.class, BetcityChmp.class);
                    sport.setChmps(ctxt.readTreeAsValue(node.get("chmps"), type));
                }
                return sport;
            }
            p.skipChildren();
            return null;
        }
    }
}
