package pro.datawiki.igaming.source.marathonbet.mapper.tennis;

import org.springframework.stereotype.Component;
import pro.datawiki.igaming.dto.BetType;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.dto.market.*;
import pro.datawiki.igaming.source.core.mapper.AbstractBetTypeMapper;

@Component
public class MarathonTennisTotalMapper extends AbstractBetTypeMapper {

    @Override
    public boolean supports(String bookmaker, SportType sportType) {
        return "marathonbet".equals(bookmaker) && sportType == SportType.TENNIS;
    }

    @Override
    public BetType map(String m, String o) {
        if (m == null || o == null) return null;

        // 4. Totals (Games & Sets)
        if (m.contains("TOTAL")) {
            StatType statType = m.contains("SET") ? StatType.SETS : (m.contains("GAME") ? StatType.GAMES : StatType.MATCH);
            BetScope scope = BetScope.FULL_MATCH;
            if (m.contains("1ST_SET")) scope = BetScope.SET_1;
            else if (m.contains("2ND_SET")) scope = BetScope.SET_2;

            BetSubject subject = BetSubject.MATCH;
            if (m.contains("FIRST_TEAM") || m.contains("TEAM1")) subject = BetSubject.TEAM1;
            else if (m.contains("SECOND_TEAM") || m.contains("TEAM2")) subject = BetSubject.TEAM2;

            if ("ODD".equals(o)) return new BinaryMarketBet(scope, subject, BinaryMarketBet.MarketType.ODD_EVEN, BinaryMarketBet.Outcome.ODD, statType);
            if ("EVEN".equals(o)) return new BinaryMarketBet(scope, subject, BinaryMarketBet.MarketType.ODD_EVEN, BinaryMarketBet.Outcome.EVEN, statType);

            return mapTotalRecord(o, scope, subject, statType, m.contains("ASIAN"));
        }

        return null;
    }
}
