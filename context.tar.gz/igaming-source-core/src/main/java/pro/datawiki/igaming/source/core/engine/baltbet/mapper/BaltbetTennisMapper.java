package pro.datawiki.igaming.source.core.engine.baltbet.mapper;

import org.springframework.stereotype.Component;
import pro.datawiki.igaming.dto.BetType;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.source.core.mapper.AbstractBetTypeMapper;

import java.util.Map;

/**
 * Tennis-specific mapper for Baltbet-family bookmakers.
 */
@Component
public class BaltbetTennisMapper extends AbstractBetTypeMapper {

    private static final Map<String, BetType> ID_MAP = Map.ofEntries(
            // Example: Map.entry("400", ...)
    );

    @Override
    public boolean supports(String bookmaker, SportType sportType) {
        return bookmaker != null && bookmaker.toLowerCase().contains("baltbet") && sportType == SportType.TENNIS;
    }

    @Override
    public BetType map(String m, String o) {
        return ID_MAP.get(m);
    }
}
