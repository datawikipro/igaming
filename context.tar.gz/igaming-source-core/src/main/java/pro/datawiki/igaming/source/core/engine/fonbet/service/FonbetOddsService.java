package pro.datawiki.igaming.source.core.engine.fonbet.service;

import java.util.Map;

/**
 * Maps fonbet factor IDs to human-readable bet type names.
 */
public class FonbetOddsService {

    private static final Map<Integer, String> FACTOR_NAMES = Map.ofEntries(
            Map.entry(921, "Win 1"),
            Map.entry(922, "Draw"),
            Map.entry(923, "Win 2"),
            Map.entry(924, "1X"),
            Map.entry(925, "12"),
            Map.entry(926, "X2"),
            Map.entry(927, "Handicap 1"),
            Map.entry(928, "Handicap 2"),
            Map.entry(930, "Total Over"),
            Map.entry(931, "Total Under"),
            Map.entry(932, "Individual Total 1 Over"),
            Map.entry(933, "Individual Total 1 Under"),
            Map.entry(934, "Individual Total 2 Over"),
            Map.entry(935, "Individual Total 2 Under"),
            Map.entry(1571, "Win1 or Win2"),
            Map.entry(1845, "Both Teams Score - Yes"),
            Map.entry(1846, "Both Teams Score - No")
    );

    private FonbetOddsService() {
    }

    public static String getFactorName(Integer factorId) {
        if (factorId == null) return "Unknown";
        return FACTOR_NAMES.getOrDefault(factorId, "Factor " + factorId);
    }
}
