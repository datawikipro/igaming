package pro.datawiki.igaming.source.core.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import pro.datawiki.igaming.source.core.domain.MatchCache;
import pro.datawiki.igaming.source.core.domain.SportCache;
import pro.datawiki.igaming.source.core.repository.MatchCacheRepository;
import pro.datawiki.igaming.source.core.repository.SportCacheRepository;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.LocalDateTime;
import java.util.HexFormat;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
public class MatchPersistenceService {

    private final MatchCacheRepository matchCacheRepository;
    private final SportCacheRepository sportCacheRepository;

    @Transactional
    public void saveOrUpdateMatchMetadata(MatchCache match, String jsonPayload) {
        String newHash = computeHash(jsonPayload);
        
        Optional<MatchCache> existing = matchCacheRepository.findByExternalId(match.getExternalId());
        
        MatchCache toSave = existing.orElse(match);
        if (existing.isPresent()) {
            updateFields(toSave, match);
        }

        if (toSave.getCreatedAt() == null) {
            toSave.setCreatedAt(LocalDateTime.now());
        }
        toSave.setUpdatedAt(LocalDateTime.now());

        // Check for updates
        if (toSave.getPayloadHash() == null || !toSave.getPayloadHash().equals(newHash)) {
            toSave.setStatus(MatchCache.Status.NEW);
        }

        toSave.setJsonPayload(jsonPayload);
        toSave.setPayloadHash(newHash);
        
        matchCacheRepository.save(toSave);
    }

    private void updateFields(MatchCache target, MatchCache source) {
        target.setSportId(source.getSportId());
        target.setSportName(source.getSportName());
        target.setTeam1(source.getTeam1());
        target.setTeam2(source.getTeam2());
        target.setStartTime(source.getStartTime());
        target.setIsLive(source.getIsLive());
        target.setScore1(source.getScore1());
        target.setScore2(source.getScore2());
        target.setEventUrl(source.getEventUrl());
    }


    @Transactional
    public void saveSport(Integer sportId, String sportName) {
        try {
            Optional<SportCache> existing = sportCacheRepository.findByExternalId(sportId);
            SportCache sport = existing.orElseGet(SportCache::new);
            sport.setExternalId(sportId);
            sport.setName(sportName);
            sport.setUpdatedAt(LocalDateTime.now());
            sportCacheRepository.save(sport);
        } catch (Exception e) {
            log.debug("Error saving sport {}: {}", sportId, e.getMessage());
        }
    }

    private static final ThreadLocal<MessageDigest> SHA256_DIGEST = ThreadLocal.withInitial(() -> {
        try {
            return MessageDigest.getInstance("SHA-256");
        } catch (Exception e) {
            throw new RuntimeException("SHA-256 not available", e);
        }
    });

    public String computeHash(String content) {
        if (content == null) return "";
        try {
            MessageDigest digest = SHA256_DIGEST.get();
            digest.reset();
            byte[] hash = digest.digest(content.getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(hash);
        } catch (Exception e) {
            return String.valueOf(content.hashCode());
        }
    }
}
