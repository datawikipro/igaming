package pro.datawiki.igaming.source.marathonbet.dto.marathon;

import lombok.Data;

/**
 * Represents an odds/coefficient from Marathonbet.
 */
@Data
public class MarathonOdd {
    private String id;
    private String name;       // e.g., "1", "X", "2", "Тотал Больше 2.5"
    private String label;      // human-readable visual text from the DOM (e.g. "1:0" or "Любой другой счет")
    private Double value;      // coefficient
    private Double param;      // handicap/total value
    private String groupName;  // e.g., "Результат", "Тотал", "Фора"
}
