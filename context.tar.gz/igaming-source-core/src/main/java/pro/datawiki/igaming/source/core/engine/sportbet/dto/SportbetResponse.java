package pro.datawiki.igaming.source.core.engine.sportbet.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import java.util.Map;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class SportbetResponse {
    private Map<String, SportbetSport> s;
    private Map<String, SportbetCategory> c;
    private Map<String, SportbetTournament> t;
    private Map<String, SportbetFixture> fixtures;
}
