package pro.datawiki.igaming.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class OddItem {
    private Integer factorId;
    private String name;        // human-readable bet type (raw bookmaker name)
    private Double value;       // coefficient
    private String groupName;   // group (for winline)

    /**
     * Canonical bet type resolved by the source service.
     */
    private BetType betType;
}