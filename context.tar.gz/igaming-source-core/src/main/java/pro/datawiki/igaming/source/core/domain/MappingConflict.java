package pro.datawiki.igaming.source.core.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "mapping_conflict", indexes = {
        @Index(name = "idx_mapping_conflict_key", columnList = "bookmaker, sport_type, market, outcome")
})
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MappingConflict {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "bookmaker", nullable = false)
    private String bookmaker;

    @Column(name = "sport_type", nullable = false)
    private String sportType;

    @Column(name = "market")
    private String market;

    @Column(name = "outcome")
    private String outcome;

    @Column(name = "conflicting_mappers", length = 1024)
    private String conflictingMappers;

    @Column(name = "event_id")
    private String eventId;

    @CreationTimestamp
    @Column(name = "created_at")
    private LocalDateTime createdAt;
}
