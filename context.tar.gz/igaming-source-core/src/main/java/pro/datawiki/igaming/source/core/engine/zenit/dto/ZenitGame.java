package pro.datawiki.igaming.source.core.engine.zenit.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import java.util.List;

@Data
public class ZenitGame {
    private Long time;
    private String score;
    @JsonProperty
    private Integer sid;
    @JsonProperty
    private Integer lid;
    private String u1;
    private String u2;
    private List<ZenitOdd> f_l;

    private String team1;
    private String team2;
}
