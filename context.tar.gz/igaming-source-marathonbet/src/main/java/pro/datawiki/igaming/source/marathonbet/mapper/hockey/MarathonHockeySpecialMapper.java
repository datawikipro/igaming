package pro.datawiki.igaming.source.marathonbet.mapper.hockey;

import org.springframework.stereotype.Component;
import pro.datawiki.igaming.dto.BetType;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.dto.market.BetScope;
import pro.datawiki.igaming.dto.market.BetSubject;
import pro.datawiki.igaming.dto.market.BinaryMarketBet;
import pro.datawiki.igaming.dto.market.StatType;
import pro.datawiki.igaming.source.core.mapper.AbstractBetTypeMapper;

@Component
public class MarathonHockeySpecialMapper extends AbstractBetTypeMapper {

    @Override
    public boolean supports(String bookmaker, SportType sportType) {
        return "marathonbet".equals(bookmaker) && sportType == SportType.HOCKEY;
    }

    @Override
    public BetType map(String m, String o) {
        if (m == null || o == null) return null;

        // --- Specialties ---
        if ("BOTH_TEAMS_TO_SCORE".equals(m)) {
            return new BinaryMarketBet(BetScope.FULL_MATCH, BetSubject.MATCH, BinaryMarketBet.MarketType.BTTS, "YES".equals(o) ? BinaryMarketBet.Outcome.YES : BinaryMarketBet.Outcome.NO, StatType.MATCH);
        }
        if ("TO_QUALIFY".equals(m)) {
            BetSubject subject = ("1".equals(o) || "HOME".equals(o)) ? BetSubject.TEAM1 : BetSubject.TEAM2;
            return new BinaryMarketBet(BetScope.FULL_MATCH, subject, BinaryMarketBet.MarketType.QUALIFY, BinaryMarketBet.Outcome.YES, StatType.MATCH);
        }

        return null;
    }
}
