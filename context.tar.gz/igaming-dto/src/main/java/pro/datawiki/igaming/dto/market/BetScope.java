package pro.datawiki.igaming.dto.market;

public enum BetScope {
    FULL_MATCH(""),
    FULL_MATCH_INCLUDING_OT("OT_"),
    HALF_1("HALFTIME_"),
    HALF_2("SECOND_HALF_"),
    FIRST_HALF("HALFTIME_"),
    SECOND_HALF("SECOND_HALF_"),
    QUARTER_1("QUARTER_1_"),
    QUARTER_2("QUARTER_2_"),
    QUARTER_3("QUARTER_3_"),
    QUARTER_4("QUARTER_4_"),
    SET_1("SET_1_"),
    SET_2("SET_2_"),
    SET_3("SET_3_"),
    SET_4("SET_4_"),
    SET_5("SET_5_"),
    SET_6("SET_6_"),
    SET_7("SET_7_"),
    MAP_1("MAP_1_"),
    MAP_2("MAP_2_"),
    MAP_3("MAP_3_"),
    MAP_4("MAP_4_"),
    MAP_5("MAP_5_"),
    PERIOD_1("PERIOD_1_"),
    PERIOD_2("PERIOD_2_"),
    PERIOD_3("PERIOD_3_"),
    TIME_INTERVAL("TIME_INTERVAL_");

    private final String prefix;

    BetScope(String prefix) {
        this.prefix = prefix;
    }

    public String prefix() {
        return prefix;
    }
}
