package pro.datawiki.igaming.source.core.domain;
 
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
 
@Entity
@Table(name = "match_factor", indexes = {
        @Index(name = "idx_match_factor_match", columnList = "match_id")
})
@Getter
@Setter
@NoArgsConstructor
public class MatchFactor {
 
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
 
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "match_id", nullable = false)
    private MatchCache match;
 
    @Column(name = "factor_id", nullable = false)
    private Integer factorId;
 
    @Column(name = "name")
    private String name;
 
    @Column(name = "value")
    private Double value;
 
}
