package pro.datawiki.igaming.dto;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonNode;

import java.io.IOException;
import pro.datawiki.igaming.dto.market.*;

/**
 * Jackson deserializer: String code → BetType, or JSON object → BetType (via code reconstruction).
 * Handles both formats:
 * - Simple string: "WIN1" → BetTypeRegistry.fromCode("WIN1")
 * - JSON object from source services that serialize records directly:
 *   {"scope":"FULL_MATCH","outcome":"WIN1","statType":"MATCH"} → reconstruct code → BetTypeRegistry.fromCode(code)
 *
 * Uses {@link BetTypeRegistry} to resolve codes across all sport-specific enums.
 */
public class BetTypeDeserializer extends JsonDeserializer<BetType> {

    @Override
    public BetType deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
        if (p.currentToken() == JsonToken.VALUE_STRING) {
            // Simple string code: "WIN1"
            String code = p.getValueAsString();
            return BetTypeRegistry.fromCode(code);
        }

        if (p.currentToken() == JsonToken.VALUE_NULL) {
            return null;
        }

        if (p.currentToken() == JsonToken.START_OBJECT) {
            // JSON object — read the tree and try to extract or reconstruct the code
            JsonNode node = p.readValueAsTree();
            return deserializeFromObject(node);
        }

        // Fallback
        String code = p.getValueAsString();
        return BetTypeRegistry.fromCode(code);
    }

    private BetType deserializeFromObject(JsonNode node) {
        // If the object has an explicit "code" field, use it directly
        if (node.has("code")) {
            return BetTypeRegistry.fromCode(node.get("code").asText());
        }

        // Reconstruct the record parameters
        BetScope scope = node.has("scope") ? BetScope.valueOf(node.get("scope").asText()) : BetScope.FULL_MATCH;
        StatType statType = (node.has("statType") && !node.get("statType").isNull()) ? StatType.valueOf(node.get("statType").asText()) : null;
        BetSubject subject = (node.has("subject") && !node.get("subject").isNull()) ? BetSubject.valueOf(node.get("subject").asText()) : BetSubject.MATCH;

        // Detect record type by presence of specific fields
        if (node.has("outcome")) {
            if (node.has("marketType")) {
                // BinaryMarketBet
                BinaryMarketBet.MarketType marketType = BinaryMarketBet.MarketType.valueOf(node.get("marketType").asText());
                BinaryMarketBet.Outcome binaryOutcome = BinaryMarketBet.Outcome.valueOf(node.get("outcome").asText());
                return new BinaryMarketBet(scope, subject, marketType, binaryOutcome, statType);
            }
            // MatchResultBet
            MatchResultBet.Outcome matchOutcome = MatchResultBet.Outcome.valueOf(node.get("outcome").asText());
            return new MatchResultBet(scope, matchOutcome, statType);
        }

        if (node.has("direction")) {
            // TotalBet
            TotalBet.Direction direction = TotalBet.Direction.valueOf(node.get("direction").asText());
            boolean isAsian = node.has("isAsian") && node.get("isAsian").asBoolean();
            double param = node.has("param") ? node.get("param").asDouble() : 0.0;
            return new TotalBet(scope, subject, direction, param, isAsian, statType);
        }

        if (node.has("team") && node.has("param")) {
            // HandicapBet
            HandicapBet.Team team = HandicapBet.Team.valueOf(node.get("team").asText());
            boolean isAsian = node.has("isAsian") && node.get("isAsian").asBoolean();
            double param = node.get("param").asDouble();
            return new HandicapBet(scope, team, param, isAsian, statType);
        }

        if (node.has("score1") && node.has("score2")) {
            // CorrectScoreBet
            boolean anyOther = node.has("isAnyOtherScore") && node.get("isAnyOtherScore").asBoolean();
            int s1 = node.get("score1").asInt();
            int s2 = node.get("score2").asInt();
            return new CorrectScoreBet(scope, s1, s2, anyOther);
        }

        // Unknown object structure
        return new pro.datawiki.igaming.dto.market.UnknownBet(node.toString(), null);
    }

    private String getPrefix(JsonNode node, String fieldName, PrefixEnum[] values) {
        if (!node.has(fieldName) || node.get(fieldName).isNull()) {
            return "";
        }
        String name = node.get(fieldName).asText();
        for (PrefixEnum v : values) {
            if (v.name().equals(name)) {
                return v.prefix();
            }
        }
        return "";
    }

    /**
     * Common interface for prefix enums to avoid reflection.
     */
    private interface PrefixEnum {
        String name();
        String prefix();
    }

    private enum ScopePrefix implements PrefixEnum {
        FULL_MATCH(""), FULL_MATCH_INCLUDING_OT("OT_"),
        HALF_1("HALFTIME_"), HALF_2("SECOND_HALF_"),
        FIRST_HALF("HALFTIME_"), SECOND_HALF("SECOND_HALF_"),
        QUARTER_1("QUARTER_1_"), QUARTER_2("QUARTER_2_"), QUARTER_3("QUARTER_3_"), QUARTER_4("QUARTER_4_"),
        SET_1("SET_1_"), SET_2("SET_2_"), SET_3("SET_3_"), SET_4("SET_4_"), SET_5("SET_5_"), SET_6("SET_6_"), SET_7("SET_7_"),
        MAP_1("MAP_1_"), MAP_2("MAP_2_"), MAP_3("MAP_3_"), MAP_4("MAP_4_"), MAP_5("MAP_5_"),
        PERIOD_1("PERIOD_1_"), PERIOD_2("PERIOD_2_"), PERIOD_3("PERIOD_3_"),
        TIME_INTERVAL("TIME_INTERVAL_");

        private final String prefix;
        ScopePrefix(String prefix) { this.prefix = prefix; }
        @Override public String prefix() { return prefix; }
    }

    private enum StatTypePrefix implements PrefixEnum {
        NONE(""), MATCH(""),
        CORNERS("CORNER_"), CARDS("CARDS_"), YELLOW_CARDS("CARDS_"),
        OFFSIDES("OFFSIDES_"), FOULS("FOULS_"), SHOTS_ON_TARGET("SOT_"),
        GAMES("GAMES_"), SETS("SETS_"), MAPS("MAPS_");

        private final String prefix;
        StatTypePrefix(String prefix) { this.prefix = prefix; }
        @Override public String prefix() { return prefix; }
    }

    private enum SubjectPrefix implements PrefixEnum {
        MATCH(""), TEAM1("TEAM1_"), TEAM2("TEAM2_");

        private final String prefix;
        SubjectPrefix(String prefix) { this.prefix = prefix; }
        @Override public String prefix() { return prefix; }
    }
}
