package pro.datawiki.igaming.source.core.engine.sportbet.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class SportbetTournament {
    private Integer id;
    private String n; // name
    private Integer cid; // category id reference
}
