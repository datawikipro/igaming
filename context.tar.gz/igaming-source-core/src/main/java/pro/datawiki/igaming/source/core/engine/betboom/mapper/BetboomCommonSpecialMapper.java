package pro.datawiki.igaming.source.core.engine.betboom.mapper;

import org.springframework.stereotype.Component;
import pro.datawiki.igaming.dto.BetType;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.dto.market.BetScope;
import pro.datawiki.igaming.dto.market.BetSubject;
import pro.datawiki.igaming.dto.market.BinaryMarketBet;
import pro.datawiki.igaming.dto.market.StatType;
import pro.datawiki.igaming.source.core.mapper.AbstractBetTypeMapper;

import java.util.Set;

@Component
public class BetboomCommonSpecialMapper extends AbstractBetTypeMapper {

    private static final Set<SportType> SPECIALIZED_SPORTS = Set.of(
            SportType.FOOTBALL, SportType.BASKETBALL, SportType.HOCKEY, SportType.TENNIS,
            SportType.ESPORTS, SportType.CYBER_FOOTBALL, SportType.CYBER_BASKETBALL, SportType.CYBER_HOCKEY,
            SportType.VOLLEYBALL, SportType.BEACH_VOLLEYBALL, SportType.TABLE_TENNIS
    );

    @Override
    public boolean supports(String bookmaker, SportType sportType) {
        return "betboom".equals(bookmaker) && !SPECIALIZED_SPORTS.contains(sportType);
    }

    @Override
    public BetType map(String market, String outcome) {
        if (market == null || outcome == null) return null;
        String m = market.toUpperCase().trim();
        String o = outcome.toUpperCase().trim();

        if (m.contains("ОБЕ ЗАБЬЮТ")) {
            BinaryMarketBet.Outcome res = null;
            if (o.contains("ДА") || o.equals("YES")) res = BinaryMarketBet.Outcome.YES;
            if (o.contains("НЕТ") || o.equals("NO")) res = BinaryMarketBet.Outcome.NO;
            
            if (res != null) {
                return new BinaryMarketBet(BetScope.FULL_MATCH, BetSubject.MATCH, BinaryMarketBet.MarketType.BTTS, res, StatType.MATCH);
            }
        }

        return null;
    }
}
