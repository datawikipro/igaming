package pro.datawiki.igaming.source.marathonbet.mapper.football;

import org.springframework.stereotype.Component;
import pro.datawiki.igaming.dto.BetType;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.dto.market.*;
import pro.datawiki.igaming.source.core.mapper.AbstractBetTypeMapper;

@Component
public class MarathonFootballTotalMapper extends AbstractBetTypeMapper {

    @Override
    public boolean supports(String bookmaker, SportType sportType) {
        return "marathonbet".equals(bookmaker) && sportType == SportType.FOOTBALL;
    }

    @Override
    public BetType map(String m, String o) {
        if (m == null || o == null) return null;
        String upperM = m.toUpperCase().replace("_", " ").replace(".", " ").trim();
        String upperO = o.toUpperCase().trim();

        if (!upperM.contains("TOTAL")) return null;
        
        boolean is1st = upperM.contains("FIRST TEAM") || upperM.contains("TEAM 1") || upperM.contains("1ST TEAM") || upperM.contains("HOME");
        boolean is2nd = upperM.contains("SECOND TEAM") || upperM.contains("TEAM 2") || upperM.contains("2ND TEAM") || upperM.contains("AWAY");
        boolean isHalf1 = upperM.contains("1ST HALF") || upperM.contains("FIRST HALF");
        boolean isHalf2 = upperM.contains("2ND HALF") || upperM.contains("SECOND HALF");

        BetScope scope = isHalf1 ? BetScope.HALF_1 : (isHalf2 ? BetScope.HALF_2 : BetScope.FULL_MATCH);
        BetSubject subject = is1st ? BetSubject.TEAM1 : (is2nd ? BetSubject.TEAM2 : BetSubject.MATCH);
        
        StatType statType = StatType.MATCH;
        if (upperM.contains("CORNER")) statType = StatType.CORNERS;
        else if (upperM.contains("CARD")) statType = StatType.YELLOW_CARDS;
        else if (upperM.contains("OFFSIDE")) statType = StatType.OFFSIDES;
        else if (upperM.contains("FOUL")) statType = StatType.FOULS;
        else if (upperM.contains("SHOTS ON TARGET") || upperM.contains("ATTEMPTS ON TARGET")) statType = StatType.SHOTS_ON_TARGET;

        BetType total = mapTotalRecord(upperO, scope, subject, statType, upperM.contains("ASIAN"));
        if (total != null) return total;
        
        if ("ODD".equals(upperO)) return new BinaryMarketBet(scope, subject, BinaryMarketBet.MarketType.ODD_EVEN, BinaryMarketBet.Outcome.ODD, statType);
        if ("EVEN".equals(upperO)) return new BinaryMarketBet(scope, subject, BinaryMarketBet.MarketType.ODD_EVEN, BinaryMarketBet.Outcome.EVEN, statType);
        
        return null;
    }
}
