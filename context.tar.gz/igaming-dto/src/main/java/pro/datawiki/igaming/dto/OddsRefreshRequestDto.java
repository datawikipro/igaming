package pro.datawiki.igaming.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO for communicating odds refresh requests from aggregator to source services.
 * When a surebet is detected, the aggregator schedules targeted refresh requests
 * for the bookmakers involved, and source services poll for these requests.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class OddsRefreshRequestDto {
    private String externalEventId;  // Bookmaker's event ID
    private String bookmaker;        // "leon", "fonbet", etc.
    private String priority;         // LIVE, HIGH, MEDIUM, LOW
    private Long matchId;            // Aggregator's internal match ID (informational)
}
