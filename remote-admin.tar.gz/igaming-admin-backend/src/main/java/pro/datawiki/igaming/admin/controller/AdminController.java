package pro.datawiki.igaming.admin.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pro.datawiki.igaming.admin.entity.TelegramChannel;
import pro.datawiki.igaming.admin.repository.TelegramChannelRepository;
import pro.datawiki.igaming.admin.service.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/admin")
@CrossOrigin(origins = "*") // Allow requests from Next.js frontend
@RequiredArgsConstructor
public class AdminController {

    private final KubernetesNodeService nodeService;
    private final KubernetesPodService podService;
    private final SmartScalingService smartScalingService;
    private final GcpHardwareService gcpHardwareService;
    private final GeoScalingBalancerService geoScalingBalancerService;
    private final ManagedInstanceService managedInstanceService;
    private final TelegramChannelRepository channelRepository;

    @GetMapping("/nodes/stats")
    public KubernetesNodeService.NodeStats getNodesStats() {
        return nodeService.getNodesStats();
    }

    @GetMapping("/nodes")
    public List<KubernetesNodeService.NodeDetail> getDetailedNodes() {
        return nodeService.getDetailedNodes();
    }

    @GetMapping({"/loaders", "/loaders/stats"})
    public List<KubernetesPodService.LoaderStat> getLoadersStats() {
        return podService.getLoadersStats();
    }

    @GetMapping("/aggregator/stats")
    public pro.datawiki.igaming.dto.DiagnosticsStatsDto getAggregatorStats() {
        return podService.fetchAggregatorStats();
    }

    @GetMapping("/analytics/matches")
    public pro.datawiki.igaming.dto.MatchAnalyticsDto getMatchAnalytics(
            @RequestParam(required = false) String sport,
            @RequestParam(required = false) Long start,
            @RequestParam(required = false) Long end) {
        return podService.fetchMatchAnalytics(sport, start, end);
    }

    @GetMapping("/optimization/report")
    public pro.datawiki.igaming.dto.OptimizationReportDto getOptimizationReport() {
        return podService.getOptimizationReport();
    }




    @PostMapping("/loaders/{deploymentName}/scale")
    public void scaleLoader(@PathVariable String deploymentName, @RequestParam int replicas) {
        podService.scaleLoader(deploymentName, replicas);
    }

    @GetMapping("/management/{type}")
    public Object getManagementData(@PathVariable String type) {
        return podService.fetchManagementData(type);
    }

    @PostMapping("/management/normalization-queue/{id}/retry")
    public void retryNormalization(@PathVariable Long id) {
        podService.retryNormalization(id);
    }

    @DeleteMapping("/management/normalization-queue/{id}")
    public void deleteNormalization(@PathVariable Long id) {
        podService.deleteNormalization(id);
    }

    @GetMapping("/channels")
    public List<TelegramChannel> getChannels() {
        return channelRepository.findAll();
    }

    @GetMapping("/channels/active")
    public List<TelegramChannel> getActiveChannels() {
        return channelRepository.findByEnabledTrue();
    }

    @PostMapping("/channels")
    public TelegramChannel saveChannel(@RequestBody TelegramChannel channel) {
        return channelRepository.save(channel);
    }

    @PutMapping("/channels/{id}")
    public ResponseEntity<TelegramChannel> updateChannel(@PathVariable Long id, @RequestBody TelegramChannel details) {
        return channelRepository.findById(id).map(ch -> {
            ch.setName(details.getName());
            ch.setChatId(details.getChatId());
            ch.setRegion(details.getRegion());
            ch.setEnabled(details.isEnabled());
            return ResponseEntity.ok(channelRepository.save(ch));
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/channels/{id}")
    public ResponseEntity<Void> deleteChannel(@PathVariable Long id) {
        if (channelRepository.existsById(id)) {
            channelRepository.deleteById(id);
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.notFound().build();
    }

    @PostMapping("/scaling/spot")
    public void scaleSpotNodes(@RequestParam int size) {
        smartScalingService.setDesiredCount(size);
    }

    @GetMapping("/scaling/target")
    public int getTargetCount() {
        return smartScalingService.getDesiredCount();
    }

    @PostMapping("/scaling/sync-target")
    public void syncTarget() {
        smartScalingService.syncTargetWithCurrentCount();
    }


    @GetMapping("/hardware/stats")
    public Map<String, GcpHardwareService.GcpNodeInfo> getHardwareStats() {
        return gcpHardwareService.getGcpInstancesInfo();
    }

    @PostMapping("/nodes/provision")
    public String provisionNode() {
        return geoScalingBalancerService.provisionNode("ANY", "SPOT", "LOADER", "e2-custom-4-16384", false);
    }

    @PostMapping("/nodes/provisionAccount")
    public String provisionNodeByAccount(@RequestParam String accountName) {
        return geoScalingBalancerService.provisionNodeByAccount(accountName, "SPOT", "LOADER", "e2-custom-4-16384");
    }

    @DeleteMapping("/nodes/{instanceName}")
    public void terminateNode(@PathVariable String instanceName) {
        geoScalingBalancerService.terminateInstance(instanceName);
    }

    @GetMapping("/inventory")
    public List<pro.datawiki.igaming.admin.entity.ManagedInstance> getInventory() {
        return managedInstanceService.getAllInstances();
    }

    @PostMapping("/inventory")
    public pro.datawiki.igaming.admin.entity.ManagedInstance saveInventory(@RequestBody pro.datawiki.igaming.admin.entity.ManagedInstance instance) {
        return managedInstanceService.saveInstance(instance);
    }

    @DeleteMapping("/inventory/{instanceName}")
    public void deleteInventory(@PathVariable String instanceName) {
        geoScalingBalancerService.terminateInstance(instanceName);
    }

    @PostMapping("/inventory/sync")
    public void syncInventory() {
        managedInstanceService.syncFromCluster(nodeService.getDetailedNodes());
    }
}
