package pro.datawiki.igaming.source.core.service;

import org.springframework.stereotype.Service;
import pro.datawiki.igaming.dto.*;
import pro.datawiki.igaming.dto.market.*;
import pro.datawiki.igaming.dto.market.MatchResultBet.Outcome;
import pro.datawiki.igaming.dto.market.TotalBet.Direction;
import pro.datawiki.igaming.dto.market.HandicapBet.Team;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class DynamicBetTypeResolver {

    // Regex patterns for dynamic sets/frames/maps
    private static final Pattern SET_PATTERN = Pattern.compile("^(\\d+)-(?:Й|Я)\\s+СЕТ:\\s+(.*)$");
    private static final Pattern MAP_PATTERN = Pattern.compile("^(\\d+)-(?:Й|Я)\\s+КАРТА:\\s+(.*)$");
    private static final Pattern FRAME_PATTERN = Pattern.compile("^(\\d+)-(?:Й|Я)\\s+ФРЕЙМ:\\s+(.*)$");

    public BetType resolve(SportType sport, String marketNameUpper, String runnerNameUpper) {
        if (marketNameUpper == null || sport == null) return null;

        Matcher setMatcher = SET_PATTERN.matcher(marketNameUpper);
        if (setMatcher.find()) {
            int setNum = Integer.parseInt(setMatcher.group(1));
            String subMarket = setMatcher.group(2).trim();
            return resolveSetMarket(sport, setNum, subMarket, runnerNameUpper);
        }

        Matcher mapMatcher = MAP_PATTERN.matcher(marketNameUpper);
        if (mapMatcher.find()) {
            int mapNum = Integer.parseInt(mapMatcher.group(1));
            String subMarket = mapMatcher.group(2).trim();
            return resolveMapMarket(sport, mapNum, subMarket, runnerNameUpper);
        }

        Matcher frameMatcher = FRAME_PATTERN.matcher(marketNameUpper);
        if (frameMatcher.find()) {
            int frameNum = Integer.parseInt(frameMatcher.group(1));
            String subMarket = frameMatcher.group(2).trim();
            return resolveFrameMarket(sport, frameNum, subMarket, runnerNameUpper);
        }

        if (sport == SportType.TABLE_TENNIS || sport == SportType.VOLLEYBALL) {
            StatType stat = StatType.MATCH; // Usually points in these contexts
            if (marketNameUpper.equals("ТОТАЛ ОЧКОВ")) {
                Direction dir = resolveDirection(runnerNameUpper);
                if (dir != null) return new TotalBet(BetScope.FULL_MATCH, BetSubject.MATCH, dir, 0.0, false, stat);
            }
            if (marketNameUpper.equals("ФОРА ПО ОЧКАМ")) {
                Team team = resolveTeam(runnerNameUpper);
                if (team != null) return new HandicapBet(BetScope.FULL_MATCH, team, 0.0, false, stat);
            }
            if (marketNameUpper.equals("ТОТАЛ ПЕРВОГО ИГРОКА") || marketNameUpper.equals("ТОТАЛ ХОЗЯЕВ")) {
                Direction dir = resolveDirection(runnerNameUpper);
                if (dir != null) return new TotalBet(BetScope.FULL_MATCH, BetSubject.TEAM1, dir, 0.0, false, stat);
            }
            if (marketNameUpper.equals("ТОТАЛ ВТОРОГО ИГРОКА") || marketNameUpper.equals("ТОТАЛ ГОСТЕЙ")) {
                Direction dir = resolveDirection(runnerNameUpper);
                if (dir != null) return new TotalBet(BetScope.FULL_MATCH, BetSubject.TEAM2, dir, 0.0, false, stat);
            }
        }
        
        if (sport == SportType.ESPORTS) {
            if (marketNameUpper.equals("ТОТАЛ РАУНДОВ")) {
                Direction dir = resolveDirection(runnerNameUpper);
                if (dir != null) return new TotalBet(BetScope.FULL_MATCH, BetSubject.MATCH, dir, 0.0, false, StatType.MATCH);
            }
        }

        // --- Generic markets for sports using common Total/Handicap/Result patterns ---
        if (sport == SportType.CRICKET || sport == SportType.RUGBY_LEAGUE || sport == SportType.BASEBALL
                || sport == SportType.HANDBALL || sport == SportType.FUTSAL || sport == SportType.FLOORBALL
                || sport == SportType.BEACH_VOLLEYBALL || sport == SportType.FIELD_HOCKEY || sport == SportType.UNKNOWN) {
            
            // Total runs/points
            if (marketNameUpper.equals("ТОТАЛ РАНОВ") || marketNameUpper.equals("ТОТАЛ ОЧКОВ")) {
                Direction dir = resolveDirection(runnerNameUpper);
                if (dir != null) return new TotalBet(BetScope.FULL_MATCH, BetSubject.MATCH, dir, 0.0, false, StatType.MATCH);
            }
            // Team 1 Total
            if (marketNameUpper.equals("ТОТАЛ РАНОВ ХОЗЯЕВ") || marketNameUpper.equals("ТОТАЛ ХОЗЯЕВ")) {
                Direction dir = resolveDirection(runnerNameUpper);
                if (dir != null) return new TotalBet(BetScope.FULL_MATCH, BetSubject.TEAM1, dir, 0.0, false, StatType.MATCH);
            }
            // Team 2 Total
            if (marketNameUpper.equals("ТОТАЛ РАНОВ ГОСТЕЙ") || marketNameUpper.equals("ТОТАЛ ГОСТЕЙ")) {
                Direction dir = resolveDirection(runnerNameUpper);
                if (dir != null) return new TotalBet(BetScope.FULL_MATCH, BetSubject.TEAM2, dir, 0.0, false, StatType.MATCH);
            }
            // Handicap
            if (marketNameUpper.equals("ФОРА ПО РАНАМ") || marketNameUpper.equals("ФОРА")
                    || marketNameUpper.equals("ФОРА ПО ФРЕЙМАМ") || marketNameUpper.equals("ГАНДИКАП")) {
                Team team = resolveTeam(runnerNameUpper);
                if (team != null) return new HandicapBet(BetScope.FULL_MATCH, team, 0.0, false, StatType.MATCH);
            }
            // OT-inclusive markets (Australian Football etc.)
            if (marketNameUpper.contains("ТОТАЛ (ВКЛЮЧАЯ ОТ)") || marketNameUpper.contains("ТОТАЛ (ВКЛЮЧАЯ OT)")) {
                Direction dir = resolveDirection(runnerNameUpper);
                if (dir != null) return new TotalBet(BetScope.FULL_MATCH_INCLUDING_OT, BetSubject.MATCH, dir, 0.0, false, StatType.MATCH);
            }
            if (marketNameUpper.contains("ФОРА (ВКЛЮЧАЯ ОТ)") || marketNameUpper.contains("ФОРА (ВКЛЮЧАЯ OT)")) {
                Team team = resolveTeam(runnerNameUpper);
                if (team != null) return new HandicapBet(BetScope.FULL_MATCH_INCLUDING_OT, team, 0.0, false, StatType.MATCH);
            }
            if (marketNameUpper.contains("ТОТАЛ ХОЗЯЕВ (ВКЛЮЧАЯ ОТ)") || marketNameUpper.contains("ТОТАЛ ХОЗЯЕВ (ВКЛЮЧАЯ OT)")) {
                Direction dir = resolveDirection(runnerNameUpper);
                if (dir != null) return new TotalBet(BetScope.FULL_MATCH_INCLUDING_OT, BetSubject.TEAM1, dir, 0.0, false, StatType.MATCH);
            }
            if (marketNameUpper.contains("ТОТАЛ ГОСТЕЙ (ВКЛЮЧАЯ ОТ)") || marketNameUpper.contains("ТОТАЛ ГОСТЕЙ (ВКЛЮЧАЯ OT)")) {
                Direction dir = resolveDirection(runnerNameUpper);
                if (dir != null) return new TotalBet(BetScope.FULL_MATCH_INCLUDING_OT, BetSubject.TEAM2, dir, 0.0, false, StatType.MATCH);
            }
        }

        return null;
    }

    private Direction resolveDirection(String r) {
        if (r == null) return null;
        String upper = r.toUpperCase();
        if (upper.contains("БОЛЬШЕ") || upper.contains("OVER") || upper.equals("Б") || upper.contains("ТБ") || upper.contains("TOTБ") || upper.contains("TB") || upper.contains("ТотБ")) return Direction.OVER;
        if (upper.contains("МЕНЬШЕ") || upper.contains("UNDER") || upper.equals("М") || upper.contains("ТМ") || upper.contains("TOTМ") || upper.contains("TM") || upper.contains("ТотМ")) return Direction.UNDER;
        return null;
    }


    private Team resolveTeam(String r) {
        if (r == null) return null;
        String upper = r.toUpperCase();
        if (upper.startsWith("1") || upper.contains("HOME") || upper.contains("П1") || upper.contains("Ф1") || upper.contains("К1")) return Team.TEAM1;
        if (upper.startsWith("2") || upper.contains("AWAY") || upper.contains("П2") || upper.contains("Ф2") || upper.contains("К2")) return Team.TEAM2;
        return null;
    }


    private BetType resolveSetMarket(SportType sport, int setNum, String subMarket, String r) {
        BetScope scope = switch (setNum) {
            case 1 -> BetScope.SET_1;
            case 2 -> BetScope.SET_2;
            case 3 -> BetScope.SET_3;
            case 4 -> BetScope.SET_4;
            case 5 -> BetScope.SET_5;
            case 6 -> BetScope.SET_6;
            case 7 -> BetScope.SET_7;
            default -> null;
        };
        if (scope == null) return null;

        StatType stat = (sport == SportType.TENNIS) ? StatType.GAMES : StatType.MATCH;

        if (subMarket.contains("ПОБЕДИТЕЛЬ") || subMarket.contains("ИСХОД")) {
            if (r.contains("1") || r.contains("П1")) return new MatchResultBet(scope, Outcome.WIN1, StatType.MATCH);
            if (r.contains("2") || r.contains("П2")) return new MatchResultBet(scope, Outcome.WIN2, StatType.MATCH);
        }
        if (subMarket.contains("ТОТАЛ")) {
            Direction dir = resolveDirection(r);
            if (dir != null) return new TotalBet(scope, BetSubject.MATCH, dir, 0.0, false, stat);
        }
        if (subMarket.contains("ФОРА")) {
            Team team = resolveTeam(r);
            if (team != null) return new HandicapBet(scope, team, 0.0, false, stat);
        }
        return null;
    }

    private BetType resolveMapMarket(SportType sport, int mapNum, String subMarket, String r) {
        BetScope scope = switch (mapNum) {
            case 1 -> BetScope.MAP_1;
            case 2 -> BetScope.MAP_2;
            case 3 -> BetScope.MAP_3;
            case 4 -> BetScope.MAP_4;
            case 5 -> BetScope.MAP_5;
            default -> null;
        };
        if (scope == null) return null;

        if (subMarket.contains("ПОБЕДИТЕЛЬ") || subMarket.contains("ИСХОД")) {
            if (r.contains("1") || r.contains("П1")) return new MatchResultBet(scope, Outcome.WIN1, StatType.MATCH);
            if (r.contains("2") || r.contains("П2")) return new MatchResultBet(scope, Outcome.WIN2, StatType.MATCH);
        }
        if (subMarket.contains("ТОТАЛ РАУНДОВ") || subMarket.contains("ТОТАЛ")) {
            Direction dir = resolveDirection(r);
            if (dir != null) return new TotalBet(scope, BetSubject.MATCH, dir, 0.0, false, StatType.MATCH);
        }
        if (subMarket.contains("ФОРА")) {
            Team team = resolveTeam(r);
            if (team != null) return new HandicapBet(scope, team, 0.0, false, StatType.MATCH);
        }
        return null;
    }

    private BetType resolveFrameMarket(SportType sport, int frameNum, String subMarket, String r) {
        // We don't have BetScope.FRAME_N yet in our common enum, but we can use generic records if we add them.
        // For now, let's keep it legacy or return null to be safe.
        return null;
    }
}

