package pro.datawiki.igaming.source.core.engine.betcity.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import pro.datawiki.igaming.dto.OddItem;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.dto.market.HandicapBet;
import pro.datawiki.igaming.source.core.aggregator.AggregatorClient;
import pro.datawiki.igaming.source.core.domain.MatchCache;
import pro.datawiki.igaming.source.core.engine.betcity.dto.BetcityEvent;
import pro.datawiki.igaming.source.core.repository.MatchCacheRepository;
import pro.datawiki.igaming.source.core.repository.SportCacheRepository;
import pro.datawiki.igaming.source.core.service.BetTypeResolverService;
import pro.datawiki.igaming.source.core.service.SportNormalizationService;
import pro.datawiki.igaming.source.core.service.UnmappedBetService;
import pro.datawiki.igaming.source.core.validation.JsonValidationService;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class BetcityParsingTest {

    private AbstractBetcityFamilyService service;
    private BetTypeResolverService betTypeResolver;
    private ObjectMapper objectMapper = new ObjectMapper();

    @BeforeEach
    void setUp() {
        MatchCacheRepository matchCacheRepository = mock(MatchCacheRepository.class);
        SportCacheRepository sportCacheRepository = mock(SportCacheRepository.class);
        AggregatorClient aggregatorClient = mock(AggregatorClient.class);
        JsonValidationService jsonValidationService = mock(JsonValidationService.class);
        UnmappedBetService unmappedBetService = mock(UnmappedBetService.class);
        SportNormalizationService sportNormalizationService = mock(SportNormalizationService.class);
        betTypeResolver = mock(BetTypeResolverService.class);

        service = new AbstractBetcityFamilyService(
                matchCacheRepository,
                sportCacheRepository,
                aggregatorClient,
                objectMapper,
                jsonValidationService,
                unmappedBetService,
                sportNormalizationService,
                betTypeResolver
        ) {
            @Override
            protected String generateEventUrl(MatchCache match, BetcityEvent event, boolean isLive) {
                return "http://test.com";
            }
        };
    }

    @Test
    void testExtractOddsWithSplitHandicap() throws Exception {
        String json = "{\"id_ev\":123, \"main\": {\"1\": {\"data\": {\"101\": {\"blocks\": {\"Handicap\": {\"F1\": -1.5, \"Kf_F1\": 1.85}}}}}}}";
        BetcityEvent event = objectMapper.readValue(json, BetcityEvent.class);
        
        HandicapBet handicapBet = new HandicapBet(pro.datawiki.igaming.dto.market.BetScope.FULL_MATCH, HandicapBet.Team.TEAM1, 0.0, false, pro.datawiki.igaming.dto.market.StatType.MATCH);
        when(betTypeResolver.resolve(any(), any(), anyString(), eq("F1"), any())).thenReturn(handicapBet);
        when(betTypeResolver.resolve(any(), any(), anyString(), eq("Kf_F1"), any())).thenReturn(handicapBet);

        List<OddItem> odds = new ArrayList<>();
        Map<String, OddItem> resolvedOdds = new HashMap<>();
        
        service.extractOddsFromSection(event.getMain(), odds, resolvedOdds, SportType.FOOTBALL, "123");

        assertEquals(1, odds.size());
        assertEquals(1.85, odds.get(0).getValue());
        assertEquals("Kf_F1", odds.get(0).getName());
        assertEquals(-1.5, odds.get(0).getBetType().getParam());
    }

    @Test
    void testExtractOddsWithLargeMd() throws Exception {
        // Large md (ID) should be ignored
        String json = "{\"id_ev\":123, \"main\": {\"1\": {\"data\": {\"101\": {\"blocks\": {\"Handicap\": {\"Kf_F1\": {\"kf\": 1.85, \"md\": 1776537467}}}}}}}}";
        BetcityEvent event = objectMapper.readValue(json, BetcityEvent.class);
        
        HandicapBet handicapBet = new HandicapBet(pro.datawiki.igaming.dto.market.BetScope.FULL_MATCH, HandicapBet.Team.TEAM1, 0.0, false, pro.datawiki.igaming.dto.market.StatType.MATCH);
        when(betTypeResolver.resolve(any(), any(), anyString(), eq("Kf_F1"), any())).thenReturn(handicapBet);

        List<OddItem> odds = new ArrayList<>();
        Map<String, OddItem> resolvedOdds = new HashMap<>();
        
        service.extractOddsFromSection(event.getMain(), odds, resolvedOdds, SportType.FOOTBALL, "123");

        assertEquals(1, odds.size());
        assertEquals(1.85, odds.get(0).getValue());
        // Param should be 0.0 because 1.77E9 was ignored and no param field F1 exists
        assertEquals(0.0, odds.get(0).getBetType().getParam());
    }

    @Test
    void testDeserializationWithNulls() throws Exception {
        String json = "{\"id_ev\":123, \"main\": null, \"ext\": null}";
        BetcityEvent event = objectMapper.readValue(json, BetcityEvent.class);
        assertNotNull(event);
        assertNull(event.getMain());
        assertNull(event.getExt());
    }
}
