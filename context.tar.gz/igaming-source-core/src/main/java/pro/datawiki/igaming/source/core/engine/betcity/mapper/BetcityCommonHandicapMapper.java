package pro.datawiki.igaming.source.core.engine.betcity.mapper;

import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import pro.datawiki.igaming.dto.BetType;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.dto.market.BetScope;
import pro.datawiki.igaming.dto.market.HandicapBet;
import pro.datawiki.igaming.dto.market.StatType;
import pro.datawiki.igaming.source.core.mapper.AbstractBetTypeMapper;

import java.util.Set;

@Component
@Order(Ordered.LOWEST_PRECEDENCE)
public class BetcityCommonHandicapMapper extends AbstractBetTypeMapper {

    private static final Set<SportType> SPECIALIZED_SPORTS = Set.of(
            SportType.FOOTBALL, SportType.BASKETBALL, SportType.HOCKEY, SportType.TENNIS,
            SportType.ESPORTS, SportType.CYBER_FOOTBALL, SportType.CYBER_BASKETBALL, SportType.CYBER_HOCKEY,
            SportType.VOLLEYBALL, SportType.BEACH_VOLLEYBALL, SportType.TABLE_TENNIS
    );

    @Override
    public boolean supports(String bookmaker, SportType sportType) {
        return bookmaker != null && bookmaker.toLowerCase().contains("betcity") && !SPECIALIZED_SPORTS.contains(sportType);
    }

    @Override
    public BetType map(String m, String o) {
        if (m == null || o == null) return null;
        String group = m.toLowerCase().trim();
        String outcome = o.toUpperCase().trim();

        if (group.matches(".*(фора|handicap|spread|f1|f2|kf_f|f1m|f2m).*")) {
            if (outcome.equals("1") || outcome.startsWith("Ф1") || outcome.equals("F1") || outcome.equals("KF_F1") || outcome.startsWith("KF_F1") || outcome.equals("F1M")) 
                return new HandicapBet(BetScope.FULL_MATCH, HandicapBet.Team.TEAM1, 0.0, false, StatType.MATCH);
            if (outcome.equals("2") || outcome.startsWith("Ф2") || outcome.equals("F2") || outcome.equals("KF_F2") || outcome.startsWith("KF_F2") || outcome.equals("F2M")) 
                return new HandicapBet(BetScope.FULL_MATCH, HandicapBet.Team.TEAM2, 0.0, false, StatType.MATCH);
        }

        return null;
    }
}
