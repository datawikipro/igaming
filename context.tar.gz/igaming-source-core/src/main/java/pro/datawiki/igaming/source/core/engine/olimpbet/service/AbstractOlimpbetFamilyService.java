package pro.datawiki.igaming.source.core.engine.olimpbet.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import pro.datawiki.igaming.dto.OddItem;
import pro.datawiki.igaming.dto.OddsUpdateRequest;
import pro.datawiki.igaming.source.core.aggregator.AggregatorClient;
import pro.datawiki.igaming.source.core.domain.MatchCache;
import pro.datawiki.igaming.source.core.domain.MatchFactor;
import pro.datawiki.igaming.source.core.domain.SportCache;
import pro.datawiki.igaming.source.core.engine.olimpbet.dto.*;
import pro.datawiki.igaming.source.core.repository.MatchCacheRepository;
import pro.datawiki.igaming.source.core.repository.SportCacheRepository;
import pro.datawiki.igaming.source.core.service.UnmappedBetService;
import pro.datawiki.igaming.source.core.validation.JsonValidationService;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.dto.BetType;
import pro.datawiki.igaming.source.core.service.BetTypeResolverService;
import pro.datawiki.igaming.source.core.service.SportNormalizationService;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.LocalDateTime;
import java.util.*;

@Slf4j
public abstract class AbstractOlimpbetFamilyService {

    protected final MatchCacheRepository matchCacheRepository;
    protected final SportCacheRepository sportCacheRepository;
    protected final AggregatorClient aggregatorClient;
    protected final ObjectMapper objectMapper;
    protected final JsonValidationService jsonValidationService;
    protected final UnmappedBetService unmappedBetService;
    protected final SportNormalizationService sportNormalizationService;
    protected final BetTypeResolverService betTypeResolver;

    public AbstractOlimpbetFamilyService(MatchCacheRepository matchCacheRepository,
                                         SportCacheRepository sportCacheRepository,
                                         AggregatorClient aggregatorClient,
                                         ObjectMapper objectMapper,
                                         JsonValidationService jsonValidationService,
                                         UnmappedBetService unmappedBetService,
                                         SportNormalizationService sportNormalizationService,
                                         BetTypeResolverService betTypeResolver) {
        this.matchCacheRepository = matchCacheRepository;
        this.sportCacheRepository = sportCacheRepository;
        this.aggregatorClient = aggregatorClient;
        this.objectMapper = objectMapper;
        this.jsonValidationService = jsonValidationService;
        this.unmappedBetService = unmappedBetService;
        this.sportNormalizationService = sportNormalizationService;
        this.betTypeResolver = betTypeResolver;
    }

    @Value("${app.bookmaker.name:olimpbet}")
    protected String bookmakerName;

    @Value("${app.bookmaker.region:ru}")
    protected String region;

    /**
     * Discovery role: processes the full line JSON and saves metadata to MatchCache.
     */
    public int discoverEvents(String json, boolean isLive) {
        if (json == null || json.isEmpty()) {
            return 0;
        }

        // 1. Strict JSON Schema Validation
        try {
            jsonValidationService.validate(json, "olimpbet-schema.json");
        } catch (Exception e) {
            log.error("CRITICAL: Olimpbet API structure changed! Skipping discovery cycle. Error: {}", e.getMessage());
            return 0;
        }

        List<OlimpbetRootResponse> responses;
        try {
            responses = objectMapper.readValue(json, new TypeReference<List<OlimpbetRootResponse>>() {});
        } catch (Exception e) {
            log.error("Failed to deserialize OlimpbetRootResponse: {}", e.getMessage());
            return 0;
        }

        if (responses == null || responses.isEmpty()) {
            return 0;
        }

        int discoveredCount = 0;
        for (OlimpbetRootResponse response : responses) {
            if (response.getPayload() == null) continue;
            
            OlimpbetPayload payload = response.getPayload();
            OlimpbetSport sport = payload.getSport();
            if (sport != null) {
                saveSport(sport);
            }

            if (payload.getCompetitionsWithEvents() == null) continue;

            for (OlimpbetCompetitionWithEvents comp : payload.getCompetitionsWithEvents()) {
                if (comp.getEvents() == null) continue;

                for (OlimpbetEvent event : comp.getEvents()) {
                    if (event.getTeam1Name() == null || event.getTeam2Name() == null) continue;

                    try {
                        saveOrUpdateMatchMetadata(event, sport, isLive);
                        discoveredCount++;
                    } catch (Exception e) {
                        log.error("Error saving metadata for Olimpbet event {}: {}", event.getId(), e.getMessage());
                    }
                }
            }
        }

        log.info("[{}/{}] Discovered {} {} events", bookmakerName, region, discoveredCount, isLive ? "live" : "prematch");
        return discoveredCount;
    }

    /**
     * Backward-compatible method: simply calls discoverEvents.
     */
    public int processResponse(String json, boolean isLive) {
        return discoverEvents(json, isLive);
    }

    protected void saveOrUpdateMatchMetadata(OlimpbetEvent event, OlimpbetSport sport, boolean isLive) {
        String externalId = event.getId();
        Optional<MatchCache> existing = matchCacheRepository.findByExternalId(externalId);

        MatchCache match = existing.orElseGet(MatchCache::new);
        match.setExternalId(externalId);
        if (sport != null) {
            try {
                match.setSportId(Integer.parseInt(sport.getId()));
            } catch (NumberFormatException ignored) {}
            match.setSportName(sport.getName());
        }
        match.setTeam1(event.getTeam1Name());
        match.setTeam2(event.getTeam2Name());
        
        long startTime = event.getStartDateTime() != null ? event.getStartDateTime() : 0;
        if (startTime > 0 && startTime < 10000000000L) {
             startTime *= 1000;
        }
        match.setStartTime(startTime);
        match.setIsLive(isLive);
        
        if (event.getScore() != null) {
            String[] parts = event.getScore().split(":");
            if (parts.length >= 2) {
                match.setScore1(parts[0].trim());
                match.setScore2(parts[1].trim());
            }
        }
        
        String jsonPayload;
        try {
            jsonPayload = objectMapper.writeValueAsString(event);
        } catch (Exception e) {
            jsonPayload = "{}";
        }

        String newHash = computeHash(jsonPayload);
        match.setUpdatedAt(LocalDateTime.now());
        if (match.getCreatedAt() == null) {
            match.setCreatedAt(LocalDateTime.now());
        }
        
        // Skip update if nothing changed (ensuring payload is also present)
        if (existing.isPresent() && 
            newHash.equals(match.getPayloadHash()) && 
            match.getIsLive() == isLive &&
            match.getJsonPayload() != null && !match.getJsonPayload().isEmpty()) {
            return;
        }

        match.setJsonPayload(jsonPayload);
        match.setPayloadHash(newHash);
        
        if (match.getPayloadHash() == null || !match.getPayloadHash().equals(newHash)) {
             match.setStatus(MatchCache.Status.NEW);
        }

        // Relational factors sync
        syncFactors(match, event);
        
        matchCacheRepository.saveAndFlush(match);
    }

    /**
     * Match-loader worker role: continuously pops the oldest matches from DB and enriches them.
     */
    @org.springframework.transaction.annotation.Transactional
    public int loadMatchCards(int batchSize) {
        List<MatchCache> batch = matchCacheRepository.findAndLockOnlyNewPendingMatches(org.springframework.data.domain.PageRequest.of(0, batchSize));

        if (batch.isEmpty()) return 0;
        int processed = 0;

        for (MatchCache cache : batch) {
            try {
                pushToAggregator(cache);
                
                // Use atomic status update to avoid version conflicts with concurrent crawler
                matchCacheRepository.updateStatus(cache.getId(), MatchCache.Status.PROCESSED, LocalDateTime.now());
                processed++;
            } catch (Exception e) {
                log.error("Failed to load Olimpbet match card for {}: {}", cache.getExternalId(), e.getMessage());
                matchCacheRepository.updateStatus(cache.getId(), MatchCache.Status.FAILED, LocalDateTime.now());
            }
        }
        return processed;
    }

    protected void pushToAggregator(MatchCache match) {
        OlimpbetEvent event = parseOlimpbetEvent(match);
        if (event == null) return;

        OddsUpdateRequest request = buildOddsUpdateRequest(match, event);
        
        if (event.getOutcomes() != null) {
            List<OddItem> odds = processOdds(match, event, request.getSportType());
            if (!odds.isEmpty()) {
                request.setOdds(odds);
                aggregatorClient.pushOddsUpdate(request);
            }
        }
    }

    private OlimpbetEvent parseOlimpbetEvent(MatchCache match) {
        try {
            return objectMapper.readValue(match.getJsonPayload(), OlimpbetEvent.class);
        } catch (Exception e) {
            log.error("Failed to parse cached payload for {}: {}", match.getExternalId(), e.getMessage());
            return null;
        }
    }

    private OddsUpdateRequest buildOddsUpdateRequest(MatchCache match, OlimpbetEvent event) {
        OddsUpdateRequest request = new OddsUpdateRequest();
        request.setBookmaker(bookmakerName);
        request.setRegion(region);
        request.setEventUrl(generateEventUrl(match, event, match.getIsLive()));
        request.setExternalEventId(match.getExternalId());
        request.setSportName(match.getSportName());
        request.setTeam1(match.getTeam1());
        request.setTeam2(match.getTeam2());
        request.setScore1(match.getScore1());
        request.setScore2(match.getScore2());
        request.setStartTime(match.getStartTime());
        request.setIsLive(match.getIsLive());
        request.setPayloadHash(match.getPayloadHash());

        SportType sportType = resolveOlimpbetSportType(match.getSportName());
        request.setSportType(sportType);
        return request;
    }

    private List<OddItem> processOdds(MatchCache match, OlimpbetEvent event, SportType sportType) {
        List<OddItem> odds = new ArrayList<>();
        Map<String, OddItem> resolvedOdds = new HashMap<>();

        for (OlimpbetOutcome outcome : event.getOutcomes()) {
            if (outcome.getProbability() != null) {
                try {
                    String rawName = outcome.getShortName();
                    String groupName = outcome.getGroupName();
                    BetType betType = betTypeResolver.resolve(bookmakerName, sportType, groupName, rawName);

                    if ("UNKNOWN".equals(betType.code())) {
                        unmappedBetService.saveAndNotify(bookmakerName, sportType.name(), rawName, groupName, match.getExternalId());
                        continue;
                    }

                    // Inject param into parametric bet types (totals, handicaps)
                    if (betType.isParametric() && outcome.getParam() != null && !outcome.getParam().isEmpty()) {
                        try {
                            double param = Double.parseDouble(outcome.getParam().replace(',', '.'));
                            if (param != 0.0) {
                                betType = betType.withParam(param * betType.paramMultiplier());
                            }
                        } catch (NumberFormatException | UnsupportedOperationException ignored) {}
                    }

                    OddItem item = buildOddItem(outcome, betType, rawName, groupName);

                    String semanticKey = betType.code();
                    if (resolvedOdds.containsKey(semanticKey)) {
                        OddItem existing = resolvedOdds.get(semanticKey);
                        if (!existing.getValue().equals(item.getValue())) {
                            log.error("DUPLICATE COEFFICIENT ATTEMPT: Tried to map 1 coefficient twice with DIFFERENT values! " +
                                      "Match={}, SemanticKey={}, ExistingValue={}, NewValue={}, ExistingOriginalName='{}', NewOriginalName='{}'",
                                      match.getExternalId(), semanticKey, existing.getValue(), item.getValue(),
                                      existing.getName(), item.getName());
                        }
                        continue; // skip the duplicate
                    }

                    resolvedOdds.put(semanticKey, item);
                    odds.add(item);
                } catch (NumberFormatException ignored) {}
            }
        }
        return odds;
    }

    private OddItem buildOddItem(OlimpbetOutcome outcome, BetType betType, String rawName, String groupName) {
        OddItem item = new OddItem();
        item.setFactorId(Math.abs(rawName.hashCode()));
        item.setName(rawName);
        item.setValue(Double.parseDouble(outcome.getProbability()));
        item.setGroupName(groupName);
        item.setBetType(betType);
        return item;
    }

    private void syncFactors(MatchCache match, OlimpbetEvent event) {
        if (event.getOutcomes() == null) return;
        match.getFactors().clear();
        for (OlimpbetOutcome outcome : event.getOutcomes()) {
            if (outcome.getProbability() != null) {
                try {
                    MatchFactor factor = new MatchFactor();
                    factor.setMatch(match);
                    factor.setName(outcome.getShortName());
                    factor.setValue(Double.parseDouble(outcome.getProbability()));
                    factor.setFactorId(Math.abs(outcome.getShortName().hashCode()));
                    match.getFactors().add(factor);
                } catch (NumberFormatException ignored) {}
            }
        }
    }

    private String computeHash(String content) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(content.getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(hash);
        } catch (Exception e) {
            return String.valueOf(content.hashCode());
        }
    }

    private void saveSport(OlimpbetSport olimpbetSport) {
        try {
            int sportId = Integer.parseInt(olimpbetSport.getId());
            Optional<SportCache> existing = sportCacheRepository.findByExternalId(sportId);
            SportCache sport = existing.orElseGet(SportCache::new);
            sport.setExternalId(sportId);
            sport.setName(olimpbetSport.getName());
            sport.setUpdatedAt(LocalDateTime.now());
            sportCacheRepository.save(sport);
        } catch (Exception e) {
            log.debug("Error saving sport {}: {}", olimpbetSport.getId(), e.getMessage());
        }
    }

    protected SportType resolveOlimpbetSportType(String sportName) {
        if (sportName == null) return SportType.UNKNOWN;
        return sportNormalizationService.normalize(sportName);
    }

    protected abstract String generateEventUrl(MatchCache match, OlimpbetEvent event, boolean isLive);
}
