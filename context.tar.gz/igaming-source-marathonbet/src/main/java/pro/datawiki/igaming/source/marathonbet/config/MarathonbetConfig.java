package pro.datawiki.igaming.source.marathonbet.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
@ConfigurationProperties(prefix = "app.marathonbet")
@Data
public class MarathonbetConfig {
    /** Base URL for marathonbet.ru */
    private String baseUrl = "https://www.marathonbet.ru";
    /** Menu API for prematch sports tree (returns JSON) */
    private String menuPrematchUrl = "https://www.marathonbet.ru/su/react/event/menu/prematch";
    /** Menu API for live sports tree (returns JSON) */
    private String menuLiveUrl = "https://www.marathonbet.ru/su/react/event/menu/live";
    /** Betting page base URL (returns HTML with events) */
    private String bettingBaseUrl = "https://www.marathonbet.ru/su/betting";
    /** Live update JSONP endpoint */
    private String liveUpdateUrl = "https://lu.marathonbet.ru/su/liveupdate";
    /** Top-level sport UIDs to scrape (Football=11, Hockey=537, Basketball=6, Tennis=2398) */
    private List<String> sportUids = List.of("11", "537", "6", "2398");
    /** Max leagues to scrape per sport */
    private int maxLeaguesPerSport = 10;
    /** Fetch interval in seconds for REST polling */
    private int fetchIntervalSeconds = 120;
    /** Prematch fetch interval in seconds */
    private int prematchFetchIntervalSeconds = 300;
    /** HTTP request timeout in ms */
    private int requestTimeoutMs = 15000;
    /** User-Agent for REST requests */
    private String userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";

    /** Backup proxy host for 403 retries */
    private String backupProxyHost;
    /** Backup proxy port for 403 retries */
    private int backupProxyPort = 3128;
}
