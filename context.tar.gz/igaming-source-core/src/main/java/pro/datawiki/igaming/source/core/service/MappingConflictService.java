package pro.datawiki.igaming.source.core.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import pro.datawiki.igaming.source.core.domain.MappingConflict;
import pro.datawiki.igaming.source.core.repository.MappingConflictRepository;

import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
public class MappingConflictService {

    private final MappingConflictRepository repository;

    /**
     * Saves a mapping conflict if this (bookmaker, sportType, market, outcome) combination
     * has not been seen before (deduplication).
     */
    public void saveIfNew(String bookmaker, String sportType, String market, String outcome,
                          String conflictingMappers, String eventId) {
        Optional<MappingConflict> existing = repository
                .findFirstByBookmakerAndSportTypeAndMarketAndOutcome(bookmaker, sportType, market, outcome);

        if (existing.isEmpty()) {
            log.error("MAPPING CONFLICT: {}:{} market='{}' outcome='{}' mappers=[{}] event={}",
                    bookmaker, sportType, market, outcome, conflictingMappers, eventId);

            repository.save(MappingConflict.builder()
                    .bookmaker(bookmaker)
                    .sportType(sportType)
                    .market(market)
                    .outcome(outcome)
                    .conflictingMappers(conflictingMappers)
                    .eventId(eventId)
                    .build());
        }
    }
}
