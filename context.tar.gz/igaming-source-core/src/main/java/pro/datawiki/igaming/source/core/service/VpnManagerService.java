package pro.datawiki.igaming.source.core.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.client.HttpStatusCodeException;
import pro.datawiki.igaming.source.core.dto.VpnConfigDto;

import java.net.InetAddress;
import java.net.UnknownHostException;
import org.springframework.boot.CommandLineRunner;

@Service
@RequiredArgsConstructor
@Slf4j
public class VpnManagerService implements CommandLineRunner {

    private static final String DEFAULT_PROXY_HOST = "igaming-vpn-proxy-ru";
    private static final String DEFAULT_PROXY_PORT = "3128";
    private static final String NON_PROXY_HOSTS = "igaming-aggregator|localhost|127.*|10.*|172.*|192.168.*";

    private static final int CONNECTIVITY_MAX_RETRIES = 3;
    private static final long CONNECTIVITY_RETRY_DELAY_MS = 5000;

    private final RestTemplate restTemplate;

    @Value("${spring.application.name}")
    private String applicationName;

    @Value("${app.aggregator.url:http://igaming-aggregator}")
    private String aggregatorUrl;

    @Value("${app.target.host:}")
    private String targetHost;

    @Value("${app.proxy.host:}")
    private String proxyHostOverride;

    @Override
    public void run(String... args) throws Exception {
        log.info("Checking for active VPN configurations from Aggregator via REST ({}/api/v1/config/vpn/{})...", aggregatorUrl, applicationName);

        try {
            String url = String.format("%s/api/v1/config/vpn/%s", aggregatorUrl, applicationName);

            ResponseEntity<VpnConfigDto> response = restTemplate.getForEntity(url, VpnConfigDto.class);

            if (!response.getStatusCode().is2xxSuccessful() || response.getBody() == null) {
                log.error("No active VPN configuration found from aggregator (Status: {}).", response.getStatusCode());
                throw new IllegalStateException("Proxy is mandatory! No active VPN configuration found.");
            }

            VpnConfigDto config = response.getBody();
            if (config.getEnabled() == null || !config.getEnabled()) {
                log.error("VPN configuration found but is Disabled.");
                throw new IllegalStateException("Proxy is mandatory! VPN configuration is disabled.");
            }

            log.info("Found active VPN configuration. Configuring centralized proxy...");

            configureProxy(config);

            // Validate connectivity to the target bookmaker through the proxy
            verifyTargetConnectivity();

        } catch (Exception e) {
            log.error("Failed to initialize VPN proxy from Aggregator: {}", e.getMessage());
            throw new IllegalStateException("Failed to initialize mandatory VPN proxy", e);
        }
    }

    /**
     * Configures the JVM to route all HTTP/HTTPS traffic through the centralized VPN proxy.
     * This replaces the old per-pod WireGuard tunnel setup with a simple Java proxy injection.
     * The proxy pod (igaming-vpn-proxy-ru) runs WireGuard + tinyproxy in Kubernetes.
     */
    private void configureProxy(VpnConfigDto config) {
        String proxyHost;
        if (StringUtils.hasText(proxyHostOverride)) {
            proxyHost = proxyHostOverride;
            log.info("Using proxy host override from environment: {}", proxyHost);
        } else {
            proxyHost = StringUtils.hasText(config.getProxyHost())
                    ? config.getProxyHost()
                    : DEFAULT_PROXY_HOST;
        }

        log.info("Configuring proxy: {}:{}", proxyHost, DEFAULT_PROXY_PORT);

        System.setProperty("http.proxyHost", proxyHost);
        System.setProperty("http.proxyPort", DEFAULT_PROXY_PORT);
        System.setProperty("https.proxyHost", proxyHost);
        System.setProperty("https.proxyPort", DEFAULT_PROXY_PORT);
        System.setProperty("http.nonProxyHosts", NON_PROXY_HOSTS);

        log.info("✅ Proxy configured: {}:{} (non-proxy: {})", proxyHost, DEFAULT_PROXY_PORT, NON_PROXY_HOSTS);
    }

    /**
     * Validates that the target bookmaker host is reachable through the VPN proxy.
     * Performs DNS resolution and HTTP connectivity check with retries.
     * Fails fast with a clear regional restriction message if unreachable.
     */
    private void verifyTargetConnectivity() {
        if (!StringUtils.hasText(targetHost)) {
            log.warn("Property 'app.target.host' is not set — skipping post-VPN connectivity check.");
            return;
        }

        log.info("Verifying connectivity to target host '{}' through proxy ({} retries, {}ms delay)...",
                targetHost, CONNECTIVITY_MAX_RETRIES, CONNECTIVITY_RETRY_DELAY_MS);

        for (int attempt = 1; attempt <= CONNECTIVITY_MAX_RETRIES; attempt++) {
            try {
                // Step 1: DNS resolution (informative only, proxy might handle it)
                log.info("[Attempt {}/{}] Resolving DNS for '{}'...", attempt, CONNECTIVITY_MAX_RETRIES, targetHost);
                try {
                    InetAddress address = InetAddress.getByName(targetHost);
                    log.info("[Attempt {}/{}] DNS resolved: {} -> {}", attempt, CONNECTIVITY_MAX_RETRIES, targetHost, address.getHostAddress());
                } catch (UnknownHostException e) {
                    log.warn("[Attempt {}/{}] Local DNS resolution failed for '{}'. Proxy might still resolve it.",
                            attempt, CONNECTIVITY_MAX_RETRIES, targetHost);
                }

                // Step 2: HTTP connectivity check (goes through the configured proxy)
                log.info("[Attempt {}/{}] Checking HTTP connectivity to 'https://{}'...", attempt, CONNECTIVITY_MAX_RETRIES, targetHost);
                int responseCode = checkHttpConnectivity(targetHost);
                log.info("✅ Target host '{}' is reachable (HTTP {}). Proxy connectivity verified.", targetHost, responseCode);
                return; // success

            } catch (Exception e) {
                log.warn("❌ [Attempt {}/{}] Connectivity check failed for '{}': {}",
                        attempt, CONNECTIVITY_MAX_RETRIES, targetHost, e.getMessage());
            }

            if (attempt < CONNECTIVITY_MAX_RETRIES) {
                log.info("Waiting {}ms before retry...", CONNECTIVITY_RETRY_DELAY_MS);
                try {
                    Thread.sleep(CONNECTIVITY_RETRY_DELAY_MS);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        }

        // All retries exhausted
        String errorMessage = String.format(
                "🚫 REGIONAL RESTRICTION DETECTED: Cannot reach target host '%s' after %d attempts. " +
                "The centralized VPN proxy does not provide access to this region. " +
                "Please check the igaming-vpn-proxy-ru pod status and VPN configuration for application '%s'.",
                targetHost, CONNECTIVITY_MAX_RETRIES, applicationName);
        log.error(errorMessage);
        throw new IllegalStateException(errorMessage);
    }

    /**
     * Performs an HTTP HEAD request to the target host with a timeout.
     * The request is automatically routed through the configured proxy (System.setProperty)
     * and uses the pre-configured RestTemplate which ignores SSL certificate errors.
     */
    private int checkHttpConnectivity(String host) {
        String url = "https://" + host;
        try {
            // restTemplate is already configured with SSL-ignoring trust strategy and timeouts
            ResponseEntity<Void> response = restTemplate.exchange(url, HttpMethod.HEAD, null, Void.class);
            return response.getStatusCode().value();
        } catch (HttpStatusCodeException e) {
            log.info("Target host '{}' responded with HTTP {} (which confirms connectivity through proxy).",
                    host, e.getStatusCode());
            return e.getStatusCode().value(); // 404, 403, etc still mean we reached the server!
        } catch (Exception e) {
            log.error("Connectivity check failed to {}: {}", url, e.getMessage());
            throw e;
        }
    }
}
