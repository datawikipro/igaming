package pro.datawiki.igaming.source.marathonbet.mapper.basketball;

import org.springframework.stereotype.Component;
import pro.datawiki.igaming.dto.BetType;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.dto.market.BetScope;
import pro.datawiki.igaming.dto.market.HandicapBet;
import pro.datawiki.igaming.dto.market.StatType;
import pro.datawiki.igaming.source.core.mapper.AbstractBetTypeMapper;

@Component
public class MarathonBasketballHandicapMapper extends AbstractBetTypeMapper {

    @Override
    public boolean supports(String bookmaker, SportType sportType) {
        return "marathonbet".equals(bookmaker) && sportType == SportType.BASKETBALL;
    }

    @Override
    public BetType map(String m, String o) {
        if (m == null || o == null) return null;
        String upperM = m.toUpperCase().trim();
        String upperO = o.toUpperCase().trim();

        // 2. Handicap
        if (upperM.matches("^(HANDICAP|HANDICAP_BETTING_POINTS)$")) {
            HandicapBet.Team team = (upperO.equals("1") || upperO.equals("HB_H") || upperO.equals("HB_ASN_H")) ? HandicapBet.Team.TEAM1 : HandicapBet.Team.TEAM2;
            return new HandicapBet(BetScope.FULL_MATCH, team, 0.0, false, StatType.MATCH);
        }

        // 7. Quarter Handicaps
        if (upperM.matches("^HANDICAP_-_([1-4])(ST|ND|RD|TH)_QUARTER$")) {
            String q = upperM.replaceAll("^HANDICAP_-_([1-4]).*", "$1");
            boolean isH1 = "1".equals(upperO) || "HB_H".equals(upperO);
            BetScope scope = switch (q) {
                case "1" -> BetScope.QUARTER_1;
                case "2" -> BetScope.QUARTER_2;
                case "3" -> BetScope.QUARTER_3;
                case "4" -> BetScope.QUARTER_4;
                default -> null;
            };
            return new HandicapBet(scope, isH1 ? HandicapBet.Team.TEAM1 : HandicapBet.Team.TEAM2, 0.0, false, StatType.MATCH);
        }

        return null;
    }
}
