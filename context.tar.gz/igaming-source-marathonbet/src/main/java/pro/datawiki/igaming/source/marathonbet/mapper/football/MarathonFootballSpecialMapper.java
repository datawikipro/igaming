package pro.datawiki.igaming.source.marathonbet.mapper.football;

import org.springframework.stereotype.Component;
import pro.datawiki.igaming.dto.BetType;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.dto.market.BetScope;
import pro.datawiki.igaming.dto.market.BetSubject;
import pro.datawiki.igaming.dto.market.BinaryMarketBet;
import pro.datawiki.igaming.dto.market.StatType;
import pro.datawiki.igaming.source.core.mapper.AbstractBetTypeMapper;

@Component
public class MarathonFootballSpecialMapper extends AbstractBetTypeMapper {

    @Override
    public boolean supports(String bookmaker, SportType sportType) {
        return "marathonbet".equals(bookmaker) && sportType == SportType.FOOTBALL;
    }

    @Override
    public BetType map(String m, String o) {
        if (m == null || o == null) return null;
        String upperM = m.toUpperCase().trim();
        String upperO = o.toUpperCase().trim();

        // 8. Correct Score
        if (upperM.contains("CORRECT_SCORE")) {
            BetScope scope = BetScope.FULL_MATCH;
            if (upperM.contains("1ST_HALF")) scope = BetScope.HALF_1;
            else if (upperM.contains("2ND_HALF")) scope = BetScope.HALF_2;
            return mapCorrectScoreRecord(upperO, scope);
        }

        // 9. Special Markets
        if ("BOTH_TEAMS_TO_SCORE".equals(upperM)) {
            return new BinaryMarketBet(BetScope.FULL_MATCH, BetSubject.MATCH, BinaryMarketBet.MarketType.BTTS, "YES".equals(upperO) ? BinaryMarketBet.Outcome.YES : BinaryMarketBet.Outcome.NO, StatType.MATCH);
        }
        if ("TO_QUALIFY".equals(upperM)) {
            BetSubject subject = ("1".equals(upperO) || "HOME".equals(upperO)) ? BetSubject.TEAM1 : BetSubject.TEAM2;
            return new BinaryMarketBet(BetScope.FULL_MATCH, subject, BinaryMarketBet.MarketType.QUALIFY, BinaryMarketBet.Outcome.YES, StatType.MATCH);
        }
        if ("OWN_GOAL".equals(upperM)) {
            return new BinaryMarketBet(BetScope.FULL_MATCH, BetSubject.MATCH, BinaryMarketBet.MarketType.OWN_GOAL, "YES".equals(upperO) ? BinaryMarketBet.Outcome.YES : BinaryMarketBet.Outcome.NO, StatType.MATCH);
        }

        return null;
    }
}
