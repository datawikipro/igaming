package pro.datawiki.igaming.source.marathonbet.scheduler;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import pro.datawiki.igaming.source.marathonbet.service.MatchService;

@Component
@RequiredArgsConstructor
@Slf4j
@ConditionalOnProperty(name = "app.role", havingValue = "match-loader")
public class MatchLoadScheduler {

    private final MatchService matchService;

    @Scheduled(fixedDelayString = "${app.match-loader.poll-delay-ms:3000}")
    public void loadMatches() {
        try {
            int processed = matchService.loadMatchCards(3);
            if (processed > 0) {
                log.debug("Match-loader processed {} matches in this cycle", processed);
            }
        } catch (Exception e) {
            log.error("Error during scheduled match loading", e);
        }
    }
}
