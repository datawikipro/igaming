package pro.datawiki.igaming.source.core.engine.zenit.mapper;

import org.springframework.stereotype.Component;
import pro.datawiki.igaming.dto.BetType;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.dto.market.BetScope;
import pro.datawiki.igaming.dto.market.BetSubject;
import pro.datawiki.igaming.dto.market.StatType;
import pro.datawiki.igaming.source.core.mapper.AbstractBetTypeMapper;

import java.util.Set;

@Component
public class ZenitCommonTotalMapper extends AbstractBetTypeMapper {

    private static final Set<SportType> SPECIALIZED_SPORTS = Set.of(
            SportType.FOOTBALL, SportType.BASKETBALL, SportType.HOCKEY, SportType.TENNIS,
            SportType.ESPORTS, SportType.CYBER_FOOTBALL, SportType.CYBER_BASKETBALL, SportType.CYBER_HOCKEY,
            SportType.VOLLEYBALL, SportType.BEACH_VOLLEYBALL, SportType.TABLE_TENNIS
    );

    @Override
    public boolean supports(String bookmaker, SportType sportType) {
        return "zenit".equals(bookmaker) && !SPECIALIZED_SPORTS.contains(sportType);
    }

    @Override
    public BetType map(String market, String outcome) {
        if ("11".equals(outcome)) return mapTotalRecord("OVER", BetScope.FULL_MATCH, BetSubject.MATCH, StatType.MATCH, false);
        if ("12".equals(outcome)) return mapTotalRecord("UNDER", BetScope.FULL_MATCH, BetSubject.MATCH, StatType.MATCH, false);

        if (market == null) return null;
        String upperM = market.toUpperCase().trim();

        if (upperM.contains("ТОТАЛ") || upperM.contains("TOTAL")) {
            BetSubject subject = BetSubject.MATCH;
            if (upperM.contains("ИНДИВИДУАЛЬНЫЙ ТОТАЛ 1") || upperM.contains("1-ГО")) subject = BetSubject.TEAM1;
            else if (upperM.contains("ИНДИВИДУАЛЬНЫЙ ТОТАЛ 2") || upperM.contains("2-ГО")) subject = BetSubject.TEAM2;

            // Zenit often has outcome names like "БОЛЬШЕ", "МЕНЬШЕ"
            // But if we pass factorId as outcome, we check it first.
            // If we want to support both, we'd need more complex logic.
        }

        return null;
    }
}
