package pro.datawiki.igaming.source.core.engine.olimpbet.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class OlimpbetRootResponse {
    private String operationId;
    private Integer version;
    private OlimpbetPayload payload;
}
