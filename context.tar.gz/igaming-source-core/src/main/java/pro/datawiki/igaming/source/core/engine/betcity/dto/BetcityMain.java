package pro.datawiki.igaming.source.core.engine.betcity.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.Data;
import java.io.IOException;
import java.util.Map;
import com.fasterxml.jackson.databind.JavaType;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonDeserialize(using = BetcityMain.Deserializer.class)
public class BetcityMain {
    private String name;
    private Map<String, BetcityData> data;

    public String getName() { return name; }
    public Map<String, BetcityData> getData() { return data; }
    public void setName(String name) { this.name = name; }
    public void setData(Map<String, BetcityData> data) { this.data = data; }

    public static class Deserializer extends JsonDeserializer<BetcityMain> {
        @Override
        public BetcityMain deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
            if (p.currentToken() == JsonToken.START_OBJECT) {
                JsonNode node = p.getCodec().readTree(p);
                BetcityMain main = new BetcityMain();
                if (node.has("name")) main.setName(node.get("name").asText());
                if (node.has("data") && !node.get("data").isNull()) {
                    JavaType type = ctxt.getTypeFactory().constructMapType(Map.class, String.class, BetcityData.class);
                    main.setData(ctxt.readTreeAsValue(node.get("data"), type));
                }
                return main;
            }
            p.skipChildren();
            return null;
        }
    }
}
