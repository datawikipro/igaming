package pro.datawiki.igaming.source.marathonbet.mapper.tennis;

import org.springframework.stereotype.Component;
import pro.datawiki.igaming.dto.BetType;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.dto.market.BetScope;
import pro.datawiki.igaming.dto.market.StatType;
import pro.datawiki.igaming.source.core.mapper.AbstractBetTypeMapper;

@Component
public class MarathonTennisResultMapper extends AbstractBetTypeMapper {

    @Override
    public boolean supports(String bookmaker, SportType sportType) {
        return "marathonbet".equals(bookmaker) && sportType == SportType.TENNIS;
    }

    @Override
    public BetType map(String m, String o) {
        if (m == null || o == null) return null;

        // 1. Match Winner (2-way)
        if (m.matches("^(WIN_-_MATCH|MATCH_RESULT|RESULT)$") || "1".equals(m) || "2".equals(m)) {
            return map1X2Record(o, BetScope.FULL_MATCH, StatType.MATCH);
        }

        // 2. Set Results
        if (m.matches("^RESULT_-_([1-5])(ST|ND|RD|TH)?_SET$")) {
            BetScope scope = switch (m.replaceAll("^RESULT_-_([1-5]).*", "$1")) {
                case "1" -> BetScope.SET_1;
                case "2" -> BetScope.SET_2;
                case "3" -> BetScope.SET_3;
                case "4" -> BetScope.SET_4;
                case "5" -> BetScope.SET_5;
                default -> null;
            };
            if (scope != null) return map1X2Record(o, scope, StatType.MATCH);
        }

        return null;
    }
}
