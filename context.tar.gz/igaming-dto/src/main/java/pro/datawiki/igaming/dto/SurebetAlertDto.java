package pro.datawiki.igaming.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class SurebetAlertDto {
    private Long id;
    private Long matchId;
    private String matchDescription;
    private Double margin;
    private Double profitPercent;
    private String status;
    private LocalDateTime detectedAt;
    private LocalDateTime expiredAt;
    private Long secondsToStart;
    private Integer sourceCount;
    private Boolean isLive;

    private java.util.List<OutcomeDto> outcomes;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
    public static class OutcomeDto {
        private String bookmaker;
        private String betType;
        private Double odds;
        private String externalEventId;
        private String eventUrl;
    }


}
