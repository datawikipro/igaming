package pro.datawiki.igaming.source.core.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.stereotype.Service;
import pro.datawiki.igaming.source.core.domain.MatchCache;
import pro.datawiki.igaming.source.core.repository.MatchCacheRepository;
import org.springframework.beans.factory.annotation.Value;

/**
 * Universal default implementation of RefreshCallback.
 * If a specific source microservice does not define its own RefreshCallback,
 * this default bean will be registered automatically by Spring.
 * It simply changes the MatchCache status to TARGETED_REFRESH, delegating the actual 
 * API fetching to the existing scheduling loops.
 */
@Service
@ConditionalOnMissingBean(RefreshCallback.class)
@RequiredArgsConstructor
@Slf4j
public class DefaultRefreshCallback implements RefreshCallback {

    private final MatchCacheRepository matchCacheRepository;

    @Value("${app.bookmaker.name:unknown}")
    private String bookmakerName;

    @Override
    public void refreshEvent(String matchExternalId) {
        matchCacheRepository.findByExternalId(matchExternalId).ifPresent(cache -> {
            cache.setStatus(MatchCache.Status.TARGETED_REFRESH);
            cache.setUpdatedAt(java.time.LocalDateTime.now());
            matchCacheRepository.save(cache);
            log.info("Delegating targeted refresh for {} match: {} to TARGETED_REFRESH queue (Priority=CRITICAL)", bookmakerName, matchExternalId);
        });
    }
}
