package pro.datawiki.igaming.admin.config;

import io.fabric8.kubernetes.client.Config;
import io.fabric8.kubernetes.client.ConfigBuilder;
import io.fabric8.kubernetes.client.DefaultKubernetesClient;
import io.fabric8.kubernetes.client.KubernetesClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class KubernetesConfig {

    @org.springframework.beans.factory.annotation.Value("${k3s.server-url:}")
    private String k3sServerUrl;

    @org.springframework.beans.factory.annotation.Value("${k3s.token:}")
    private String k3sToken;

    @Bean
    public KubernetesClient kubernetesClient() {
        ConfigBuilder configBuilder = new ConfigBuilder();
        
        if (k3sServerUrl != null && !k3sServerUrl.isBlank()) {
            configBuilder.withMasterUrl(k3sServerUrl);
        }
        
        // Disable SSL verification for internal K3s if needed (common with self-signed certs)
        configBuilder.withTrustCerts(true);

        return new DefaultKubernetesClient(configBuilder.build());
    }
}
