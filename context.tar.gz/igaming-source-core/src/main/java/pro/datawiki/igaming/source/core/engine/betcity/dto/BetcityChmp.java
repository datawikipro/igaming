package pro.datawiki.igaming.source.core.engine.betcity.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.Data;
import java.io.IOException;
import java.util.Map;
import com.fasterxml.jackson.databind.JavaType;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonDeserialize(using = BetcityChmp.Deserializer.class)
public class BetcityChmp {
    @JsonProperty("id_ch")
    private Integer idCh;
    
    @JsonProperty("name_ch")
    private String nameCh;
    
    private Map<String, BetcityEvent> evts;

    public static class Deserializer extends JsonDeserializer<BetcityChmp> {
        @Override
        public BetcityChmp deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
            if (p.currentToken() == JsonToken.START_OBJECT) {
                JsonNode node = p.getCodec().readTree(p);
                BetcityChmp chmp = new BetcityChmp();
                if (node.has("id_ch") && !node.get("id_ch").isNull()) chmp.setIdCh(node.get("id_ch").asInt());
                if (node.has("name_ch") && !node.get("name_ch").isNull()) chmp.setNameCh(node.get("name_ch").asText());
                if (node.has("evts")) {
                    JavaType type = ctxt.getTypeFactory().constructMapType(Map.class, String.class, BetcityEvent.class);
                    chmp.setEvts(ctxt.readTreeAsValue(node.get("evts"), type));
                }
                return chmp;
            }
            p.skipChildren();
            return null;
        }
    }
}
