package pro.datawiki.igaming.source.core.engine.betcity.mapper;

import org.springframework.stereotype.Component;
import pro.datawiki.igaming.dto.BetType;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.dto.market.BetScope;
import pro.datawiki.igaming.dto.market.MatchResultBet;
import pro.datawiki.igaming.dto.market.StatType;
import pro.datawiki.igaming.source.core.mapper.AbstractBetTypeMapper;

import static pro.datawiki.igaming.dto.market.MatchResultBet.Outcome.*;

@Component
public class BetcityFootballResultMapper extends AbstractBetTypeMapper {

    @Override
    public boolean supports(String bookmaker, SportType sportType) {
        return bookmaker != null && bookmaker.toLowerCase().contains("betcity") && sportType == SportType.FOOTBALL;
    }

    @Override
    public BetType map(String m, String o) {
        if (m == null || o == null) return null;
        String group = m.toLowerCase().trim();
        String outcome = o.toUpperCase().trim();

        if (group.contains("1-й тайм") || group.contains("1-го тайма")) {
            if (group.contains("результат") || group.contains("исход")) {
                if (outcome.matches("1|П1|P1")) return new MatchResultBet(BetScope.FIRST_HALF, WIN1, StatType.MATCH);
                if (outcome.matches("X|DRAW|НИЧЬЯ")) return new MatchResultBet(BetScope.FIRST_HALF, DRAW, StatType.MATCH);
                if (outcome.matches("2|П2|P2")) return new MatchResultBet(BetScope.FIRST_HALF, WIN2, StatType.MATCH);
            }
        }

        if (group.contains("2-й тайм") || group.contains("2-го тайма")) {
            if (group.contains("результат") || group.contains("исход")) {
                if (outcome.matches("1|П1|P1")) return new MatchResultBet(BetScope.SECOND_HALF, WIN1, StatType.MATCH);
                if (outcome.matches("X|DRAW|НИЧЬЯ")) return new MatchResultBet(BetScope.SECOND_HALF, DRAW, StatType.MATCH);
                if (outcome.matches("2|П2|P2")) return new MatchResultBet(BetScope.SECOND_HALF, WIN2, StatType.MATCH);
            }
        }

        return null;
    }
}
