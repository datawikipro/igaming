package pro.datawiki.igaming.source.marathonbet.service;

import lombok.extern.slf4j.Slf4j;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.stereotype.Component;
import pro.datawiki.igaming.source.marathonbet.dto.marathon.MarathonEvent;
import pro.datawiki.igaming.source.marathonbet.dto.marathon.MarathonMenuNode;
import pro.datawiki.igaming.source.marathonbet.dto.marathon.MarathonOdd;

import java.util.*;

/**
 * Dedicated component for parsing Marathonbet HTML documents using Jsoup.
 */
@Component
@Slf4j
public class MarathonHtmlParser {

    private static final String[] STANDARD_ODD_NAMES = {"1", "X", "2"};

    private interface OddParamExtractor {
        boolean extract(Element priceEl, MarathonOdd odd, String rawName);
    }

    private final MarathonOddParamNormalizer normalizer;
    private final List<OddParamExtractor> paramExtractors;

    public MarathonHtmlParser(MarathonOddParamNormalizer normalizer) {
        this.normalizer = normalizer;
        this.paramExtractors = Arrays.asList(
            // 1. Asian totals with two explicit numbers (e.g. 2_2.5) -> average
            (priceEl, odd, rawName) -> {
                java.util.regex.Matcher m = java.util.regex.Pattern.compile("(.+)[_\\.](\\d+\\.?\\d*)[_](\\d+\\.?\\d*)$").matcher(rawName);
                if (m.matches()) {
                    try {
                        double p1 = Double.parseDouble(m.group(2).replace('_', '.'));
                        double p2 = Double.parseDouble(m.group(3).replace('_', '.'));
                        odd.setParam((p1 + p2) / 2.0);
                        return true;
                    } catch (Exception ignored) {}
                }
                return false;
            },
            // 2. Explicit data-param attribute (most reliable for regular odds)
            (priceEl, odd, rawName) -> {
                String dataParam = priceEl.attr("data-param");
                if (dataParam == null || dataParam.isEmpty()) {
                    Element paramEl = priceEl.closest("[data-param]");
                    if (paramEl != null) dataParam = paramEl.attr("data-param");
                }
                if (dataParam != null && !dataParam.isEmpty()) {
                    double val = parseSafeDouble(dataParam);
                    if (val != 0.0) {
                        odd.setParam(val);
                        return true;
                    }
                }
                return false;
            },
            // 3. Fallback to extracting single number from the name
            (priceEl, odd, rawName) -> {
                java.util.regex.Matcher m = java.util.regex.Pattern.compile("(.+)[_\\.](\\d+\\.?\\d*)$").matcher(rawName);
                if (m.matches()) {
                    try {
                        double extractedNameParam = Double.parseDouble(m.group(2));
                        if (extractedNameParam != 0.0) {
                            odd.setParam(extractedNameParam);
                            return true;
                        }
                    } catch (NumberFormatException ignored) {}
                }
                return false;
            }
        );
    }

    /**
     * Parse events from Marathonbet HTML page structure.
     */
    public List<MarathonEvent> parseEventsFromHtml(Document doc, MarathonMenuNode league) {
        List<MarathonEvent> events = new ArrayList<>();
        Elements eventRows = doc.select("[data-event-treeid]");

        if (eventRows.isEmpty()) {
            log.warn("No match rows found with [data-event-treeid] in league: {}. HTML title: {}", 
                    league.getLabel(), doc.title());
            eventRows = doc.select(".coupon-row, .coupon-row-item, table.foot-market tbody tr");
        }

        for (Element row : eventRows) {
            try {
                MarathonEvent event = new MarathonEvent();
                event.setSportName(league.getSport());
                event.setLeagueName(league.getLabel());
                event.setTreeId(league.getUid());

                if (!extractEventBasicInfo(row, event)) continue;
                extractScores(row, event);

                Elements priceElements = row.select("[data-selection-key], .selection-link, .coeff-value");
                List<MarathonOdd> odds = new ArrayList<>();
                Set<String> processedIds = new HashSet<>();
                int oddIndex = 0;

                for (Element priceEl : priceElements) {
                    String selectionId = getSelectionKey(priceEl);
                    if (selectionId != null && !selectionId.isEmpty()) {
                        if (processedIds.contains(selectionId)) continue;
                        processedIds.add(selectionId);
                    }

                    MarathonOdd odd = extractOdd(priceEl, oddIndex);
                    if (odd != null) {
                        odds.add(odd);
                        oddIndex++;
                    }
                }

                event.setOdds(odds);
                if (!odds.isEmpty()) events.add(event);
            } catch (Exception e) {
                log.debug("Error parsing event row: {}", e.getMessage());
            }
        }
        return events;
    }

    /**
     * Parse all markets from a single event document.
     */
    public void parseAllMarketsFromHtml(Document doc, MarathonEvent event) {
        Elements priceElements = doc.select("[data-selection-key], .selection-link, .coeff-value");
        if (priceElements.isEmpty()) return;

        List<MarathonOdd> existingOdds = event.getOdds() != null ? event.getOdds() : new ArrayList<>();
        Set<String> existingIds = new HashSet<>();
        for (MarathonOdd odd : existingOdds) {
            if (odd.getId() != null) existingIds.add(odd.getId());
        }

        for (Element priceEl : priceElements) {
            try {
                String selectionKey = getSelectionKey(priceEl);
                if (selectionKey != null && existingIds.contains(selectionKey)) continue;

                MarathonOdd odd = extractOdd(priceEl, -1);
                if (odd != null) {
                    enrichOddWithGroupName(priceEl, odd);
                    existingOdds.add(odd);
                    if (odd.getId() != null) existingIds.add(odd.getId());
                }
            } catch (Exception e) {
                log.trace("Error parsing an additional odd: {}", e.getMessage());
            }
        }
        event.setOdds(existingOdds);
    }

    /**
     * Parse a single event directly by its URL.
     */
    public MarathonEvent parseSingleEventFromHtml(Document doc, String fullUrl, String baseUrl) {
        MarathonEvent event = new MarathonEvent();
        String matchPath = fullUrl.contains(baseUrl) ? fullUrl.replace(baseUrl, "") : fullUrl;
        event.setMatchUrl(matchPath);

        Element sportEl = doc.selectFirst("a.sport-category-label");
        if (sportEl != null) event.setSportName(sportEl.text().trim());
        
        Element leagueEl = doc.selectFirst("a.category-label-link");
        if (leagueEl != null) event.setLeagueName(leagueEl.text().trim());

        if (!extractTeamsFromPage(doc, event)) {
            log.warn("Could not parse team names from {}", fullUrl);
            return null;
        }

        extractEventIdFromUrl(doc, event, matchPath);
        extractScores(doc, event);

        parseAllMarketsFromHtml(doc, event);
        return event;
    }

    // --- Private Helper Methods ---

    private boolean extractEventBasicInfo(Element row, MarathonEvent event) {
        String eventId = row.attr("data-event-treeid");
        if (eventId.isEmpty()) eventId = row.attr("data-event-id");
        if (eventId.isEmpty()) eventId = "marathon-" + Math.abs(row.hashCode());
        event.setEventId(eventId);

        Element linkElement = row.selectFirst("a.member-link, a.event-name");
        if (linkElement != null) event.setMatchUrl(linkElement.attr("href"));

        Elements names = row.select(".member-name, td.name div, .event-name span");
        if (names.size() >= 2) {
            event.setTeam1(names.get(0).text().trim());
            event.setTeam2(names.get(1).text().trim());
        } else if (names.size() == 1) {
            String fullName = names.get(0).text().trim();
            String[] parts = fullName.split(" (?:vs?\\.?|—|–|-) ", 2);
            if (parts.length == 2) {
                event.setTeam1(parts[0].trim());
                event.setTeam2(parts[1].trim());
            } else {
                event.setTeam1(fullName);
                event.setTeam2("");
            }
        }
        return event.getTeam1() != null && !event.getTeam1().isEmpty();
    }

    private void extractScores(Element container, MarathonEvent event) {
        Elements scores = container.select(".score-home, .score-away, .cl-left .result, .cl-right .result, .cl-scorebar-score");
        if (scores.size() >= 2) {
            event.setScore1(scores.get(0).text().trim());
            event.setScore2(scores.get(1).text().trim());
            event.setIsLive(true);
        } else if (!scores.isEmpty()) {
            String scoreText = scores.get(0).text().trim();
            if (scoreText.contains(":")) {
                String[] parts = scoreText.split(":");
                event.setScore1(parts[0].trim());
                event.setScore2(parts[1].trim());
                event.setIsLive(true);
            }
        }
    }

    private MarathonOdd extractOdd(Element priceEl, int oddIndex) {
        String priceText = priceEl.text().trim();
        if (priceText.isEmpty() || priceText.equals("-") || priceText.equals("—")) return null;

        String cleanPrice = priceText.replaceAll("[^0-9.]", "");
        if (cleanPrice.isEmpty()) return null;

        MarathonOdd odd = new MarathonOdd();
        odd.setValue(Double.parseDouble(cleanPrice));
        
        String selectionKey = getSelectionKey(priceEl);
        odd.setId(selectionKey);

        if (selectionKey != null && !selectionKey.isEmpty()) {
            String[] parts = selectionKey.split("@");
            String rawName = parts.length > 1 ? parts[1] : parts[0];

            extractParameters(priceEl, odd, rawName);
            
            odd.setName(rawName);
            String groupName = "Результат";
            if (rawName.contains(".")) {
                groupName = rawName.substring(0, rawName.indexOf('.'));
            }
            
            // Clean tech prefixes from group name
            groupName = groupName.replaceAll("^ADD_\\d+\\.", "");
            groupName = groupName.replaceAll("^\\d+\\.", "");
            
            odd.setGroupName(groupName);
        } else {
            // Fallback to title or index
            if (priceEl.hasAttr("title") && !priceEl.attr("title").isEmpty()) {
                odd.setName(priceEl.attr("title"));
            } else if (oddIndex >= 0 && oddIndex < STANDARD_ODD_NAMES.length) {
                odd.setName(STANDARD_ODD_NAMES[oddIndex]);
            } else {
                return null;
            }
            odd.setGroupName("Результат");
        }

        // Try to extract visual human-readable label
        Element nameEl = priceEl.selectFirst(".selection-name, .name, .row-name");
        if (nameEl != null && !nameEl.text().trim().isEmpty()) {
            odd.setLabel(nameEl.text().trim());
        } else if (priceEl.hasAttr("title") && !priceEl.attr("title").isEmpty()) {
            odd.setLabel(priceEl.attr("title").trim());
        }

        return odd;
    }

    private void extractParameters(Element priceEl, MarathonOdd odd, String rawName) {
        for (OddParamExtractor extractor : paramExtractors) {
            if (extractor.extract(priceEl, odd, rawName)) {
                break;
            }
        }
        // Apply integer total normalization regardless of how param was extracted.
        // Extractor #3 (name fallback) already calls normalizeParam inline, but
        // extractors #1 and #2 (asian average, data-param) do not. We apply it here
        // so that integer totals from data-param also get the ±0.5 shift.
        if (odd.getParam() != null && odd.getParam() != 0.0) {
            double normalized = normalizer.normalizeParam(rawName, odd.getParam());
            odd.setParam(normalized);
        }
    }


    private void enrichOddWithGroupName(Element priceEl, MarathonOdd odd) {
        Element marketGroup = priceEl.closest(".market-inline-block, .market-table, .coupon-row");
        String groupTitle = null;
        if (marketGroup != null) {
            Element titleEl = marketGroup.selectFirst(".market-title, .name, .category-label");
            if (titleEl != null) groupTitle = titleEl.text().trim();
        }
        
        Element periodContainer = priceEl.closest(".market-group, .market-group-container");
        if (periodContainer != null) {
            Element periodTitleEl = periodContainer.selectFirst(".market-group-title, .group-header");
            if (periodTitleEl != null) {
                String periodTitle = periodTitleEl.text().trim();
                groupTitle = groupTitle != null ? periodTitle + " - " + groupTitle : periodTitle;
            }
        }
        
        Element categoryContainer = priceEl.closest(".category-container, .market-category, .event-markets");
        if (categoryContainer != null) {
            Element categoryTitleEl = categoryContainer.selectFirst(".category-label, .category-title, .title");
            if (categoryTitleEl != null) {
                String categoryTitle = categoryTitleEl.text().trim();
                if (!categoryTitle.isEmpty()) {
                    groupTitle = groupTitle != null ? categoryTitle + " - " + groupTitle : categoryTitle;
                }
            }
        }
        
        if (groupTitle != null) odd.setGroupName(groupTitle);
        else if (odd.getGroupName() == null) odd.setGroupName("Доп. маркеты");
    }

    private String getSelectionKey(Element el) {
        String key = el.attr("data-selection-key");
        if (key.isEmpty()) {
            Element closest = el.closest("[data-selection-key]");
            if (closest != null) key = closest.attr("data-selection-key");
        }
        return key.isEmpty() ? null : key;
    }

    private boolean extractTeamsFromPage(Document doc, MarathonEvent event) {
        Elements teamEls = doc.select("a.member-link span");
        if (teamEls.size() >= 2) {
            event.setTeam1(teamEls.get(0).text().trim());
            event.setTeam2(teamEls.get(1).text().trim());
            return true;
        }
        String title = doc.title();
        if (title.contains(" - ") || title.contains(" vs ")) {
            String[] parts = title.split(" (?:vs|-|—) ");
            if (parts.length >= 2) {
                event.setTeam1(parts[0].trim());
                event.setTeam2(parts[1].split(" \\|")[0].trim());
                return true;
            }
        }
        return false;
    }

    private void extractEventIdFromUrl(Document doc, MarathonEvent event, String matchPath) {
        if (matchPath.contains("-+")) {
            String[] urlParts = matchPath.split("-\\+");
            event.setEventId(urlParts[urlParts.length - 1]);
        } else {
            Element firstOdd = doc.selectFirst("[data-selection-key]");
            if (firstOdd != null) {
                String key = firstOdd.attr("data-selection-key");
                event.setEventId(key.contains("@") ? key.split("@")[0] : "marathon-url-" + Math.abs(matchPath.hashCode()));
            } else {
                event.setEventId("marathon-url-" + Math.abs(matchPath.hashCode()));
            }
        }
    }

    private Double parseSafeDouble(String val) {
        if (val == null || val.isEmpty()) return 0.0;
        try {
            String normalized = val.replace(',', '.').replaceAll("[^0-9.]", "");
            return normalized.isEmpty() ? 0.0 : Double.parseDouble(normalized);
        } catch (Exception e) {
            return 0.0;
        }
    }
}
