package pro.datawiki.igaming.source.core.engine.sportbet.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class SportbetMarket {
    private Integer id;
    private String n; // name
    private List<SportbetSelection> sel;
}
