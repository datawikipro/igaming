package pro.datawiki.igaming.source.core.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "unmapped_bet", indexes = {
        @Index(name = "idx_unmapped_bet_sport_raw", columnList = "sport_name, raw_name")
})
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UnmappedBet {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "sport_name")
    private String sportName;

    @Column(name = "raw_name", nullable = false)
    private String rawName;

    @Column(name = "group_name")
    private String groupName;

    @Column(name = "event_id")
    private String eventId;

    @CreationTimestamp
    @Column(name = "created_at")
    private LocalDateTime createdAt;
}
