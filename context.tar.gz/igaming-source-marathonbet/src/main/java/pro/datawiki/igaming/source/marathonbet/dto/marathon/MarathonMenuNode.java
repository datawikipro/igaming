package pro.datawiki.igaming.source.marathonbet.dto.marathon;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import java.util.List;

/**
 * Represents a node in the Marathonbet menu tree.
 * FROM: /su/react/event/menu/prematch
 * Structure: Sports -> Regions -> Leagues (childs hierarchy)
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class MarathonMenuNode {
    private String uid;
    private String label;
    private String url;
    private String sport;
    private String region;
    private List<MarathonMenuNode> childs;
    private Boolean hasChilds;
}
