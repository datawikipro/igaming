package pro.datawiki.igaming.source.core.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import pro.datawiki.igaming.source.core.domain.MatchCache;
import pro.datawiki.igaming.source.core.repository.MatchCacheRepository;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Service to aggressively prune old matches from Postgres to reduce IO and Sequence Scans CPU.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class MatchCacheCleanupService {

    private final MatchCacheRepository matchCacheRepository;

    /**
     * Run every 15 minutes to clean up Old processed/failed and very old entries.
     */
    @Scheduled(fixedDelay = 900000)
    @Transactional
    public void cleanupOldMatches() {
        LocalDateTime now = LocalDateTime.now();
        
        // 1. Delete PROCESSED or FAILED matches older than 1 hour.
        LocalDateTime oneHourAgo = now.minusHours(1);
        List<String> statuses = List.of("PROCESSED", "FAILED");
        matchCacheRepository.deleteFactorsForOldMatchesByStatus(statuses, oneHourAgo);
        matchCacheRepository.deletePayloadsForOldMatchesByStatus(statuses, oneHourAgo);
        int deletedOldProcessed = matchCacheRepository.deleteOldMatchesByStatus(statuses, oneHourAgo);

        // 2. Delete ALL matches (even PENDING) older than 24 hours.
        // This is a safety net so the DB doesn't grow infinitely with ghost/stuck matches.
        LocalDateTime oneDayAgo = now.minusHours(24);
        matchCacheRepository.deleteFactorsForAllOldMatches(oneDayAgo);
        matchCacheRepository.deletePayloadsForAllOldMatches(oneDayAgo);
        int deletedVeryOld = matchCacheRepository.deleteAllOldMatches(oneDayAgo);

        if (deletedOldProcessed > 0 || deletedVeryOld > 0) {
            log.info("Aggressive DB Cleanup: Removed {} old PROCESSED/FAILED matches, and {} very old (>24h) matches.", 
                     deletedOldProcessed, deletedVeryOld);
        }
    }
}
