package pro.datawiki.igaming.source.core.engine.zenit.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import java.util.List;
import java.util.Map;

@Data
public class ZenitResponse {
    @JsonProperty
    private List<ZenitSport> sport;
    private Map<String, ZenitLeague> league;
    @JsonProperty
    private Map<String, ZenitGame> games;
}
