package pro.datawiki.igaming.source.core.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import pro.datawiki.igaming.dto.UnmappedBetNotificationDto;
import pro.datawiki.igaming.source.core.aggregator.AggregatorClient;
import pro.datawiki.igaming.source.core.domain.UnmappedBet;
import pro.datawiki.igaming.source.core.repository.UnmappedBetRepository;

import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
public class UnmappedBetService {

    private final UnmappedBetRepository unmappedBetRepository;
    private final AggregatorClient aggregatorClient;

    public void saveAndNotify(String bookmaker, String sportName, String rawName, String groupName, String eventId) {
        if (rawName == null || rawName.trim().isEmpty() || "null".equalsIgnoreCase(rawName.trim())) return;

        Optional<UnmappedBet> existing = unmappedBetRepository.findFirstBySportNameAndRawName(sportName, rawName);
        if (existing.isEmpty()) {
            log.debug("New unmapped bet type found for {}: '{}' in sport '{}'", bookmaker, rawName, sportName);
            
            unmappedBetRepository.save(UnmappedBet.builder()
                    .sportName(sportName)
                    .rawName(rawName)
                    .groupName(groupName)
                    .eventId(eventId)
                    .build());

            aggregatorClient.pushUnmappedBetNotification(UnmappedBetNotificationDto.builder()
                    .bookmaker(bookmaker)
                    .sportName(sportName)
                    .rawName(rawName)
                    .groupName(groupName)
                    .eventId(eventId)
                    .build());
        }
    }
}
