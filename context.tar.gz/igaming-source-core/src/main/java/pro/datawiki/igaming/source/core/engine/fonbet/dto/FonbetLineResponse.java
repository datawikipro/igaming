package pro.datawiki.igaming.source.core.engine.fonbet.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class FonbetLineResponse {
    @JsonProperty("packetVersion")
    private Long packetVersion;
    @JsonProperty("fromVersion")
    private Long fromVersion;
    @JsonProperty("catalogTablesVersion")
    private Long catalogTablesVersion;
    @JsonProperty("sportBasicMarketsVersion")
    private Long sportBasicMarketsVersion;
    private List<FonbetSport> sports;
    private List<FonbetEvent> events;
    @JsonProperty("eventMiscs")
    private List<FonbetEventMisc> eventMiscs;
    @JsonProperty("eventBlocks")
    private List<FonbetEventBlock> eventBlocks;
    private List<FonbetCustomFactor> factors;
    @JsonProperty("customFactors")
    private List<FonbetCustomFactorGroup> customFactors;
}
