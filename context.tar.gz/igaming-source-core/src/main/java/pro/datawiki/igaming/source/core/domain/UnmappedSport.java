package pro.datawiki.igaming.source.core.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "unmapped_sport")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UnmappedSport {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "bookmaker", nullable = false)
    private String bookmaker;

    @Column(name = "raw_name", nullable = false)
    private String rawName;

    @CreationTimestamp
    @Column(name = "created_at")
    private LocalDateTime createdAt;
}
