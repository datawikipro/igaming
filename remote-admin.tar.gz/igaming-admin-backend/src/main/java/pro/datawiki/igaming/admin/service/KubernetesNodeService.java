package pro.datawiki.igaming.admin.service;

import io.fabric8.kubernetes.api.model.Node;
import io.fabric8.kubernetes.client.KubernetesClient;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class KubernetesNodeService {

    private final KubernetesClient kubernetesClient;
    private final GcpHardwareService gcpHardwareService;

    @Value("${GCP_ZONE:not defined}")
    private String configuredZone;

    public NodeStats getNodesStats() {
        List<Node> nodes;
        try {
            nodes = kubernetesClient.nodes().list().getItems();
        } catch (Exception e) {
            log.error("Failed to list nodes from Kubernetes: {}", e.getMessage());
            return new NodeStats(0, 0, 0, 0);
        }
        
        long totalNodes = nodes.size();
        long stableNodes = 0;
        long spotNodes = 0;
        long homeNodes = 0;
        
        for (Node node : nodes) {
            Map<String, String> labels = node.getMetadata().getLabels();
            if (labels != null) {
                String nodeType = labels.getOrDefault("node-type", "");
                if ("spot".equals(nodeType)) {
                    spotNodes++;
                } else if ("home".equals(nodeType) || node.getMetadata().getName().contains("home")) {
                    homeNodes++;
                } else {
                    stableNodes++;
                }
            } else {
                stableNodes++;
            }
        }
        
        return new NodeStats(totalNodes, stableNodes, spotNodes, homeNodes);
    }

    public List<NodeDetail> getDetailedNodes() {
        Map<String, GcpHardwareService.GcpNodeInfo> gcpInfo = gcpHardwareService.getGcpInstancesInfo();
        
        List<Node> nodes;
        try {
            nodes = kubernetesClient.nodes().list().getItems();
        } catch (Exception e) {
            log.error("Failed to list nodes for detailed view: {}", e.getMessage());
            return List.of();
        }

        return nodes.stream()
                .map(node -> {
                    String nodeName = node.getMetadata().getName();
                    Map<String, String> labels = node.getMetadata().getLabels();
                    String type = labels != null ? labels.getOrDefault("node-type", "main") : "main";
                    
                    GcpHardwareService.GcpNodeInfo hw = gcpInfo.getOrDefault(nodeName, null);
                    String machineType = hw != null ? hw.machineType() : (labels != null ? labels.getOrDefault("node.kubernetes.io/instance-type", "not defined") : "not defined");
                    String zone = labels != null ? labels.getOrDefault("topology.kubernetes.io/zone", 
                                  labels.getOrDefault("failure-domain.beta.kubernetes.io/zone", configuredZone)) : configuredZone;
                    
                    String cpuPlatform = hw != null ? hw.cpuPlatform() : "not defined";
                    
                    String scheduling = hw != null ? hw.scheduling() : "Unknown";
                    
                    return new NodeDetail(
                            nodeName,
                            type,
                            node.getStatus().getCapacity().get("cpu").getAmount(),
                            formatRam(node.getStatus().getCapacity().get("memory").getAmount()),
                            machineType,
                            zone,
                            node.getStatus().getConditions().stream()
                                    .filter(c -> "Ready".equals(c.getType()))
                                    .map(c -> "True".equals(c.getStatus()) ? "Ready" : "NotReady")
                                    .findFirst().orElse("Unknown"),
                            cpuPlatform,
                            scheduling
                    );
                })
                .collect(Collectors.toList());
    }

    public Map<String, Node> getActiveNodesMap() {
        try {
            return kubernetesClient.nodes().list().getItems().stream()
                    .collect(Collectors.toMap(node -> node.getMetadata().getName(), node -> node));
        } catch (Exception e) {
            log.error("Failed to get active nodes map: {}", e.getMessage());
            return Map.of();
        }
    }

    public record NodeStats(long total, long stable, long spot, long home) {}
    
    @lombok.Data
    @lombok.AllArgsConstructor
    @lombok.NoArgsConstructor
    @lombok.Builder
    public static class NodeDetail {
        private String name;
        private String type;
        private String cpu;
        private String memory;
        private String machineType;
        private String zone;
        private String status;
        private String cpuPlatform;
        private String scheduling;
    }
    private String formatRam(String kiAmount) {
        try {
            long ki = Long.parseLong(kiAmount);
            double gb = ki / (1024.0 * 1024.0);
            return String.format("%.1f GB", gb);
        } catch (Exception e) {
            return kiAmount + " RAM";
        }
    }
}
