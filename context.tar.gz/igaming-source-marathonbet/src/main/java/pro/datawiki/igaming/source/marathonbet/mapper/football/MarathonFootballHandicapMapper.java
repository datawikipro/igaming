package pro.datawiki.igaming.source.marathonbet.mapper.football;

import org.springframework.stereotype.Component;
import pro.datawiki.igaming.dto.BetType;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.dto.market.BetScope;
import pro.datawiki.igaming.dto.market.HandicapBet;
import pro.datawiki.igaming.dto.market.StatType;
import pro.datawiki.igaming.source.core.mapper.AbstractBetTypeMapper;

@Component
public class MarathonFootballHandicapMapper extends AbstractBetTypeMapper {

    @Override
    public boolean supports(String bookmaker, SportType sportType) {
        return "marathonbet".equals(bookmaker) && sportType == SportType.FOOTBALL;
    }

    @Override
    public BetType map(String m, String o) {
        if (m == null || o == null) return null;
        String upperM = m.toUpperCase().replace("_", " ").replace(".", " ").trim();
        String upperO = o.toUpperCase().trim();

        if (upperM.contains("HANDICAP") || upperM.contains("SPREAD")) {
            BetScope scope = BetScope.FULL_MATCH;
            if (upperM.contains("1ST HALF")) scope = BetScope.HALF_1;
            else if (upperM.contains("2ND HALF")) scope = BetScope.HALF_2;

            HandicapBet.Team team = (upperO.contains("1") || upperO.contains("HOME") || upperO.contains("HB_H") || upperO.contains("HB_ASN_H")) ? HandicapBet.Team.TEAM1 : HandicapBet.Team.TEAM2;
            return new HandicapBet(scope, team, 0.0, upperM.contains("ASIAN"), StatType.MATCH);
        }
        return null;
    }
}
