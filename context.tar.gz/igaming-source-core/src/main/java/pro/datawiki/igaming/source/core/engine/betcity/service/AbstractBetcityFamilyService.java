package pro.datawiki.igaming.source.core.engine.betcity.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import pro.datawiki.igaming.dto.OddItem;
import pro.datawiki.igaming.dto.OddsUpdateRequest;
import pro.datawiki.igaming.source.core.aggregator.AggregatorClient;
import pro.datawiki.igaming.source.core.domain.MatchCache;
import pro.datawiki.igaming.source.core.domain.MatchFactor;
import pro.datawiki.igaming.source.core.domain.SportCache;
import pro.datawiki.igaming.source.core.engine.betcity.dto.*;
import pro.datawiki.igaming.source.core.repository.MatchCacheRepository;
import pro.datawiki.igaming.source.core.repository.SportCacheRepository;
import pro.datawiki.igaming.source.core.service.UnmappedBetService;
import pro.datawiki.igaming.source.core.validation.JsonValidationService;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.dto.BetType;
import pro.datawiki.igaming.source.core.service.SportNormalizationService;
import pro.datawiki.igaming.source.core.service.BetTypeResolverService;


import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.LocalDateTime;
import java.util.*;

@Slf4j
public abstract class AbstractBetcityFamilyService {

    protected final MatchCacheRepository matchCacheRepository;
    protected final SportCacheRepository sportCacheRepository;
    protected final AggregatorClient aggregatorClient;
    protected final ObjectMapper objectMapper;
    protected final JsonValidationService jsonValidationService;
    protected final UnmappedBetService unmappedBetService;
    protected final SportNormalizationService sportNormalizationService;
    protected final BetTypeResolverService betTypeResolver;


    public AbstractBetcityFamilyService(MatchCacheRepository matchCacheRepository,
                                       SportCacheRepository sportCacheRepository,
                                       AggregatorClient aggregatorClient,
                                       ObjectMapper objectMapper,
                                       JsonValidationService jsonValidationService,
                                       UnmappedBetService unmappedBetService,
                                       SportNormalizationService sportNormalizationService,
                                       BetTypeResolverService betTypeResolver) {
        this.matchCacheRepository = matchCacheRepository;
        this.sportCacheRepository = sportCacheRepository;
        this.aggregatorClient = aggregatorClient;
        this.objectMapper = objectMapper;
        this.jsonValidationService = jsonValidationService;
        this.unmappedBetService = unmappedBetService;
        this.sportNormalizationService = sportNormalizationService;
        this.betTypeResolver = betTypeResolver;
    }


    @Value("${app.bookmaker.name:betcity}")
    protected String bookmakerName;

    @Value("${app.bookmaker.region:ru}")
    protected String region;

    /**
     * Discovery role: processes the full line JSON and saves metadata to MatchCache.
     */
    public int discoverEvents(String json, boolean isLive) {
        if (json == null || json.isEmpty()) {
            return 0;
        }

        // 1. Strict JSON Schema Validation
        try {
            jsonValidationService.validate(json, "betcity-schema.json");
        } catch (Exception e) {
            log.error("CRITICAL: Betcity API structure changed! Skipping discovery cycle. Error: {}", e.getMessage());
            return 0;
        }

        BetcityResponse response;
        try {
            response = objectMapper.readValue(json, BetcityResponse.class);
        } catch (Exception e) {
            log.error("Failed to deserialize BetcityResponse: {}", e.getMessage());
            return 0;
        }

        if (response == null || response.getReply() == null || response.getReply().getSports() == null) {
            return 0;
        }

        int discoveredCount = 0;
        for (BetcitySport sport : response.getReply().getSports().values()) {
            saveSport(sport);

            if (sport.getChmps() == null) continue;

            for (BetcityChmp chmp : sport.getChmps().values()) {
                if (chmp.getEvts() == null) continue;

                for (BetcityEvent event : chmp.getEvts().values()) {
                    if (event.getNameHt() == null || event.getNameAt() == null) continue;

                    try {
                        saveOrUpdateMatchMetadata(event, sport, isLive);
                        discoveredCount++;
                    } catch (Exception e) {
                        log.error("Error saving metadata for Betcity event {}: {}", event.getIdEv(), e.getMessage());
                    }
                }
            }
        }

        log.info("[{}/{}] Discovered {} {} events", bookmakerName, region, discoveredCount, isLive ? "live" : "prematch");
        return discoveredCount;
    }

    /**
     * Backward-compatible method: simply calls discoverEvents.
     */
    public int processResponse(String json, boolean isLive) {
        return discoverEvents(json, isLive);
    }

    protected void saveOrUpdateMatchMetadata(BetcityEvent event, BetcitySport sport, boolean isLive) {
        String externalId = String.valueOf(event.getIdEv());
        Optional<MatchCache> existing = matchCacheRepository.findByExternalId(externalId);

        MatchCache match = existing.orElseGet(MatchCache::new);
        match.setExternalId(externalId);
        match.setSportId(sport.getIdSp());
        match.setSportName(sport.getNameSp());
        match.setTeam1(event.getNameHt());
        match.setTeam2(event.getNameAt());

        long startTime = event.getDateEv() != null ? event.getDateEv() : 0;
        if (startTime > 0 && startTime < 10000000000L) {
             startTime *= 1000;
        }
        match.setStartTime(startTime);
        match.setIsLive(isLive);
        
        if (event.getScEv() != null) {
            String[] parts = event.getScEv().split(":");
            if (parts.length >= 2) {
                match.setScore1(parts[0].trim());
                match.setScore2(parts[1].trim());
            }
        }
        
        match.setUpdatedAt(LocalDateTime.now());
        if (match.getCreatedAt() == null) {
            match.setCreatedAt(LocalDateTime.now());
        }

        String jsonPayload;
        try {
            jsonPayload = objectMapper.writeValueAsString(event);
        } catch (Exception e) {
            jsonPayload = "{}";
        }

        String newHash = computeHash(jsonPayload);
        if (match.getPayloadHash() == null || !match.getPayloadHash().equals(newHash)) {
            match.setStatus(MatchCache.Status.NEW);
        }

        match.setJsonPayload(jsonPayload);
        match.setPayloadHash(newHash);
        
        // Relational factors sync for search/filtering
        syncFactors(match, event, resolveBetcitySportType(sport.getNameSp()));
        
        matchCacheRepository.save(match);
    }

    /**
     * Match-loader worker role: continuously pops the oldest matches from DB and enriches them.
     */
    public int loadMatchCards(int batchSize) {
        List<MatchCache> batch = matchCacheRepository.findAndLockOnlyNewPendingMatches(org.springframework.data.domain.PageRequest.of(0, batchSize));

        if (batch.isEmpty()) return 0;
        int processed = 0;

        for (MatchCache cache : batch) {
            try {
                pushToAggregator(cache);
                
                cache.setStatus(MatchCache.Status.PROCESSED);
                cache.setUpdatedAt(LocalDateTime.now());
                matchCacheRepository.save(cache);
                processed++;
            } catch (Exception e) {
                log.error("Failed to load Betcity match card for {}: {}", cache.getExternalId(), e.getMessage());
                cache.setStatus(MatchCache.Status.FAILED);
                cache.setUpdatedAt(LocalDateTime.now());
                matchCacheRepository.save(cache);
            }
        }
        return processed;
    }

    protected void pushToAggregator(MatchCache match) {
        BetcityEvent event;
        try {
            event = objectMapper.readValue(match.getJsonPayload(), BetcityEvent.class);
        } catch (Exception e) {
            log.error("Failed to parse cached payload for {}: {}", match.getExternalId(), e.getMessage());
            return;
        }

        OddsUpdateRequest request = buildOddsUpdateRequest(match, event);
        List<OddItem> odds = processOdds(match, event, request.getSportType());
        
        if (!odds.isEmpty()) {
            request.setOdds(odds);
            aggregatorClient.pushOddsUpdate(request);
        }
    }

    private OddsUpdateRequest buildOddsUpdateRequest(MatchCache match, BetcityEvent event) {
        OddsUpdateRequest request = new OddsUpdateRequest();
        request.setBookmaker(bookmakerName);
        request.setRegion(region);
        request.setEventUrl(generateEventUrl(match, event, match.getIsLive()));
        request.setExternalEventId(match.getExternalId());
        request.setSportName(match.getSportName());
        request.setTeam1(match.getTeam1());
        request.setTeam2(match.getTeam2());
        request.setScore1(match.getScore1());
        request.setScore2(match.getScore2());
        request.setStartTime(match.getStartTime());
        request.setIsLive(match.getIsLive());
        request.setPayloadHash(match.getPayloadHash());

        SportType sportType = resolveBetcitySportType(match.getSportName());
        request.setSportType(sportType);
        return request;
    }

    private List<OddItem> processOdds(MatchCache match, BetcityEvent event, SportType sportType) {
        List<OddItem> odds = new ArrayList<>();
        Map<String, OddItem> resolvedOdds = new HashMap<>();

        extractOddsFromSection(event.getMain(), odds, resolvedOdds, sportType, match.getExternalId());
        extractOddsFromSection(event.getExt(), odds, resolvedOdds, sportType, match.getExternalId());
        
        return odds;
    }

    protected void extractOddsFromSection(Map<String, BetcityMain> section, List<OddItem> odds, Map<String, OddItem> resolvedOdds, SportType sportType, String eventId) {
        if (section == null) return;
        for (BetcityMain mainSection : section.values()) {
            if (mainSection.getData() == null) continue;
            for (BetcityData dataObj : mainSection.getData().values()) {
                if (dataObj.getBlocks() == null) continue;
                for (Map.Entry<String, Map<String, BetcityOutcome>> blockEntry : dataObj.getBlocks().entrySet()) {
                    String groupName = blockEntry.getKey();
                    Map<String, BetcityOutcome> block = blockEntry.getValue();
                    if (block == null) continue;
                    
                    // Pre-detect parameter fields (F1, F2, T, etc.) that provide the line value
                    Map<String, Double> params = new HashMap<>();
                    for (Map.Entry<String, BetcityOutcome> e : block.entrySet()) {
                        String k = e.getKey();
                        BetcityOutcome v = e.getValue();
                        // If it's a simple number (no md or md is 0) and not a known Kf_ field
                        if (!k.startsWith("Kf_") && v.getKf() != null && (v.getMd() == null || v.getMd() == 0.0)) {
                            params.put(k, v.getKf());
                        }
                    }

                    String enrichedGroupName = mainSection.getName() != null ? mainSection.getName() : groupName;
                    if (params.containsKey("Num")) {
                        int num = params.get("Num").intValue();
                        if (sportType == SportType.ESPORTS) {
                            enrichedGroupName = num + "-Я КАРТА: " + enrichedGroupName;
                        } else if (sportType == SportType.TENNIS || sportType == SportType.VOLLEYBALL || sportType == SportType.TABLE_TENNIS) {
                            enrichedGroupName = num + "-Й СЕТ: " + enrichedGroupName;
                        } else if (sportType == SportType.SNOOKER) {
                            enrichedGroupName = num + "-Й ФРЕЙМ: " + enrichedGroupName;
                        } else {
                            enrichedGroupName = num + "-Й ТАЙМ: " + enrichedGroupName;
                        }
                    }

                    for (Map.Entry<String, BetcityOutcome> outcomeEntry : block.entrySet()) {
                        String name = outcomeEntry.getKey();
                        BetcityOutcome outcome = outcomeEntry.getValue();

                        // Skip fields that are just parameters if their coefficient counterpart exists
                        if (params.containsKey(name) && (block.containsKey("Kf_" + name) || block.containsKey("Kf_" + name + "_Over"))) {
                            continue;
                        }
                        
                        if (outcome.getKf() != null) {
                            String displayName = outcome.getNm() != null ? outcome.getNm() : name;
                            BetType betType = betTypeResolver.resolve(bookmakerName, sportType, enrichedGroupName, displayName, eventId);

                            if (betType == null || "UNKNOWN".equals(betType.code())) {
                                unmappedBetService.saveAndNotify(bookmakerName, sportType.name(), displayName, enrichedGroupName, eventId);
                                continue;
                            }

                            // Inject param into parametric bet types (totals, handicaps)
                            Double md = outcome.getMd();
                            
                            // If md is missing or looks like an ID (too large), try to get it from params map
                            if (md == null || md == 0.0 || Math.abs(md) > 10000.0) {
                                String paramKey = name.startsWith("Kf_") ? name.substring(3) : name;
                                // Handle Kf_T_Over -> T, Kf_T_Under -> T
                                if (paramKey.endsWith("_Over")) paramKey = paramKey.substring(0, paramKey.length() - 5);
                                if (paramKey.endsWith("_Under")) paramKey = paramKey.substring(0, paramKey.length() - 6);
                                
                                if (params.containsKey(paramKey)) {
                                    md = params.get(paramKey);
                                } else if (md != null && Math.abs(md) > 10000.0) {
                                    md = null; // Discard invalid md
                                }
                            }

                            if (betType.isParametric() && md != null && md != 0.0) {
                                try {
                                    betType = betType.withParam(md * betType.paramMultiplier());
                                } catch (UnsupportedOperationException ignored) {}
                            }

                            OddItem item = new OddItem();
                            item.setFactorId(Math.abs((enrichedGroupName + ":" + name).hashCode()));
                            item.setGroupName(enrichedGroupName);
                            item.setName(displayName);
                            item.setValue(outcome.getKf());
                            item.setBetType(betType);

                            // Semantic duplicate check
                            String semanticKey = betType.code();
                            if (resolvedOdds.containsKey(semanticKey)) {
                                OddItem existing = resolvedOdds.get(semanticKey);
                                if (!existing.getValue().equals(item.getValue())) {
                                    log.warn("DUPLICATE COEFFICIENT ATTEMPT: Tried to map 1 coefficient twice with DIFFERENT values! " +
                                              "Event={}, Group={}, SemanticKey={}, ExistingValue={}, NewValue={}, ExistingOriginalName='{}', NewOriginalName='{}'",
                                              eventId, enrichedGroupName, semanticKey, existing.getValue(), item.getValue(),
                                              existing.getName(), item.getName());
                                }
                                continue;
                            }

                            resolvedOdds.put(semanticKey, item);
                            odds.add(item);
                        }
                    }
                }
            }
        }
    }




    private void syncFactors(MatchCache match, BetcityEvent event, SportType sportType) {
        if (match.getFactors() == null) {
            match.setFactors(new ArrayList<>());
        } else {
            match.getFactors().clear();
        }
        List<OddItem> oddsDtos = new ArrayList<>();
        extractOddsFromSection(event.getMain(), oddsDtos, new HashMap<>(), sportType, String.valueOf(event.getIdEv()));
        extractOddsFromSection(event.getExt(), oddsDtos, new HashMap<>(), sportType, String.valueOf(event.getIdEv()));
        
        for (OddItem dto : oddsDtos) {
            MatchFactor factor = new MatchFactor();
            factor.setMatch(match);
            factor.setName(dto.getName());
            factor.setValue(dto.getValue());
            factor.setFactorId(dto.getFactorId()); 
            match.getFactors().add(factor);
        }
    }

    protected SportType resolveBetcitySportType(String sportName) {
        if (sportName == null) return SportType.UNKNOWN;
        return sportNormalizationService.normalize(sportName);
    }

    private String computeHash(String content) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(content.getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(hash);
        } catch (Exception e) {
            return String.valueOf(content.hashCode());
        }
    }

    private void saveSport(BetcitySport betcitySport) {
        try {
            if (betcitySport.getIdSp() == null) return;
            int sportId = betcitySport.getIdSp();
            Optional<SportCache> existing = sportCacheRepository.findByExternalId(sportId);
            SportCache sport = existing.orElseGet(SportCache::new);
            sport.setExternalId(sportId);
            sport.setName(betcitySport.getNameSp());
            sport.setUpdatedAt(LocalDateTime.now());
            sportCacheRepository.save(sport);
        } catch (Exception e) {
            log.debug("Error saving sport {}: {}", betcitySport.getIdSp(), e.getMessage());
        }
    }

    protected abstract String generateEventUrl(MatchCache match, BetcityEvent event, boolean isLive);
}
