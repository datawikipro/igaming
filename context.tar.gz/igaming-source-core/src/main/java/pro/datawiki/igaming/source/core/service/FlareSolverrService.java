package pro.datawiki.igaming.source.core.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Universal service for interacting with a FlareSolverr sidecar to bypass anti-bot protection
 * and extract session cookies.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class FlareSolverrService {

    private final RestTemplate restTemplate;
    private final StringRedisTemplate redisTemplate;
    private final ObjectMapper objectMapper;

    // FlareSolverr is expected to be a sidecar in the same pod.
    private static final String DEFAULT_FLARESOLVERR_URL = "http://localhost:8191/v1";

    /**
     * Refreshes cookies for a target URL and stores specific cookies in Redis.
     *
     * @param targetUrl The website to visit (e.g., https://fon.bet/)
     * @param cookieNames Array of cookie names to extract (e.g., ["spsn", "spid"])
     * @param redisKeyPrefix Prefix for Redis keys (e.g., "fonbet:cookie:")
     * @param ttlMinutes Time to live in Redis for extracted cookies
     */
    public void refreshCookies(String targetUrl, String[] cookieNames, String redisKeyPrefix, int ttlMinutes) {
        log.info("Refreshing cookies via FlareSolverr for: {}", targetUrl);
        try {
            Map<String, Object> requestBody = new HashMap<>();
            requestBody.put("cmd", "request.get");
            requestBody.put("url", targetUrl);
            requestBody.put("maxTimeout", 60000);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<Map<String, Object>> entity = new HttpEntity<>(requestBody, headers);

            String response = restTemplate.postForObject(DEFAULT_FLARESOLVERR_URL, entity, String.class);
            if (response != null) {
                JsonNode root = objectMapper.readTree(response);
                if ("ok".equals(root.path("status").asText())) {
                    JsonNode cookies = root.path("solution").path("cookies");
                    if (cookies.isArray()) {
                        int count = 0;
                        for (JsonNode cookieNode : cookies) {
                            String name = cookieNode.path("name").asText();
                            String value = cookieNode.path("value").asText();
                            
                            for (String targetName : cookieNames) {
                                if (targetName.equals(name)) {
                                    String redisKey = redisKeyPrefix + name;
                                    redisTemplate.opsForValue().set(redisKey, value, ttlMinutes, TimeUnit.MINUTES);
                                    log.debug("Saved cookie to Redis: {} -> {}", redisKey, value);
                                    count++;
                                }
                            }
                        }
                        log.info("Successfully refreshed {} cookies for {}", count, targetUrl);
                    }
                } else {
                    log.error("FlareSolverr error: {}", root.path("message").asText());
                }
            }
        } catch (Exception e) {
            log.error("Failed to refresh cookies via FlareSolverr for {}: {}", targetUrl, e.getMessage());
        }
    }
}
