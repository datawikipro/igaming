package pro.datawiki.igaming.source.core.engine.fonbet.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class FonbetEventBlock {
    private Integer id;
    private String state;
    private List<Integer> factors;
}
