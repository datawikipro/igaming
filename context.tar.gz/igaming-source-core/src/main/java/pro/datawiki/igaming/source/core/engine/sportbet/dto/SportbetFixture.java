package pro.datawiki.igaming.source.core.engine.sportbet.dto;

import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class SportbetFixture {
    private Integer fi; // fixture id
    private Integer tid; // tournament id
    private Long d; // date/time start?
    private List<SportbetMarketGroup> gm;

    private Map<String, Object> extra = new HashMap<>();

    @JsonAnySetter
    public void setExtra(String key, Object value) {
        extra.put(key, value);
    }
}
