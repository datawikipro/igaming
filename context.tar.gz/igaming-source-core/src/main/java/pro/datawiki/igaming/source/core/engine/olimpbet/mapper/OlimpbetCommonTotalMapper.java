package pro.datawiki.igaming.source.core.engine.olimpbet.mapper;

import org.springframework.stereotype.Component;
import pro.datawiki.igaming.dto.BetType;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.dto.market.BetScope;
import pro.datawiki.igaming.dto.market.BetSubject;
import pro.datawiki.igaming.dto.market.StatType;
import pro.datawiki.igaming.source.core.mapper.AbstractBetTypeMapper;

import java.util.Set;

@Component
public class OlimpbetCommonTotalMapper extends AbstractBetTypeMapper {

    private static final Set<SportType> SPECIALIZED_SPORTS = Set.of(
            SportType.FOOTBALL, SportType.BASKETBALL, SportType.HOCKEY, SportType.TENNIS,
            SportType.ESPORTS, SportType.CYBER_FOOTBALL, SportType.CYBER_BASKETBALL, SportType.CYBER_HOCKEY,
            SportType.VOLLEYBALL, SportType.BEACH_VOLLEYBALL, SportType.TABLE_TENNIS
    );

    @Override
    public boolean supports(String bookmaker, SportType sportType) {
        return bookmaker != null && bookmaker.toLowerCase().contains("olimpbet") && !SPECIALIZED_SPORTS.contains(sportType);
    }

    @Override
    public BetType map(String market, String outcome) {
        if (market == null || outcome == null) return null;
        String upperM = market.toUpperCase().trim();
        String upperO = outcome.toUpperCase().trim();

        if (upperM.contains("ТОТАЛ") || upperM.contains("TOTAL")) {
            BetScope scope = resolveScope(upperM);
            BetSubject subject = BetSubject.MATCH;
            if (upperM.contains("ИНДИВИДУАЛЬНЫЙ ТОТАЛ 1") || upperM.contains("1-ГО")) subject = BetSubject.TEAM1;
            else if (upperM.contains("ИНДИВИДУАЛЬНЫЙ ТОТАЛ 2") || upperM.contains("2-ГО")) subject = BetSubject.TEAM2;

            StatType stat = StatType.MATCH;
            if (upperM.contains("КАРТ")) stat = StatType.MAPS;
            else if (upperM.contains("ГЕЙМ")) stat = StatType.GAMES;

            return mapTotalRecord(upperO, scope, subject, stat, false);
        }
        return null;
    }

    private BetScope resolveScope(String market) {
        if (market.contains("1-Й ТАЙМ") || market.contains("1-Я ПОЛОВИНА")) return BetScope.HALF_1;
        if (market.contains("2-Й ТАЙМ") || market.contains("2-Я ПОЛОВИНА")) return BetScope.HALF_2;
        if (market.contains("1-Й СЕТ")) return BetScope.SET_1;
        if (market.contains("1-Й ПЕРИОД")) return BetScope.PERIOD_1;
        if (market.contains("1-Я ЧЕТВЕРТЬ")) return BetScope.QUARTER_1;
        if (market.contains("КАРТА 1")) return BetScope.MAP_1;
        return BetScope.FULL_MATCH;
    }
}
