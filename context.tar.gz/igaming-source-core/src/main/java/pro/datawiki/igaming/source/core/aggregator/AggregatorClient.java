package pro.datawiki.igaming.source.core.aggregator;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;
import pro.datawiki.igaming.dto.OddsRefreshRequestDto;
import pro.datawiki.igaming.dto.OddsUpdateRequest;

import java.util.Collections;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class AggregatorClient {

    private final RestTemplate restTemplate;

    @Value("${app.aggregator.url:http://igaming-aggregator}")
    private String aggregatorUrl;

    public void pushOddsUpdate(OddsUpdateRequest request) {
        pushToAggregator("/api/odds/update", request);
    }

    public void pushOutrightUpdate(OddsUpdateRequest request) {
        pushToAggregator("/api/odds/outright/update", request);
    }

    private void pushToAggregator(String path, OddsUpdateRequest request) {
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<OddsUpdateRequest> entity = new HttpEntity<>(request, headers);

            restTemplate.postForEntity(
                    aggregatorUrl + path,
                    entity,
                    String.class
            );
            log.debug("Pushed update for event {} to aggregator path {}", request.getExternalEventId(), path);
        } catch (Exception e) {
            log.warn("Failed to push update to aggregator path {} for event {}: {}",
                    path, request.getExternalEventId(), e.getMessage());
        }
    }

    public void pushBatchUpdate(List<OddsUpdateRequest> requests) {
        pushBatchToAggregator("/api/odds/update/batch", requests);
    }

    public void pushOutrightBatchUpdate(List<OddsUpdateRequest> requests) {
        pushBatchToAggregator("/api/odds/outright/update/batch", requests);
    }

    private void pushBatchToAggregator(String path, List<OddsUpdateRequest> requests) {
        if (requests == null || requests.isEmpty()) {
            return;
        }
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<List<OddsUpdateRequest>> entity = new HttpEntity<>(requests, headers);

            restTemplate.postForEntity(
                    aggregatorUrl + path,
                    entity,
                    String.class
            );
            log.info("Pushed batch of {} updates to aggregator path {}", requests.size(), path);
        } catch (Exception e) {
            log.warn("Failed to push batch update to aggregator path {}: {}", path, e.getMessage());
        }
    }

    public void pushUnmappedBetNotification(pro.datawiki.igaming.dto.UnmappedBetNotificationDto notification) {
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<pro.datawiki.igaming.dto.UnmappedBetNotificationDto> entity = new HttpEntity<>(notification, headers);

            restTemplate.postForEntity(
                    aggregatorUrl + "/api/odds/unmapped",
                    entity,
                    String.class
            );
            log.debug("Pushed unmapped bet notification for {}", notification.getRawName());
        } catch (Exception e) {
            log.warn("Failed to push unmapped bet notification for {}: {}", notification.getRawName(), e.getMessage());
        }
    }

    // =========================================================================
    // Odds Refresh Queue (surebet-driven targeted refresh)
    // =========================================================================

    /**
     * Fetch prematch (HIGH/MEDIUM/LOW) refresh requests from aggregator.
     */
    public List<OddsRefreshRequestDto> fetchPrematchRefreshQueue(String sourceId) {
        return fetchRefreshQueue("/api/odds/refresh-queue/prematch", sourceId);
    }

    /**
     * Fetch LIVE refresh requests from aggregator.
     */
    public List<OddsRefreshRequestDto> fetchLiveRefreshQueue(String sourceId) {
        return fetchRefreshQueue("/api/odds/refresh-queue/live", sourceId);
    }

    private List<OddsRefreshRequestDto> fetchRefreshQueue(String path, String sourceId) {
        try {
            String url = UriComponentsBuilder.fromHttpUrl(aggregatorUrl + path)
                    .queryParam("source", sourceId)
                    .toUriString();

            ResponseEntity<List<OddsRefreshRequestDto>> response = restTemplate.exchange(
                    url,
                    HttpMethod.GET,
                    null,
                    new ParameterizedTypeReference<List<OddsRefreshRequestDto>>() {}
            );

            return response.getBody() != null ? response.getBody() : Collections.emptyList();
        } catch (Exception e) {
            log.debug("Failed to fetch refresh queue from {}: {}", path, e.getMessage());
            return Collections.emptyList();
        }
    }

    /**
     * Acknowledge that a refresh has been completed for a specific event.
     */
    public void acknowledgeRefresh(String sourceId, String externalEventId) {
        try {
            String url = UriComponentsBuilder.fromHttpUrl(aggregatorUrl + "/api/odds/refresh-ack")
                    .queryParam("source", sourceId)
                    .queryParam("externalEventId", externalEventId)
                    .toUriString();

            restTemplate.postForEntity(url, null, Void.class);
            log.trace("Acknowledged refresh for source={}, event={}", sourceId, externalEventId);
        } catch (Exception e) {
            log.debug("Failed to acknowledge refresh for event {}: {}", externalEventId, e.getMessage());
        }
    }
}
