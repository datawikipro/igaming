package pro.datawiki.igaming.source.core.engine.fonbet.mapper;

import org.springframework.stereotype.Component;
import pro.datawiki.igaming.dto.BetType;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.dto.market.BetScope;
import pro.datawiki.igaming.dto.market.BetSubject;
import pro.datawiki.igaming.dto.market.StatType;
import pro.datawiki.igaming.dto.market.TotalBet;
import pro.datawiki.igaming.dto.market.TotalBet.Direction;
import pro.datawiki.igaming.source.core.mapper.AbstractBetTypeMapper;

import java.util.Map;
import java.util.Set;

@Component
public class FonbetCommonTotalMapper extends AbstractBetTypeMapper {

    private static final Set<SportType> SPECIALIZED_SPORTS = Set.of(
            SportType.FOOTBALL, SportType.BASKETBALL, SportType.HOCKEY, SportType.TENNIS,
            SportType.ESPORTS, SportType.CYBER_FOOTBALL, SportType.CYBER_BASKETBALL, SportType.CYBER_HOCKEY,
            SportType.VOLLEYBALL, SportType.BEACH_VOLLEYBALL, SportType.TABLE_TENNIS
    );

    private static final Set<String> OVER_IDS = Set.of(
            "930", "932", "934", "1094", "1096", "1696", "1727", "1730", "1733", "1736", "1739", "1791", "1794", "1797", "2535", "2538", "2541", "1812"
    );

    private static final Set<String> UNDER_IDS = Set.of(
            "931", "933", "935", "1093", "1095", "1697", "1728", "1731", "1734", "1737", "1793", "1796", "2534", "2537", "2540", "1813", "1881"
    );

    private static final Set<String> TEAM1_IDS = Set.of("932", "933", "1812", "1813");
    private static final Set<String> TEAM2_IDS = Set.of("934", "935", "1881");

    @Override
    public boolean supports(String bookmaker, SportType sportType) {
        return "fonbet".equals(bookmaker) && !SPECIALIZED_SPORTS.contains(sportType);
    }

    @Override
    public BetType map(String market, String outcome) {
        if (outcome == null) return null;
        
        Direction dir = null;
        if (OVER_IDS.contains(outcome)) dir = Direction.OVER;
        else if (UNDER_IDS.contains(outcome)) dir = Direction.UNDER;
        
        if (dir == null) return null;

        BetSubject subject = BetSubject.MATCH;
        if (TEAM1_IDS.contains(outcome)) subject = BetSubject.TEAM1;
        else if (TEAM2_IDS.contains(outcome)) subject = BetSubject.TEAM2;

        BetScope scope = resolveScope(market);
        StatType stat = resolveStat(market);

        return new TotalBet(scope, subject, dir, 0.0, false, stat);
    }

    private BetScope resolveScope(String market) {
        if (market == null) return BetScope.FULL_MATCH;
        String m = market.toLowerCase();
        if (m.contains("1-й период") || m.contains("1-й тайм") || m.contains("1-я четверть") || m.contains("1-й сет")) return BetScope.PERIOD_1;
        if (m.contains("2-й период") || m.contains("2-й тайм") || m.contains("2-я четверть") || m.contains("2-й сет")) return BetScope.PERIOD_2;
        if (m.contains("3-й период") || m.contains("3-я четверть") || m.contains("3-й сет")) return BetScope.PERIOD_3;
        if (m.contains("4-я четверть")) return BetScope.QUARTER_4;
        if (m.contains("1-я половина")) return BetScope.HALF_1;
        if (m.contains("2-я половина")) return BetScope.HALF_2;
        return BetScope.FULL_MATCH;
    }

    private StatType resolveStat(String market) {
        if (market == null) return StatType.MATCH;
        String m = market.toLowerCase();
        if (m.contains("угловые")) return StatType.CORNERS;
        if (m.contains("желтые карточки") || m.contains("жк")) return StatType.CARDS;
        return StatType.MATCH;
    }
}
