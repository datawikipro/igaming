package pro.datawiki.igaming.source.core.engine;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import pro.datawiki.igaming.dto.OddItem;
import pro.datawiki.igaming.dto.OddsUpdateRequest;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.source.core.aggregator.AggregatorClient;
import pro.datawiki.igaming.source.core.domain.MatchCache;
import pro.datawiki.igaming.source.core.repository.MatchCacheRepository;
import pro.datawiki.igaming.source.core.service.MatchPersistenceService;
import pro.datawiki.igaming.source.core.service.SportNormalizationService;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Slf4j
@RequiredArgsConstructor
public abstract class AbstractMatchService<T> {

    protected final MatchCacheRepository matchCacheRepository;
    protected final MatchPersistenceService persistenceService;
    protected final AggregatorClient aggregatorClient;
    protected final ObjectMapper objectMapper;
    protected final SportNormalizationService sportNormalizationService;

    /**
     * Discovery role: processes a list of events and saves metadata to MatchCache.
     */
    public int discoverEvents(List<T> events, boolean isLive) {
        if (events == null || events.isEmpty()) {
            return 0;
        }

        int discoveredCount = 0;
        for (T event : events) {
            if (!isValidEvent(event)) continue;

            try {
                processEventDiscovery(event, isLive);
                discoveredCount++;
            } catch (Exception e) {
                log.error("Error saving metadata for {} event: {}", getBookmakerName(), e.getMessage());
            }
        }

        log.info("Discovered {} {} {} events", discoveredCount, isLive ? "live" : "prematch", getBookmakerName());
        return discoveredCount;
    }

    /**
     * Backward-compatible method.
     */
    public int processEvents(List<T> events, boolean isLive) {
        return discoverEvents(events, isLive);
    }

    /**
     * Match-loader worker role: continuously pops the oldest matches from DB and enriches them.
     */
    public int loadMatchCards(int batchSize) {
        List<MatchCache> batch = matchCacheRepository.findAndLockPendingMatches(
                org.springframework.data.domain.PageRequest.of(0, batchSize));

        if (batch.isEmpty()) return 0;
        int processed = 0;

        for (MatchCache cache : batch) {
            try {
                pushToAggregator(cache);
                
                cache.setStatus(MatchCache.Status.PROCESSED);
                cache.setUpdatedAt(LocalDateTime.now());
                matchCacheRepository.save(cache);
                processed++;
            } catch (Exception e) {
                log.error("Failed to load {} match card for {}: {}", getBookmakerName(), cache.getExternalId(), e.getMessage());
                cache.setStatus(MatchCache.Status.FAILED);
                cache.setUpdatedAt(LocalDateTime.now());
                matchCacheRepository.save(cache);
            }
        }
        return processed;
    }

    protected void pushToAggregator(MatchCache match) {
        T event = parseEventPayload(match);
        if (event == null) return;

        OddsUpdateRequest request = buildOddsUpdateRequest(match);
        List<OddItem> odds = processOdds(match, event, request.getSportType());

        if (!odds.isEmpty()) {
            request.setOdds(odds);
            aggregatorClient.pushOddsUpdate(request);
        }
    }

    protected abstract String getBookmakerName();
    protected abstract boolean isValidEvent(T event);
    protected abstract void processEventDiscovery(T event, boolean isLive) throws Exception;
    protected abstract T parseEventPayload(MatchCache match);
    protected abstract OddsUpdateRequest buildOddsUpdateRequest(MatchCache match);
    protected abstract List<OddItem> processOdds(MatchCache match, T event, SportType sportType);

    protected SportType normalizeSport(String sportName) {
        if (sportName == null) return SportType.UNKNOWN;
        return sportNormalizationService.normalize(sportName);
    }
}
