package pro.datawiki.igaming.admin.service;

import com.google.cloud.container.v1.ClusterManagerClient;
import com.google.cloud.container.v1.ClusterManagerSettings;
import com.google.container.v1.SetNodePoolSizeRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;

@Slf4j
@Service
public class GcpScalingService {

    private final pro.datawiki.igaming.admin.repository.CloudAccountRepository cloudAccountRepository;

    public GcpScalingService(pro.datawiki.igaming.admin.repository.CloudAccountRepository cloudAccountRepository) {
        this.cloudAccountRepository = cloudAccountRepository;
    }

    public void setSpotNodePoolSize(String targetProjectId, String targetZone, String targetClusterId, String nodePoolId, int size) {
        log.info("Scaling spot node pool {} in cluster {} to size {}", nodePoolId, targetClusterId, size);
        
        pro.datawiki.igaming.admin.entity.CloudAccount account = cloudAccountRepository.findByIsActiveTrueOrderByPriorityAsc().stream()
                .filter(a -> "GCP".equalsIgnoreCase(a.getProvider()) && targetProjectId.equalsIgnoreCase(a.getProjectId()))
                .findFirst()
                .orElseThrow(() -> new RuntimeException("No active GCP account found for project: " + targetProjectId));

        try (ClusterManagerClient client = createClient(account)) {
            String name = String.format("projects/%s/locations/%s/clusters/%s/nodePools/%s", 
                targetProjectId, targetZone, targetClusterId, nodePoolId);
            
            SetNodePoolSizeRequest request = SetNodePoolSizeRequest.newBuilder()
                .setName(name)
                .setNodeCount(size)
                .build();
            
            client.setNodePoolSize(request);
            log.info("Scaling request sent successfully");
        } catch (IOException e) {
            log.error("Failed to scale spot node pool", e);
            throw new RuntimeException("GCP Scaling failed", e);
        }
    }

    private ClusterManagerClient createClient(pro.datawiki.igaming.admin.entity.CloudAccount account) throws IOException {
        ClusterManagerSettings.Builder settingsBuilder = ClusterManagerSettings.newBuilder();
        if (account.getCredentialsJson() != null && !account.getCredentialsJson().trim().isEmpty()) {
            try (java.io.ByteArrayInputStream bais = new java.io.ByteArrayInputStream(account.getCredentialsJson().getBytes(java.nio.charset.StandardCharsets.UTF_8))) {
                com.google.auth.oauth2.GoogleCredentials credentials = com.google.auth.oauth2.GoogleCredentials.fromStream(bais)
                        .createScoped(java.util.List.of("https://www.googleapis.com/auth/cloud-platform"));
                settingsBuilder.setCredentialsProvider(com.google.api.gax.core.FixedCredentialsProvider.create(credentials));
            }
        }
        return ClusterManagerClient.create(settingsBuilder.build());
    }
}
