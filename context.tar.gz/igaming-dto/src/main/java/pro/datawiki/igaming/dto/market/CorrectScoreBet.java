package pro.datawiki.igaming.dto.market;

import pro.datawiki.igaming.dto.BetType;

/**
 * Record representing a Correct Score bet.
 * Examples: 1:0, 2:1, 0:0, or "Any Other Score".
 */
public record CorrectScoreBet(
        BetScope scope,
        int score1,
        int score2,
        boolean isAnyOtherScore
) implements BetType {

    @Override
    public String code() {
        StringBuilder sb = new StringBuilder();
        sb.append(scope.prefix());
        sb.append("CORRECT_SCORE");
        
        if (isAnyOtherScore) {
            sb.append("_ANY");
        } else {
            sb.append("_").append(score1).append("_").append(score2);
        }
        
        return sb.toString();
    }

    @Override
    public String marketCode() {
        return scope.prefix() + "CORRECT_SCORE";
    }

    @Override
    public String description() {
        if (isAnyOtherScore) {
            return scope.name() + " Any Other Score";
        }
        return scope.name() + " Correct Score " + score1 + ":" + score2;
    }

    @Override
    public boolean isParametric() {
        // Technically it relies on parameters (the scores), but they are baked into the record
        // and stringified in the code. For legacy compatibility, we return false here so 
        // that Aggregator doesn't enforce a 'param' Double field.
        return false;
    }

    @Override
    public BetType withParam(double param) {
        throw new UnsupportedOperationException("CorrectScoreBet uses string/integer score parameters, not a single Double param.");
    }
}
