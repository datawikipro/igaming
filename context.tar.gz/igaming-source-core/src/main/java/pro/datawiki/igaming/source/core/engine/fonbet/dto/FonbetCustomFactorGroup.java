package pro.datawiki.igaming.source.core.engine.fonbet.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.Data;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class FonbetCustomFactorGroup {
    private Integer e;
    
    @JsonProperty("eventId")
    private Integer eventId;

    private List<FonbetCustomFactor> factors;

    public Integer getE() {
        return e != null ? e : eventId;
    }
}
