package pro.datawiki.igaming.source.core.engine.baltbet.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import pro.datawiki.igaming.dto.OddItem;
import pro.datawiki.igaming.dto.OddsUpdateRequest;
import pro.datawiki.igaming.source.core.aggregator.AggregatorClient;
import pro.datawiki.igaming.source.core.domain.MatchCache;
import pro.datawiki.igaming.source.core.domain.MatchFactor;
import pro.datawiki.igaming.source.core.engine.baltbet.dto.BaltbetCoef;
import pro.datawiki.igaming.source.core.engine.baltbet.dto.BaltbetEvent;
import pro.datawiki.igaming.source.core.engine.baltbet.dto.BaltbetResponse;
import pro.datawiki.igaming.source.core.repository.MatchCacheRepository;
import pro.datawiki.igaming.source.core.repository.SportCacheRepository;
import pro.datawiki.igaming.source.core.service.UnmappedBetService;
import pro.datawiki.igaming.source.core.validation.JsonValidationService;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.dto.BetType;
import pro.datawiki.igaming.source.core.service.SportNormalizationService;
import pro.datawiki.igaming.source.core.service.BetTypeResolverService;


import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HexFormat;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Slf4j
public abstract class AbstractBaltbetFamilyService {

    protected final MatchCacheRepository matchCacheRepository;
    protected final SportCacheRepository sportCacheRepository;
    protected final AggregatorClient aggregatorClient;
    protected final ObjectMapper objectMapper;
    protected final JsonValidationService jsonValidationService;
    protected final UnmappedBetService unmappedBetService;
    protected final SportNormalizationService sportNormalizationService;
    protected final BetTypeResolverService betTypeResolver;


    public AbstractBaltbetFamilyService(MatchCacheRepository matchCacheRepository,
                                       SportCacheRepository sportCacheRepository,
                                       AggregatorClient aggregatorClient,
                                       ObjectMapper objectMapper,
                                       JsonValidationService jsonValidationService,
                                       UnmappedBetService unmappedBetService,
                                       SportNormalizationService sportNormalizationService,
                                       BetTypeResolverService betTypeResolver) {
        this.matchCacheRepository = matchCacheRepository;
        this.sportCacheRepository = sportCacheRepository;
        this.aggregatorClient = aggregatorClient;
        this.objectMapper = objectMapper;
        this.jsonValidationService = jsonValidationService;
        this.unmappedBetService = unmappedBetService;
        this.sportNormalizationService = sportNormalizationService;
        this.betTypeResolver = betTypeResolver;
    }


    @Value("${app.bookmaker.name:baltbet}")
    protected String bookmakerName;

    @Value("${app.bookmaker.region:ru}")
    protected String region;

    /**
     * Discovery role: processes the full line JSON and saves metadata to MatchCache.
     */
    public int discoverEvents(String json, boolean isLive) {
        if (json == null || json.isEmpty()) {
            return 0;
        }

        // 1. Strict JSON Schema Validation
        try {
            jsonValidationService.validate(json, "baltbet-schema.json");
        } catch (Exception e) {
            log.error("CRITICAL: Baltbet API structure changed! Skipping discovery cycle. Error: {}", e.getMessage());
            return 0;
        }

        BaltbetResponse response;
        try {
            response = objectMapper.readValue(json, BaltbetResponse.class);
        } catch (Exception e) {
            log.error("Failed to deserialize BaltbetResponse: {}", e.getMessage());
            return 0;
        }

        if (response == null || response.getEvents() == null) {
            return 0;
        }

        int discoveredCount = 0;
        for (BaltbetEvent event : response.getEvents()) {
            if (event.getId() == null) continue;

            try {
                saveOrUpdateMatchMetadata(event, isLive);
                discoveredCount++;
            } catch (Exception e) {
                log.error("Error saving metadata for Baltbet event {}: {}", event.getId(), e.getMessage());
            }
        }

        log.info("[{}/{}] Discovered {} {} events", bookmakerName, region, discoveredCount, isLive ? "live" : "prematch");
        return discoveredCount;
    }

    /**
     * Backward-compatible method: simply calls discoverEvents.
     */
    public int processResponse(String json, boolean isLive) {
        return discoverEvents(json, isLive);
    }

    protected final java.util.concurrent.ConcurrentHashMap<String, String> localHashCache = new java.util.concurrent.ConcurrentHashMap<>();
    protected final java.util.concurrent.ConcurrentHashMap<String, Long> localTimeCache = new java.util.concurrent.ConcurrentHashMap<>();

    protected void saveOrUpdateMatchMetadata(BaltbetEvent event, boolean isLive) {
        String externalId = String.valueOf(event.getId());
        Optional<MatchCache> existing = matchCacheRepository.findByExternalId(externalId);

        MatchCache match = existing.orElseGet(MatchCache::new);
        match.setExternalId(externalId);
        
        if (event.getSportId() != null) {
            match.setSportId(event.getSportId());
            match.setSportName(resolveBaltbetSportName(event.getSportId()));
        }

        if (event.getExtra().containsKey("ht")) {
            match.setTeam1(String.valueOf(event.getExtra().get("ht")));
        }
        if (event.getExtra().containsKey("at")) {
            match.setTeam2(String.valueOf(event.getExtra().get("at")));
        }
        
        if (match.getTeam1() == null) match.setTeam1("Team1_" + externalId);
        if (match.getTeam2() == null) match.setTeam2("Team2_" + externalId);

        match.setIsLive(isLive);
        match.setUpdatedAt(LocalDateTime.now());
        if (match.getCreatedAt() == null) {
            match.setCreatedAt(LocalDateTime.now());
        }

        String jsonPayload;
        try {
            jsonPayload = objectMapper.writeValueAsString(event);
        } catch (Exception e) {
            jsonPayload = "{}";
        }

        String newHash = computeHash(jsonPayload);
        String cacheKey = externalId + "_" + isLive;
        long now = System.currentTimeMillis();
        Long lastUpdate = localTimeCache.get(cacheKey);
        if (newHash.equals(localHashCache.get(cacheKey)) && lastUpdate != null && (now - lastUpdate) < 3 * 60 * 1000) {
            return;
        }

        if (match.getPayloadHash() == null || !match.getPayloadHash().equals(newHash)) {
            match.setStatus(MatchCache.Status.NEW);
        }

        match.setJsonPayload(jsonPayload);
        match.setPayloadHash(newHash);
        
        // Relational factors sync
        syncFactors(match, event);
        
        matchCacheRepository.save(match);
        localHashCache.put(cacheKey, newHash);
        localTimeCache.put(cacheKey, now);
    }

    /**
     * Match-loader worker role: continuously pops the oldest matches from DB and enriches them.
     */
    public int loadMatchCards(int batchSize) {
        List<MatchCache> batch = matchCacheRepository.findAndLockOnlyNewPendingMatches(org.springframework.data.domain.PageRequest.of(0, batchSize));

        if (batch.isEmpty()) return 0;
        int processed = 0;

        for (MatchCache cache : batch) {
            try {
                pushToAggregator(cache);
                
                cache.setStatus(MatchCache.Status.PROCESSED);
                cache.setUpdatedAt(LocalDateTime.now());
                matchCacheRepository.save(cache);
                processed++;
            } catch (Exception e) {
                log.error("Failed to load Baltbet match card for {}: {}", cache.getExternalId(), e.getMessage());
                cache.setStatus(MatchCache.Status.FAILED);
                cache.setUpdatedAt(LocalDateTime.now());
                matchCacheRepository.save(cache);
            }
        }
        return processed;
    }

    protected void pushToAggregator(MatchCache match) {
        BaltbetEvent event;
        try {
            event = objectMapper.readValue(match.getJsonPayload(), BaltbetEvent.class);
        } catch (Exception e) {
            log.error("Failed to parse cached payload for {}: {}", match.getExternalId(), e.getMessage());
            return;
        }

        OddsUpdateRequest request = buildOddsUpdateRequest(match, event);
        List<OddItem> odds = processOdds(match, event, request.getSportType());

        if (!odds.isEmpty()) {
            request.setOdds(odds);
            aggregatorClient.pushOddsUpdate(request);
        }
    }

    private OddsUpdateRequest buildOddsUpdateRequest(MatchCache match, BaltbetEvent event) {
        OddsUpdateRequest request = new OddsUpdateRequest();
        request.setBookmaker(bookmakerName);
        request.setRegion(region);
        request.setEventUrl(generateEventUrl(match, event, match.getIsLive()));
        request.setExternalEventId(match.getExternalId());
        request.setSportName(match.getSportName());
        request.setTeam1(match.getTeam1());
        request.setTeam2(match.getTeam2());
        request.setIsLive(match.getIsLive());
        request.setPayloadHash(match.getPayloadHash());

        SportType sportType = resolveBaltbetSportType(match.getSportName());
        request.setSportType(sportType);
        return request;
    }

    private List<OddItem> processOdds(MatchCache match, BaltbetEvent event, SportType sportType) {
        List<OddItem> odds = new ArrayList<>();
        Map<String, OddItem> resolvedOdds = new HashMap<>();

        if (event.getCoefs() != null) {
            for (BaltbetCoef coef : event.getCoefs()) {
                if (coef.getValue() != null && coef.getType() != null) {
                    BetType betType = betTypeResolver.resolve(bookmakerName, sportType, String.valueOf(coef.getType()), null, match.getExternalId());
                    
                    if (betType == null || "UNKNOWN".equals(betType.code())) {
                        unmappedBetService.saveAndNotify(bookmakerName, sportType.name(), String.valueOf(coef.getType()), "BALTBET_MAIN", match.getExternalId());
                        continue;
                    }

                    // Inject param into parametric bet types (totals, handicaps)
                    if (betType.isParametric() && coef.getParam() != null && !coef.getParam().isEmpty()) {
                        try {
                            double param = Double.parseDouble(coef.getParam().replace(',', '.'));
                            if (param != 0.0) {
                                betType = betType.withParam(param * betType.paramMultiplier());
                            }
                        } catch (NumberFormatException | UnsupportedOperationException ignored) {}
                    }

                    OddItem item = new OddItem();
                    item.setName(String.valueOf(coef.getType()));
                    item.setValue(coef.getValue());
                    item.setBetType(betType);

                    // Semantic duplicate check
                    String semanticKey = betType.code();
                    if (resolvedOdds.containsKey(semanticKey)) {
                        OddItem existing = resolvedOdds.get(semanticKey);
                        if (!existing.getValue().equals(item.getValue())) {
                            log.error("DUPLICATE COEFFICIENT ATTEMPT: Tried to map 1 coefficient twice with DIFFERENT values! " +
                                      "Event={}, SemanticKey={}, ExistingValue={}, NewValue={}, ExistingOriginalName='{}', NewOriginalName='{}'",
                                      match.getExternalId(), semanticKey, existing.getValue(), item.getValue(),
                                      existing.getName(), item.getName());
                        }
                        continue;
                    }

                    resolvedOdds.put(semanticKey, item);
                    odds.add(item);
                }
            }
        }
        return odds;
    }




    private void syncFactors(MatchCache match, BaltbetEvent event) {
        if (event.getCoefs() == null) return;
        match.getFactors().clear();
        for (BaltbetCoef coef : event.getCoefs()) {
            if (coef.getValue() != null && coef.getType() != null) {
                MatchFactor factor = new MatchFactor();
                factor.setMatch(match);
                factor.setFactorId(coef.getType());
                factor.setName(String.valueOf(coef.getType()));
                factor.setValue(coef.getValue());
                match.getFactors().add(factor);
            }
        }
    }

    private String computeHash(String content) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(content.getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(hash);
        } catch (Exception e) {
            return String.valueOf(content.hashCode());
        }
    }

    protected SportType resolveBaltbetSportType(String sportName) {
        if (sportName == null) return SportType.UNKNOWN;
        
        // Centralized normalization (covers common Russian and English names)
        return sportNormalizationService.normalize(sportName);
    }

    private String resolveBaltbetSportName(Integer sportId) {
        if (sportId == null) return "Unknown";
        return sportCacheRepository.findByExternalId(sportId)
                .map(sc -> sc.getName())
                .orElse("Sport_" + sportId);
    }

    protected abstract String generateEventUrl(MatchCache match, BaltbetEvent event, boolean isLive);
}
