package pro.datawiki.igaming.source.core.engine.betcity.mapper;

import org.springframework.stereotype.Component;
import pro.datawiki.igaming.dto.BetType;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.dto.market.BetScope;
import pro.datawiki.igaming.dto.market.BetSubject;
import pro.datawiki.igaming.dto.market.StatType;
import pro.datawiki.igaming.dto.market.TotalBet;
import pro.datawiki.igaming.source.core.mapper.AbstractBetTypeMapper;

@Component
public class BetcityEsportsTotalMapper extends AbstractBetTypeMapper {

    @Override
    public boolean supports(String bookmaker, SportType sportType) {
        return bookmaker != null && bookmaker.toLowerCase().contains("betcity") && (sportType == SportType.ESPORTS || sportType == SportType.CYBER_FOOTBALL || sportType == SportType.CYBER_BASKETBALL || sportType == SportType.CYBER_HOCKEY);
    }

    @Override
    public BetType map(String m, String o) {
        if (m == null || o == null) return null;
        String group = m.toLowerCase().trim();
        String outcome = o.toUpperCase().trim();

        if (group.contains("тотал")) {
            BetScope scope = BetScope.FULL_MATCH;
            StatType statType = StatType.MATCH;

            if (group.contains("карт")) statType = StatType.MAPS;
            else if (group.contains("раунд")) statType = StatType.ROUNDS;
            else if (group.contains("убийств")) statType = StatType.KILLS;

            if (group.contains("1-я карта")) scope = BetScope.MAP_1;

            if (outcome.startsWith("БО") || outcome.equals("OVER") || outcome.equals("Б")) 
                return new TotalBet(scope, BetSubject.MATCH, TotalBet.Direction.OVER, 0.0, false, statType);
            if (outcome.startsWith("МЕ") || outcome.equals("UNDER") || outcome.equals("М")) 
                return new TotalBet(scope, BetSubject.MATCH, TotalBet.Direction.UNDER, 0.0, false, statType);
        }
        return null;
    }
}
