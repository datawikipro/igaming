package pro.datawiki.igaming.source.core.engine.betcity.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.Data;
import java.io.IOException;
import java.util.Map;
import com.fasterxml.jackson.databind.JavaType;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonDeserialize(using = BetcityData.Deserializer.class)
public class BetcityData {
    private Map<String, Map<String, BetcityOutcome>> blocks;

    public static class Deserializer extends JsonDeserializer<BetcityData> {
        @Override
        public BetcityData deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
            if (p.currentToken() == JsonToken.START_OBJECT) {
                JsonNode node = p.getCodec().readTree(p);
                BetcityData data = new BetcityData();
                if (node.has("blocks") && !node.get("blocks").isNull()) {
                    com.fasterxml.jackson.core.type.TypeReference<Map<String, Map<String, BetcityOutcome>>> typeRef = 
                        new com.fasterxml.jackson.core.type.TypeReference<Map<String, Map<String, BetcityOutcome>>>() {};
                    data.setBlocks(ctxt.readTreeAsValue(node.get("blocks"), ctxt.getTypeFactory().constructType(typeRef)));
                }
                return data;
            }
            p.skipChildren();
            return null;
        }
    }
}
