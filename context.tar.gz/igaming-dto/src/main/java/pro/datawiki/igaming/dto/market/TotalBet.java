package pro.datawiki.igaming.dto.market;

import pro.datawiki.igaming.dto.BetType;

public record TotalBet(
        BetScope scope,
        BetSubject subject,
        Direction direction,
        double param,
        boolean isAsian,
        StatType statType
) implements BetType {

    public enum Direction { OVER, UNDER, EXACT }

    @Override
    public String code() {
        StringBuilder sb = new StringBuilder();
        sb.append(scope.prefix());
        sb.append(subject.prefix());
        sb.append(statType != null ? statType.prefix() : "");
        if (isAsian) {
            sb.append("ASIAN_");
        }
        sb.append("TOTAL_").append(direction.name());
        sb.append("_").append(param);
        return sb.toString();
    }

    @Override
    public String marketCode() {
        StringBuilder sb = new StringBuilder();
        sb.append(scope.prefix());
        sb.append(subject.prefix());
        sb.append(statType != null ? statType.prefix() : "");
        if (isAsian) {
            sb.append("ASIAN_");
        }
        sb.append("TOTAL");
        return sb.toString();
    }

    @Override
    public String description() {
        return "Total " + (isAsian ? "Asian " : "") + direction + " " + param;
    }

    @Override
    public boolean isParametric() {
        return true;
    }

    @Override
    public BetType withParam(double param) {
        return new TotalBet(scope, subject, direction, param, isAsian, statType);
    }

    @Override
    public Double getParam() {
        return param;
    }
}
