package pro.datawiki.igaming.source.core.engine.olimpbet.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class OlimpbetOutcome {
    private String shortName;
    private String probability; // contains the odds like "24.00"
    private String groupName;
    private String param;
}
