package pro.datawiki.igaming.source.core.engine.sportbet.mapper;

import org.springframework.stereotype.Component;
import pro.datawiki.igaming.dto.BetType;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.dto.market.BetScope;
import pro.datawiki.igaming.dto.market.StatType;
import pro.datawiki.igaming.source.core.mapper.AbstractBetTypeMapper;

import java.util.Set;

@Component
public class SportbetCommonResultMapper extends AbstractBetTypeMapper {

    private static final Set<SportType> SPECIALIZED_SPORTS = Set.of(
            SportType.FOOTBALL, SportType.BASKETBALL, SportType.HOCKEY, SportType.TENNIS,
            SportType.ESPORTS, SportType.CYBER_FOOTBALL, SportType.CYBER_BASKETBALL, SportType.CYBER_HOCKEY,
            SportType.VOLLEYBALL, SportType.BEACH_VOLLEYBALL, SportType.TABLE_TENNIS
    );

    @Override
    public boolean supports(String bookmaker, SportType sportType) {
        return "sportbet".equals(bookmaker) && !SPECIALIZED_SPORTS.contains(sportType);
    }

    @Override
    public BetType map(String market, String outcome) {
        if (market == null || outcome == null) return null;
        String m = market.toUpperCase().trim();
        String o = outcome.toUpperCase().trim();

        if (m.equals("MATCH WINNER") || m.equals("RESULT") || m.equals("1X2")) {
            return map1X2DCRecord(o, BetScope.FULL_MATCH, StatType.MATCH);
        }

        if (m.equals("DOUBLE CHANCE")) {
            return map1X2DCRecord(o, BetScope.FULL_MATCH, StatType.MATCH);
        }

        return null;
    }
}
