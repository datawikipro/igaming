package pro.datawiki.igaming.source.core.engine.betcity.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.Data;
import java.io.IOException;
import com.fasterxml.jackson.annotation.JsonCreator;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonDeserialize(using = BetcityOutcome.Deserializer.class)
public class BetcityOutcome {
    private Double kf;
    private Double md;
    private String nm;

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static BetcityOutcome fromNumber(Number number) {
        BetcityOutcome outcome = new BetcityOutcome();
        if (number != null) outcome.setKf(number.doubleValue());
        return outcome;
    }

    public static class Deserializer extends JsonDeserializer<BetcityOutcome> {
        @Override
        public BetcityOutcome deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
            if (p.currentToken() == JsonToken.START_OBJECT) {
                JsonNode node = p.getCodec().readTree(p);
                BetcityOutcome outcome = new BetcityOutcome();
                if (node.has("kf") && !node.get("kf").isNull()) outcome.setKf(node.get("kf").asDouble());
                if (node.has("md") && !node.get("md").isNull()) outcome.setMd(node.get("md").asDouble());
                if (node.has("nm") && !node.get("nm").isNull()) outcome.setNm(node.get("nm").asText());
                return outcome;
            } else if (p.currentToken() == JsonToken.VALUE_NUMBER_FLOAT || p.currentToken() == JsonToken.VALUE_NUMBER_INT) {
                BetcityOutcome outcome = new BetcityOutcome();
                outcome.setKf(p.getValueAsDouble());
                return outcome;
            }
            p.skipChildren();
            return null;
        }
    }
}
