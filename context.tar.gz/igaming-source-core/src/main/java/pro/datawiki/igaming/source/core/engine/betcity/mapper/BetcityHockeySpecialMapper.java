package pro.datawiki.igaming.source.core.engine.betcity.mapper;

import org.springframework.stereotype.Component;
import pro.datawiki.igaming.dto.BetType;
import pro.datawiki.igaming.dto.SportType;
import pro.datawiki.igaming.dto.market.*;
import pro.datawiki.igaming.source.core.mapper.AbstractBetTypeMapper;

@Component
public class BetcityHockeySpecialMapper extends AbstractBetTypeMapper {

    @Override
    public boolean supports(String bookmaker, SportType sportType) {
        return bookmaker != null && bookmaker.toLowerCase().contains("betcity") && sportType == SportType.HOCKEY;
    }

    @Override
    public BetType map(String m, String o) {
        if (m == null || o == null) return null;
        String group = m.toLowerCase().trim();
        String outcome = o.toUpperCase().trim();

        // --- Handicap ---
        if (group.contains("фора") && (group.contains("с учетом от") || group.contains("incl. ot"))) {
            if (outcome.equals("1") || outcome.startsWith("Ф1")) 
                return new HandicapBet(BetScope.FULL_MATCH_INCLUDING_OT, HandicapBet.Team.TEAM1, 0.0, false, StatType.MATCH);
            if (outcome.equals("2") || outcome.startsWith("Ф2")) 
                return new HandicapBet(BetScope.FULL_MATCH_INCLUDING_OT, HandicapBet.Team.TEAM2, 0.0, false, StatType.MATCH);
        }

        // --- Qualify ---
        if (group.contains("проход") || group.contains("выход в") || group.contains("to qualify")) {
             BetSubject subject = (outcome.matches("1|П1|ХОЗЯЕВА")) ? BetSubject.TEAM1 : BetSubject.TEAM2;
             return new BinaryMarketBet(BetScope.FULL_MATCH, subject, BinaryMarketBet.MarketType.QUALIFY, BinaryMarketBet.Outcome.YES, StatType.MATCH);
        }

        return null;
    }
}
