package pro.datawiki.igaming.admin.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import pro.datawiki.igaming.admin.entity.CloudAccount;

import java.util.List;

@Repository
public interface CloudAccountRepository extends JpaRepository<CloudAccount, Long> {
    List<CloudAccount> findByIsActiveTrueOrderByPriorityAsc();
    List<CloudAccount> findByIsActiveTrueAndProviderOrderByPriorityAsc(String provider);
}
